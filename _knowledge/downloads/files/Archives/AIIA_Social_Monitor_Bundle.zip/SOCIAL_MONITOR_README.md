# AIIA Social Monitor & Scraper Bundle

This package contains the integrated logic for real-time social media monitoring and extraction.

## 📺 The Social Monitor (UI)
The Social Monitor is the primary interface for triggering and viewing platform scans.
- **Location**: `src/App.jsx` (Search for "Social Monitor" tab).
- **Features**: 
    - Real-time scan progress indicators.
    - Rate-limit handling.
    - Dynamic term mapping (e.g., Traffic vs. Followers).

## 📡 The Scraper Bridge (Backend)
The backend engine that fulfills the scan requests.
- **Location**: `scraper-server.js`.
- **Logic**: Handles authentication-less scraping via SerpAPI, direct API calls for Facebook/Website, and cloud delegation via n8n.

## 🗄️ Initial Data
- **PLATFORMS_INIT**: Defines the baseline metrics and profile URLs for X, LinkedIn, Facebook, Instagram, TikTok, YouTube, and the AIIA Website.
- **VERIFIED_POSTS_INIT**: Contains the historical database of posts used for trend analysis and chart generation.
