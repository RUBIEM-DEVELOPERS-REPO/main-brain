---
name: social-media-monitoring
description: collect and analyze social media data for the consolidated company dashboard. Use when syncing or summarizing followers, posts, reach, impressions, engagement, clicks, audience growth, or social media performance across connected social platforms.
---

# Social Media Monitoring

## Goal
Track social media activity and summarize audience growth and engagement.

## Workflow
1. Identify connected social media platforms.
2. Collect social metrics:
   - Followers
   - Posts
   - Impressions
   - Reach
   - Engagement
   - Clicks
3. Compare against previous period.
4. Identify highest-performing platforms and posts.
5. Detect unusual drops or spikes.
6. Produce dashboard-ready summary.

## Output Format
Return:
- Social media highlights
- Platform comparison
- Audience growth
- Engagement summary
- Alerts
- Recommended actions
