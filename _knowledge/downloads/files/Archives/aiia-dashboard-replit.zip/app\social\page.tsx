'use client';

import React from 'react';

export default function SocialMediaPage() {
  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out' }}>
      <header style={{ marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>Social Media Monitoring</h1>
        <p style={{ color: 'var(--text-muted)' }}>Track audience growth and engagement across platforms.</p>
      </header>

      <div className="dashboard-grid">
        <div className="card metric-card animate-fade-in">
          <span className="metric-label">Total Followers</span>
          <span className="metric-value">42,850</span>
        </div>
        <div className="card metric-card animate-fade-in">
          <span className="metric-label">Avg. Engagement</span>
          <span className="metric-value">5.2%</span>
        </div>
        <div className="card metric-card animate-fade-in">
          <span className="metric-label">New Posts (30d)</span>
          <span className="metric-value">124</span>
        </div>
      </div>

      <div className="dashboard-grid" style={{ marginTop: '2.5rem' }}>
        {['Instagram', 'LinkedIn', 'Twitter (X)', 'TikTok'].map((platform) => (
          <div key={platform} className="card animate-fade-in">
            <h3 style={{ marginBottom: '1rem' }}>{platform}</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Followers</span>
                <span style={{ fontWeight: 600 }}>{(Math.random() * 10000).toFixed(0)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Weekly Growth</span>
                <span style={{ color: 'var(--secondary)' }}>+2.4%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
