---
name: dashboard-summary-reporting
description: generate executive summaries and dashboard reports from consolidated finance, marketing, social media, and admin data. Use when creating daily, weekly, monthly, or ad hoc company performance summaries from the integrated dashboard system.
---

# Dashboard Summary Reporting

## Goal
Turn dashboard metrics into a clear company performance summary.

## Workflow
1. Gather latest dashboard metrics across:
   - Finance
   - Marketing
   - Social media
   - Admin operations
2. Identify major changes since the previous period.
3. Summarize wins, risks, and items needing attention.
4. Keep the report concise and executive-friendly.
5. Include recommended next actions.

## Output Format
Return:
- Executive summary
- Financial highlights
- Marketing highlights
- Social media highlights
- Admin highlights
- Risks
- Recommended actions
