---
name: marketing-data-ingestion
description: collect, validate, and normalize marketing data from connected marketing systems, advertising platforms, CRMs, analytics tools, APIs, databases, or spreadsheets for the consolidated company dashboard. Use when syncing leads, campaigns, spend, impressions, clicks, conversions, traffic, or campaign performance data.
---

# Marketing Data Ingestion

## Goal
Collect marketing data from connected systems and prepare it for dashboard reporting.

## Workflow
1. Identify active marketing connections.
2. Collect campaign and channel data:
   - Leads
   - Spend
   - Impressions
   - Clicks
   - Conversions
   - Traffic
   - Campaign names
   - Channel names
3. Validate required fields.
4. Normalize channel and campaign names.
5. Calculate derived metrics:
   - Cost per lead
   - Conversion rate
   - Click-through rate
6. Store normalized results for dashboard use.
7. Report errors and missing data.

## Output Format
Return:
- Sync status
- Channels processed
- Campaigns processed
- Metrics created
- Errors
- Warnings
