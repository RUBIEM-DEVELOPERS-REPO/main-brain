const Database = require('better-sqlite3');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const dbPath = path.join(process.cwd(), 'dashboard.db');
const db = new Database(dbPath);

// Get connection IDs
const mktConn = db.prepare("SELECT id FROM connections WHERE name = 'Marketing & Social System'").get();
const finConn = db.prepare("SELECT id FROM connections WHERE name = 'Internal Financial System'").get();
const resConn = db.prepare("SELECT id FROM connections WHERE name = 'Research Publication System'").get();

if (mktConn) {
  const stmt = db.prepare(`
    INSERT INTO marketing_metrics (id, source_connection_id, metric_date, channel, campaign_name, spend, impressions, clicks, leads, conversions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(uuidv4(), mktConn.id, '2024-10-24', 'Google', 'Summer Drive', 1200, 50000, 2500, 120, 15);
  stmt.run(uuidv4(), mktConn.id, '2024-10-24', 'LinkedIn', 'B2B Growth', 800, 15000, 600, 45, 8);
}

if (finConn) {
  const stmt = db.prepare(`
    INSERT INTO financial_metrics (id, source_connection_id, metric_date, revenue, expenses, profit, cash_balance)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(uuidv4(), finConn.id, '2024-10-24', 45000, 28000, 17000, 125000);
}

if (resConn) {
  const stmt = db.prepare(`
    INSERT INTO research_publications (id, source_connection_id, title, authors, publication_date, summary, journal, status, impact_factor)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(uuidv4(), resConn.id, 'Neural Network Optimization for Agentic AI', 'A. Magaya, J. Doe', '2024-10-20', 'This paper explores novel techniques for reducing latency in large language model inference within agentic frameworks.', 'AI Journal', 'Published', 5.8);
  stmt.run(uuidv4(), resConn.id, 'Decentralized Data Management in Isolated Systems', 'A. Magaya', '2024-11-05', 'A framework for synchronizing data across air-gapped or isolated cloud environments using secure webhooks.', 'SysTech Review', 'Under Review', 4.2);
}

console.log('Successfully seeded metrics.');
db.close();
