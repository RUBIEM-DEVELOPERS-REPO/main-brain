'use client';

import React, { useState, useEffect } from 'react';

export default function AdminPage() {
  const [adminData, setAdminData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/metrics?category=Admin')
      .then(res => res.json())
      .then(data => {
        setAdminData(data);
        setLoading(false);
      })
      .catch(err => console.error('Failed to fetch admin metrics', err));
  }, []);

  const latest = adminData[0] || { 
    open_tasks: 0, 
    completed_tasks: 0, 
    overdue_tasks: 0, 
    pending_approvals: 0,
    internal_requests: 0
  };

  return (
    <div style={{ animation: 'fadeIn 0.8s ease-out', maxWidth: '1400px', margin: '0 auto' }}>
      <header style={{ marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>Admin Operations</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Monitor internal tasks, approval bottlenecks, and workflow efficiency.</p>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem', marginBottom: '2.5rem' }}>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>Open Tasks</span>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, margin: '0.5rem 0' }}>{latest.open_tasks}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--secondary)' }}>Active now</div>
        </div>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>Overdue</span>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, margin: '0.5rem 0', color: 'var(--accent)' }}>{latest.overdue_tasks}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Requires attention</div>
        </div>
        <div className="card" style={{ background: 'var(--primary)', color: 'white' }}>
          <span style={{ opacity: 0.8, fontSize: '0.75rem', textTransform: 'uppercase' }}>Pending Approvals</span>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, margin: '0.5rem 0' }}>{latest.pending_approvals}</div>
          <div style={{ fontSize: '0.875rem', opacity: 0.8 }}>Awaiting signature</div>
        </div>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>Internal Requests</span>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, margin: '0.5rem 0' }}>{latest.internal_requests}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Ticket volume</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: '2rem' }}>
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Operational Velocity</h3>
          <div style={{ height: '300px', display: 'flex', alignItems: 'flex-end', gap: '1rem', padding: '1rem 0' }}>
            {adminData.slice(0, 7).reverse().map((day: any, i: number) => (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '100%', background: 'var(--secondary)', height: `${(day.completed_tasks / (day.open_tasks || 1)) * 100}%`, borderRadius: '4px', opacity: 0.6 }}></div>
                <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{day.metric_date ? day.metric_date.split('-')[2] : '--'}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: '1rem', fontSize: '0.875rem', color: 'var(--text-muted)', textAlign: 'center' }}>
            Completion rate over the last 7 reporting cycles
          </div>
        </div>

        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Priority Action Stream</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', borderLeft: '4px solid var(--accent)' }}>
              <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>System Maintenance Required</div>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Overdue for 48 hours • Admin Node</div>
            </div>
            <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', borderLeft: '4px solid var(--primary)' }}>
              <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>New Vendor Onboarding</div>
              <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>Awaiting Approval • Finance Dept</div>
            </div>
            <button className="btn" style={{ background: 'rgba(255,255,255,0.05)', width: '100%', justifyContent: 'center' }}>View All Operations</button>
          </div>
        </div>
      </div>
    </div>
  );
}
