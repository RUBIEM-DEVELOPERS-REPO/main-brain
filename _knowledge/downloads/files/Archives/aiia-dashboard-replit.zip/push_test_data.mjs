const BASE_URL = 'http://localhost:3000/api/public/dashboard';

async function pushData() {
  console.log('--- SIMULATING EXTERNAL DATA PUSH ---');
  
  const payload = {
    date: new Date().toISOString().split('T')[0],
    revenue: 12500.50,
    expenses: 8400.25,
    cash_balance: 45200.00
  };

  try {
    const res = await fetch(BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    console.log('Push Result:', result);
  } catch (e) {
    console.error('Push failed (Is the dashboard server running?):', e.message);
  }
}

pushData();
