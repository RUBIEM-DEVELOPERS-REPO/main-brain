'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const navItems = [
  { label: 'Overview', href: '/', icon: '📊' },
  { label: 'Finance', href: '/finance', icon: '💰' },
  { label: 'Marketing & Social', href: '/marketing', icon: '🎯' },
  { label: 'Research', href: '/research', icon: '📚' },
  { label: 'Admin Ops', href: '/admin', icon: '⚙️' },
  { label: 'Connections', href: '/connections', icon: '🔌' },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [theme, setTheme] = useState('dark');
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <>
      {/* Mobile Toggle — visible via globals.css @media rule */}
      <button 
        className="btn glass mobile-toggle" 
        onClick={() => setIsOpen(!isOpen)}
        id="mobile-menu-toggle"
        aria-label="Toggle navigation"
      >
        {isOpen ? '✕' : '☰'}
      </button>

      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div style={{ marginBottom: '2.5rem' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 900, color: '#fbbf24', letterSpacing: '-0.02em' }}>
            Aiia SIGNAL
          </h2>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>AIIA Command Center</div>
        </div>

        <nav style={{ flex: 1 }}>
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setIsOpen(false)}
              className={`nav-link ${pathname === item.href ? 'active' : ''}`}
            >
              <span style={{ fontSize: '1.2rem' }}>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div style={{ marginTop: 'auto', paddingTop: '2rem', borderTop: '1px solid var(--card-border)', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <button 
            className="btn glass" 
            onClick={toggleTheme}
            style={{ width: '100%', justifyContent: 'flex-start', fontSize: '0.875rem' }}
          >
            <span>{theme === 'dark' ? '☀️' : '🌙'}</span>
            <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
          <div className="nav-link" style={{ marginBottom: 0 }}>
            <span>👤</span>
            <span>Arthur Magaya</span>
          </div>
        </div>
      </aside>
    </>
  );
}
