---
name: admin-operations-monitoring
description: collect and analyze administrative and operational data for the consolidated company dashboard. Use when tracking tasks, approvals, requests, internal processes, workload, overdue items, compliance reminders, or admin team activity.
---

# Admin Operations Monitoring

## Goal
Monitor admin operations and surface issues that need attention.

## Workflow
1. Identify active admin systems or databases.
2. Collect operational data:
   - Open tasks
   - Completed tasks
   - Overdue tasks
   - Pending approvals
   - Internal requests
   - Reminders
3. Group items by category, owner, and urgency.
4. Detect overdue or blocked work.
5. Generate dashboard highlights and alerts.

## Output Format
Return:
- Admin highlights
- Pending approvals
- Overdue items
- Workload summary
- Risks or blockers
- Recommended actions
