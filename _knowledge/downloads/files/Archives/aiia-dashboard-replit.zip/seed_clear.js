const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'dashboard.db');
const db = new Database(dbPath);

console.log('--- Database Cleanup ---');

const tables = [
  'financial_metrics',
  'marketing_metrics',
  'research_publications',
  'admin_metrics',
  'sync_jobs'
];

try {
  db.transaction(() => {
    for (const table of tables) {
      db.prepare(`DELETE FROM ${table}`).run();
      console.log(`Wiped table: ${table}`);
    }
  })();
  console.log('Cleanup successful.');
} catch (err) {
  console.error('Cleanup failed:', err.message);
} finally {
  db.close();
}
