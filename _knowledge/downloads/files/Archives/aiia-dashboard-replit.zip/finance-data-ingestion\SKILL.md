---
name: finance-data-ingestion
description: collect, validate, and normalize financial data from connected finance systems, APIs, databases, spreadsheets, or custom internal systems for the consolidated company dashboard. Use when syncing revenue, expenses, invoices, payments, cash balances, receivables, payables, or other finance metrics.
---

# Finance Data Ingestion

## Goal
Collect financial data from approved finance connections and prepare it for the central dashboard database.

## Workflow
1. Identify the active finance connection.
2. Confirm connection type: API, database, spreadsheet, or custom source.
3. Collect relevant financial records:
   - Revenue
   - Expenses
   - Invoices
   - Payments
   - Cash balances
   - Receivables
   - Payables
4. Validate required fields:
   - Date
   - Amount
   - Currency
   - Account/category
   - Source reference
5. Normalize data into dashboard-ready metrics.
6. Flag missing, duplicate, or inconsistent records.
7. Return a sync summary with record counts, errors, and warnings.

## Output Format
Return:
- Sync status
- Source connection
- Date range
- Records processed
- Metrics created
- Errors
- Warnings
- Recommended follow-up actions
