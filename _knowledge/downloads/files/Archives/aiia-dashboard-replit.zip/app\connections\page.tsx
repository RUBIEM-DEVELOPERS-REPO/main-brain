'use client';

import React, { useState, useEffect } from 'react';

const ConnectionCard = ({ conn, onSync, onTest, onDelete }: { conn: any, onSync: (id: string) => void, onTest: (url: string) => void, onDelete: (id: string) => void }) => {
  const config = JSON.parse(conn.config_json);
  const [lastSync, setLastSync] = useState<string>('Never');

  useEffect(() => {
    if (conn.last_sync_at) {
      setLastSync(new Date(conn.last_sync_at).toLocaleString());
    }
  }, [conn.last_sync_at]);
  
  return (
    <div className="card animate-fade-in" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ flex: 1 }}>
        <h3 style={{ fontSize: '1.125rem', marginBottom: '0.25rem' }}>{conn.name}</h3>
        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>{conn.type} • {conn.category}</span>
          <span style={{ height: '4px', width: '4px', borderRadius: '50%', background: 'var(--text-muted)' }}></span>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            Last sync: {lastSync}
          </span>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>• {config.url}</span>
        </div>
        {conn.status === 'Error' && (
          <div style={{ marginTop: '0.5rem', fontSize: '0.75rem', color: 'var(--danger)', background: 'rgba(239, 68, 68, 0.05)', padding: '0.4rem 0.8rem', borderRadius: '4px', display: 'inline-block' }}>
            ⚠️ Error: {conn.error_message || 'API responded with an invalid format (404/500).'}
          </div>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
        <span style={{ 
          fontSize: '0.75rem', 
          padding: '0.25rem 0.75rem', 
          borderRadius: '20px', 
          background: conn.status === 'Active' ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)',
          color: conn.status === 'Active' ? 'var(--secondary)' : 'var(--danger)',
          fontWeight: 600
        }}>
          {conn.status}
        </span>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button className="btn" title="Test Connection" onClick={() => onTest(config.url)} style={{ padding: '0.5rem', background: 'var(--glass-bg)' }}>🔌</button>
          <button className="btn" title="Sync Now" onClick={() => onSync(conn.id)} style={{ padding: '0.5rem', background: 'var(--glass-bg)' }}>🔄</button>
          <button className="btn" title="Delete Connection" onClick={() => onDelete(conn.id)} style={{ padding: '0.5rem', background: 'rgba(239, 68, 68, 0.1)', color: 'var(--danger)' }}>🗑️</button>
        </div>
      </div>
    </div>
  );
};

export default function ConnectionsPage() {
  const [connections, setConnections] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncingAll, setSyncingAll] = useState(false);
  
  // Form state
  const [name, setName] = useState('');
  const [type, setType] = useState('API');
  const [category, setCategory] = useState('Finance');
  const [url, setUrl] = useState('');
  const [secret, setSecret] = useState('');

  const fetchConnections = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/connections');
      const data = await res.json();
      setConnections(data);
    } catch (e) {
      console.error('Failed to fetch connections', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConnections();
  }, []);

  const handleSyncAll = async () => {
    setSyncingAll(true);
    try {
      await fetch('/api/public/sync', { method: 'POST' });
      alert('Global sync triggered!');
      fetchConnections();
    } catch (e) {
      alert('Global sync failed');
    } finally {
      setSyncingAll(false);
    }
  };

  const handleAdd = async () => {
    try {
      await fetch('/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, type, category, config: { url }, secret_reference: secret })
      });
      setShowModal(false);
      fetchConnections();
      setName(''); setUrl(''); setSecret('');
    } catch (e) {
      alert('Failed to add connection');
    }
  };

  const handleTest = async (testUrl: string) => {
    alert(`Testing connection to: ${testUrl}...`);
    try {
      const res = await fetch('/api/connections/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: testUrl })
      });
      const data = await res.json();
      alert(data.message);
    } catch (e) {
      alert('Test failed');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure?')) return;
    try {
      await fetch(`/api/connections?id=${id}`, { method: 'DELETE' });
      fetchConnections();
    } catch (e) {
      alert('Delete failed');
    }
  };

  const handleSync = async (id: string) => {
    alert('Syncing data...');
    try {
      const res = await fetch('/api/connections/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ connectionId: id })
      });
      const data = await res.json();
      if (data.success) {
        alert(`Sync complete! Processed ${data.recordsProcessed} records.`);
        fetchConnections();
      } else {
        alert(`Sync failed: ${data.error}`);
      }
    } catch (e) {
      alert('Sync failed');
    }
  };

  return (
    <div style={{ animation: 'fadeIn 0.8s ease-out', maxWidth: '1400px', margin: '0 auto' }}>
      <header style={{ marginBottom: '3rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>System Nexus</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Manage API connectors, health status, and data ingestion protocols.</p>
        </div>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <button className="btn" onClick={handleSyncAll} disabled={syncingAll} style={{ background: 'rgba(255,255,255,0.03)' }}>
            {syncingAll ? 'Syncing...' : '🔄 Sync All Nodes'}
          </button>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            + Register Node
          </button>
        </div>
      </header>

      {loading ? (
        <div style={{ padding: '4rem', textAlign: 'center' }}>Probing connection states...</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {connections.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '4rem', borderStyle: 'dashed' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem', opacity: 0.3 }}>🔌</div>
              <p style={{ color: 'var(--text-muted)' }}>No active connectors found. Register your first node to begin ingestion.</p>
            </div>
          ) : (
            connections.map((conn: any) => (
              <ConnectionCard key={conn.id} conn={conn} onSync={handleSync} onTest={handleTest} onDelete={handleDelete} />
            ))
          )}
        </div>
      )}

      {showModal && (
        <div style={{ 
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, 
          background: 'rgba(0,0,0,0.85)', display: 'flex', justifyContent: 'center', 
          alignItems: 'center', zIndex: 1000, backdropFilter: 'blur(8px)' 
        }}>
          <div className="card" style={{ width: '100%', maxWidth: '500px', padding: '3rem', border: '1px solid rgba(255,255,255,0.1)' }}>
            <h2 style={{ marginBottom: '2rem', fontSize: '1.75rem' }}>Register API Node</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', marginBottom: '0.5rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Node Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  style={{ width: '100%', padding: '1rem', borderRadius: '12px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--card-border)', color: 'white' }} 
                  placeholder="Production Finance Node" />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.75rem', marginBottom: '0.5rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Category</label>
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    style={{ width: '100%', padding: '1rem', borderRadius: '12px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--card-border)', color: 'white' }}>
                    <option>Finance</option>
                    <option>Marketing</option>
                    <option>Social</option>
                    <option>Admin</option>
                    <option>Research</option>
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.75rem', marginBottom: '0.5rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Type</label>
                  <input value="API" disabled style={{ width: '100%', padding: '1rem', borderRadius: '12px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--card-border)', color: 'rgba(255,255,255,0.3)' }} />
                </div>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', marginBottom: '0.5rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Endpoint URL</label>
                <input 
                  type="text" 
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  style={{ width: '100%', padding: '1rem', borderRadius: '12px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--card-border)', color: 'white' }} 
                  placeholder="https://node-1.aiia.com/v1/metrics" />
              </div>
              <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                <button className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }} onClick={handleAdd}>Save Node</button>
                <button className="btn" style={{ flex: 1, justifyContent: 'center', background: 'rgba(255,255,255,0.05)' }} onClick={() => setShowModal(false)}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
