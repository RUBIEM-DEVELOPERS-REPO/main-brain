import Database from 'better-sqlite3';
const db = new Database('./dashboard.db');

const failures = db.prepare(`
  SELECT c.name, c.category, j.error_message, j.started_at 
  FROM sync_jobs j
  JOIN connections c ON j.connection_id = c.id
  WHERE j.status = 'failed'
  ORDER BY j.started_at DESC
  LIMIT 10
`).all();

console.log('--- SYNC FAILURES REPORT ---');
if (failures.length === 0) {
  console.log('No recent failures found in sync_jobs table.');
} else {
  failures.forEach(f => {
    console.log(`[${f.started_at}] ${f.name} (${f.category}): ${f.error_message}`);
  });
}
