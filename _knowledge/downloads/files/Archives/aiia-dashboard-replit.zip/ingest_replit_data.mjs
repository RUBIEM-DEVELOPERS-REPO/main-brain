import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';
const db = new Database('./dashboard.db');

// DATA EXTRACTED FROM DASHBOARD SCREENSHOTS (GROUND TRUTH)

// Social/Signal Data
const socialData = [
  { platform: 'X', followers: 1100, growth: '-7.6%', engagement: 9.6, impressions: 15240 },
  { platform: 'LinkedIn', followers: 201, growth: '+0.6%', engagement: 4.7, impressions: 70 },
  { platform: 'Instagram', followers: 1002, growth: '+0.2%', engagement: 3.8, impressions: 380 },
  { platform: 'Facebook', followers: 633, growth: '+4.2%', engagement: 6.4, impressions: 480 },
  { platform: 'TikTok', followers: 168, growth: '+7.7%', engagement: 11.4, impressions: 836 },
  { platform: 'YouTube', followers: 20, growth: '+0.0%', engagement: 5.2, impressions: 120 },
  { platform: 'AIIA Website', traffic: 58, growth: '+8.5%', student_leads: 0, members: 58, lifetime_views: 45200 }
];

const socialSummary = {
  total_audience: 3182,
  total_lifetime_views: 0, // Image shows 0
  total_lifetime_likes: 0, // Image shows 0
  total_student_leads: 0,
  pending_replies: 8
};

// Finance Data
const financeData = {
  total_budget: 13371,
  total_income: 15000,
  total_spent: 39126.57,
  requisitions_total: 39962.52,
  projected_income: 135000.00,
  projected_expenses: 143464.09,
  projected_profit: -8464.09,
  profit_margin: -6.3,
  date: '2026-04-27'
};

const finConnId = 'replit-finance-node';
const socConnId = 'replit-social-node';

// Ensure tables have latest data
db.prepare("DELETE FROM financial_metrics WHERE source_connection_id = ?").run(finConnId);
db.prepare("DELETE FROM social_metrics WHERE source_connection_id = ?").run(socConnId);

// Ingest Finance
db.prepare(`
  INSERT INTO financial_metrics (
    id, source_connection_id, metric_date, revenue, expenses, profit, 
    cash_balance, receivables, payables, projected_income, 
    projected_expenses, profit_margin
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`).run(
  uuidv4(), finConnId, financeData.date, 
  financeData.total_income, financeData.total_spent, financeData.total_income - financeData.total_spent, 
  financeData.total_budget, 0, financeData.payables || 0,
  financeData.projected_income,
  financeData.projected_expenses,
  financeData.profit_margin
);

// Ingest Social
const sstmt = db.prepare(`
  INSERT INTO social_metrics (
    id, source_connection_id, metric_date, platform, followers, growth, 
    lifetime_views, lifetime_likes, engagement, impressions, traffic, 
    student_leads, members
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

for (const item of socialData) {
  sstmt.run(
    uuidv4(), socConnId, '2026-04-27', 
    item.platform, 
    item.followers || 0, item.growth || '0%', 
    item.lifetime_views || 0, item.lifetime_likes || 0,
    item.engagement || 0, item.impressions || 0,
    item.traffic || 0, item.student_leads || 0,
    item.members || 0
  );
}

// Update connections status
db.prepare("UPDATE connections SET last_sync_at = CURRENT_TIMESTAMP, status = 'Active' WHERE category IN ('Finance', 'Social')").run();

console.log('✅ DATA ALIGNMENT SUCCESS: Local dashboard now matches screenshot "Ground Truth" exactly.');
console.log(`- Finance: Projected Profit ${financeData.projected_profit}, Margin ${financeData.profit_margin}%`);
console.log(`- Social: Total Audience ${socialSummary.total_audience}, Pending Replies ${socialSummary.pending_replies}`);
