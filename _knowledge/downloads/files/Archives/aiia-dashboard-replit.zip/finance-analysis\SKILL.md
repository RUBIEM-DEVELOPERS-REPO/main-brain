---
name: finance-analysis
description: analyze financial metrics for the consolidated company dashboard. Use when generating revenue summaries, expense analysis, profit trends, cash flow highlights, invoice status, budget comparisons, financial risks, or executive finance insights.
---

# Finance Analysis

## Goal
Analyze normalized financial data and produce useful business insights.

## Workflow
1. Review the selected financial reporting period.
2. Compare current period against previous period.
3. Identify key movements in:
   - Revenue
   - Expenses
   - Profit
   - Cash balance
   - Receivables
   - Payables
4. Detect unusual changes or risks.
5. Produce concise dashboard highlights.

## Output Format
Return:
- Financial highlights
- Positive movements
- Risks or concerns
- Unusual changes
- Recommended actions
