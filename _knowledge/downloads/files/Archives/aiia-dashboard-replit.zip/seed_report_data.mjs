import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';
const db = new Database('./dashboard.db');

const connId = uuidv4();

db.exec(`
  INSERT OR IGNORE INTO connections (id, name, type, category, status)
  VALUES ('${connId}', 'Sample Data Source', 'API', 'Finance', 'Active');

  -- Finance Data
  INSERT OR REPLACE INTO financial_metrics (id, source_connection_id, metric_date, revenue, expenses, profit, cash_balance, receivables, payables)
  VALUES (
    '${uuidv4()}', '${connId}', '2026-04-24', 15000.00, 8000.00, 7000.00, 45000.00, 12000.00, 5000.00
  );

  -- Marketing Data
  INSERT OR REPLACE INTO marketing_metrics (id, source_connection_id, metric_date, channel, campaign_name, spend, impressions, clicks, leads, conversions)
  VALUES (
    '${uuidv4()}', '${connId}', '2026-04-24', 'Google Ads', 'Spring Launch', 2500.00, 50000, 1200, 150, 45
  );

  -- Social Data
  INSERT OR REPLACE INTO social_metrics (id, source_connection_id, metric_date, platform, followers, posts, impressions, engagement, clicks)
  VALUES (
    '${uuidv4()}', '${connId}', '2026-04-24', 'LinkedIn', 12500, 5, 8000, 450, 120
  );

  -- Research Data
  INSERT OR REPLACE INTO research_publications (id, source_connection_id, title, authors, publication_date, summary, journal, status, impact_factor)
  VALUES (
    '${uuidv4()}', '${connId}', 'AI In Modern Finance', 'Arthur Magaya', '2026-04-24', 'A study on AI integration.', 'FinTech Weekly', 'Published', 8.5
  );
`);

console.log('Seed data successfully inserted for report generation.');
