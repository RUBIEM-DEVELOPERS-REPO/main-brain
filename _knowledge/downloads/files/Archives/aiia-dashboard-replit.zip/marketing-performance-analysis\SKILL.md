---
name: marketing-performance-analysis
description: analyze marketing and campaign performance for the consolidated company dashboard. Use when generating insights about leads, ad spend, conversion rates, campaign performance, customer acquisition cost, website traffic, marketing ROI, or underperforming channels.
---

# Marketing Performance Analysis

## Goal
Analyze marketing performance and identify what is working, what is wasting spend, and what needs attention.

## Workflow
1. Review selected reporting period.
2. Compare performance by channel and campaign.
3. Identify top-performing campaigns.
4. Identify weak or expensive campaigns.
5. Calculate important metrics:
   - Cost per lead
   - Conversion rate
   - Return on ad spend, where revenue data is available
   - Click-through rate
6. Highlight trends and recommended actions.

## Output Format
Return:
- Marketing highlights
- Best-performing channels
- Underperforming channels
- Spend concerns
- Growth opportunities
- Recommended actions
