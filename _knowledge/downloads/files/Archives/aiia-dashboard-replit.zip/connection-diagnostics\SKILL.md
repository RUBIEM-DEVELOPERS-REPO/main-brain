---
name: connection-diagnostics
description: test, troubleshoot, and summarize API, database, file, and custom system connections used by the consolidated company dashboard. Use when adding a new connection, validating credentials, checking failed syncs, reviewing connection health, or diagnosing broken integrations.
---

# Connection Diagnostics

## Goal
Help verify and troubleshoot dashboard system connections.

## Workflow
1. Identify the connection type.
2. Check required configuration fields.
3. Test authentication.
4. Test basic data access.
5. Check permissions.
6. Review recent sync logs.
7. Explain the failure or confirm the connection is healthy.

## Output Format
Return:
- Connection status
- Authentication result
- Data access result
- Permission issues
- Error explanation
- Recommended fix
