'use client';

import React, { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line
} from 'recharts';

export default function FinancePage() {
  const [finance, setFinance] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = () => {
      fetch('/api/metrics?category=Finance')
        .then(res => res.json())
        .then(data => {
          setFinance(data);
          setLoading(false);
        })
        .catch(err => console.error('Failed to fetch finance metrics', err));
    };

    fetchData();
    const interval = setInterval(fetchData, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, []);

  if (loading || !finance) return <div style={{ padding: '2rem' }}>Loading Financial Intelligence...</div>;

  const { latest, metrics, receipts, requisitions } = finance;

  return (
    <div style={{ animation: 'fadeIn 0.8s ease-out', maxWidth: '1400px', margin: '0 auto' }}>
      <header style={{ marginBottom: '3rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>Financial Intelligence</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Cash flow analysis, revenue forecasts, and operational expense tracking.</p>
          <a href="https://AiiaFinaceFlow.replit.app" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--primary)', fontSize: '0.875rem', textDecoration: 'none', marginTop: '0.5rem', display: 'inline-block' }}>
            🔗 Open Source System (Replit)
          </a>
        </div>
        <div style={{ padding: '1rem 1.5rem', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid var(--card-border)' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Last Updated</span>
          <div style={{ fontWeight: 600 }}>{new Date().toLocaleDateString()}</div>
        </div>
      </header>

      {/* Finance KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem', marginBottom: '2.5rem' }}>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.8125rem' }}>Total Budget</span>
          <div style={{ fontSize: '2.2rem', fontWeight: 700, margin: '0.5rem 0' }}>${(latest.cash_balance || 0).toLocaleString()}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Operational budget</div>
        </div>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.8125rem' }}>Total Income</span>
          <div style={{ fontSize: '2.2rem', fontWeight: 700, margin: '0.5rem 0', color: 'var(--secondary)' }}>${(latest.revenue || 0).toLocaleString()}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Year-to-date income</div>
        </div>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.8125rem' }}>Total Spent</span>
          <div style={{ fontSize: '2.2rem', fontWeight: 700, margin: '0.5rem 0', color: 'var(--accent)' }}>${(latest.expenses || 0).toLocaleString()}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Confirmed outflows</div>
        </div>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.8125rem' }}>Calculated Revenue</span>
          <div style={{ fontSize: '2.2rem', fontWeight: 700, margin: '0.5rem 0', color: (latest.revenue - latest.expenses) >= 0 ? 'var(--secondary)' : 'var(--danger)' }}>
            ${((latest.revenue || 0) - (latest.expenses || 0)).toLocaleString()}
          </div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Income - Spent</div>
        </div>
      </div>

      {/* 2026 Annual Profit Forecast */}
      <div className="card" style={{ marginBottom: '2.5rem', background: 'rgba(255,255,255,0.01)', border: '1px solid rgba(255,255,255,0.1)' }}>
        <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          📈 2026 Annual Profit Forecast
        </h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '2rem' }}>Based on year-to-date actuals and projected trends</p>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '2rem' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Projected Income</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#10b981' }}>${(latest.projected_income || 0).toLocaleString()}.00</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Projected Expenses</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ef4444' }}>${(latest.projected_expenses || 0).toLocaleString()}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Projected Profit</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ef4444' }}>-${Math.abs((latest.projected_income || 0) - (latest.projected_expenses || 0)).toLocaleString()}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>Profit Margin</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ef4444' }}>{latest.profit_margin || 0}%</div>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2.5rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2.5rem' }}>
          {/* Main Chart */}
          <div className="card" style={{ height: '450px' }}>
            <h3 style={{ marginBottom: '2rem' }}>Revenue vs Expenses Trajectory</h3>
            <div style={{ flex: 1, height: '350px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={metrics.slice().reverse()} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
                  <XAxis dataKey="metric_date" stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ background: 'var(--card-bg)', border: '1px solid var(--card-border)', borderRadius: '12px' }} />
                  <Legend />
                  <Line name="Revenue" type="monotone" dataKey="revenue" stroke="var(--primary)" strokeWidth={3} dot={false} />
                  <Line name="Expenses" type="monotone" dataKey="expenses" stroke="var(--accent)" strokeWidth={3} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Requisitions Table */}
          <div className="card">
            <h3 style={{ marginBottom: '1.5rem' }}>Recent Requisitions</h3>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--card-border)' }}>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Title</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Amount</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Category</th>
                    <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {requisitions.map((req: any) => (
                    <tr key={req.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.02)' }}>
                      <td style={{ padding: '1rem', fontWeight: 600 }}>{req.title}</td>
                      <td style={{ padding: '1rem' }}>${req.amount.toLocaleString()}</td>
                      <td style={{ padding: '1rem' }}><span style={{ padding: '0.25rem 0.5rem', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', fontSize: '0.75rem' }}>{req.category}</span></td>
                      <td style={{ padding: '1rem' }}>
                        <span style={{ 
                          color: req.status === 'Approved' ? 'var(--secondary)' : req.status === 'Pending' ? '#f59e0b' : 'var(--accent)',
                          fontSize: '0.875rem',
                          fontWeight: 600
                        }}>● {req.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* Ingested Receipts */}
          <div className="card">
            <h3 style={{ marginBottom: '1.5rem' }}>Recent Receipts</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {receipts.map((r: any) => (
                <div key={r.id} style={{ padding: '1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                    <span style={{ fontWeight: 600 }}>{r.vendor}</span>
                    <span style={{ color: 'var(--accent)', fontWeight: 700 }}>-${r.amount.toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    <span>{r.category}</span>
                    <span>{r.receipt_date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="card" style={{ borderStyle: 'dashed' }}>
            <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>Record Transaction</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <button className="btn btn-primary" style={{ justifyContent: 'center' }}>Log Revenue</button>
              <button className="btn btn-secondary" style={{ justifyContent: 'center', background: 'var(--accent)' }}>Log Expense</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
