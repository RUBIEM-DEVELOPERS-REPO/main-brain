import Database from 'better-sqlite3';
const db = new Database('./dashboard.db');

console.log('--- GLOBAL API DATA INGESTION REPORT ---');
console.log('Generated at:', new Date().toLocaleString());
console.log('');

const categories = [
  { table: 'financial_metrics', label: 'FINANCE', fields: 'metric_date, revenue, expenses, profit' },
  { table: 'marketing_metrics', label: 'MARKETING', fields: 'metric_date, channel, campaign_name, leads' },
  { table: 'social_metrics', label: 'SOCIAL', fields: 'metric_date, platform, followers, engagement' },
  { table: 'admin_metrics', label: 'ADMIN', fields: 'metric_date, open_tasks, pending_approvals' },
  { table: 'research_publications', label: 'RESEARCH', fields: 'title, publication_date, impact_factor' }
];

categories.forEach(cat => {
  try {
    const count = db.prepare(`SELECT count(*) as c FROM ${cat.table}`).get().c;
    const latest = db.prepare(`SELECT ${cat.fields} FROM ${cat.table} ORDER BY created_at DESC LIMIT 3`).all();
    
    console.log(`[${cat.label}] Total Records: ${count}`);
    if (latest.length > 0) {
      console.table(latest);
    } else {
      console.log('No data yet.');
    }
    console.log('');
  } catch (e) {
    console.log(`[${cat.label}] Table error or empty: ${e.message}`);
  }
});

const jobs = db.prepare(`
  SELECT c.name, j.status, j.records_processed, j.error_message, j.completed_at 
  FROM sync_jobs j
  JOIN connections c ON j.connection_id = c.id
  ORDER BY j.completed_at DESC
  LIMIT 5
`).all();

console.log('--- LATEST SYNC ACTIVITY ---');
console.table(jobs);
