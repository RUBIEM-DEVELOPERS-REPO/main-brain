'use client';

import React, { useState, useEffect } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell
} from 'recharts';

const MetricCard = ({ label, value, trend, trendValue, icon }: { label: string, value: string, trend?: 'up' | 'down', trendValue?: string, icon?: string }) => (
  <div className="card metric-card animate-fade-in" style={{ position: 'relative', overflow: 'hidden' }}>
    <div style={{ position: 'absolute', top: '-10px', right: '-10px', fontSize: '4rem', opacity: 0.03, pointerEvents: 'none' }}>{icon}</div>
    <span className="metric-label" style={{ letterSpacing: '0.05em', textTransform: 'uppercase', fontSize: '0.75rem' }}>{label}</span>
    <span className="metric-value" style={{ fontSize: '2rem', display: 'block', margin: '0.5rem 0' }}>{value}</span>
    {trend && (
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <span className={`trend-${trend}`} style={{ fontSize: '0.875rem', fontWeight: 600, padding: '0.2rem 0.5rem', background: `rgba(${trend === 'up' ? '16, 185, 129' : '239, 68, 68'}, 0.1)`, borderRadius: '4px' }}>
          {trend === 'up' ? '↑' : '↓'} {trendValue}
        </span>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>vs last period</span>
      </div>
    )}
  </div>
);

export default function Home() {
  const [metrics, setMetrics] = useState({
    totalRevenue: 0,
    totalProfit: 0,
    totalFollowers: 0,
    totalApprovals: 0
  });
  const [trendData, setTrendData] = useState([]);
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = () => {
      Promise.all([
        fetch('/api/metrics?category=Summary').then(res => res.json()),
        fetch('/api/metrics?category=Trends').then(res => res.json()),
        fetch('/api/connections').then(res => res.json())
      ]).then(([sum, trnd, conns]) => {
        setMetrics(sum);
        setTrendData(trnd.slice().reverse());
        setConnections(conns);
        setLoading(false);
      }).catch(err => console.error('Dashboard data failed', err));
    };

    fetchData();
    const interval = setInterval(fetchData, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ animation: 'fadeIn 0.8s ease-out', maxWidth: '1400px', margin: '0 auto' }}>
      <header style={{ marginBottom: '3rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>Command Center</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Global operations overview and real-time system intelligence.</p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>System Status</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--secondary)', fontWeight: 600 }}>
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--secondary)', boxShadow: '0 0 10px var(--secondary)' }}></span>
            Operational
          </div>
        </div>
      </header>

      {/* Main Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.5rem', marginBottom: '2.5rem' }}>
        <MetricCard label="Calculated Revenue" value={`$${metrics.totalRevenue.toLocaleString()}`} icon="💰" />
        <MetricCard label="Net Profit" value={`$${metrics.totalProfit.toLocaleString()}`} icon="📈" />
        <MetricCard label="Social Reach" value={metrics.totalFollowers.toLocaleString()} icon="📱" />
        <MetricCard label="Active Tasks" value={metrics.totalApprovals.toLocaleString()} icon="⚡" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
        {/* Main Chart Area */}
        <div className="card" style={{ height: '500px', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.25rem' }}>Performance Velocity</h3>
            <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Historical Trend</span>
          </div>
          <div style={{ flex: 1 }}>
            {trendData.length === 0 ? (
              <div style={{ height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', color: 'var(--text-muted)', background: 'rgba(255,255,255,0.01)', borderRadius: '12px' }}>
                No trend data available. Perform a sync to populate.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
                  <XAxis dataKey="name" stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ background: 'var(--card-bg)', border: '1px solid var(--card-border)', borderRadius: '12px', backdropFilter: 'blur(10px)' }}
                    itemStyle={{ color: 'var(--foreground)' }}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="var(--primary)" fillOpacity={1} fill="url(#colorRev)" strokeWidth={4} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Connections & Alerts */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div className="card" style={{ flex: 1 }}>
            <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>Active Connectors</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {connections.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)', background: 'rgba(255,255,255,0.02)', borderRadius: '12px' }}>
                  No systems connected.
                </div>
              ) : (
                connections.map((conn: any, i: number) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ 
                      width: '40px', height: '40px', borderRadius: '10px', 
                      background: 'rgba(255,255,255,0.05)', display: 'flex', 
                      justifyContent: 'center', alignItems: 'center', fontSize: '1.2rem' 
                    }}>
                      {conn.category === 'Finance' ? '💰' : conn.category === 'Marketing' ? '📢' : '🔬'}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.9375rem', fontWeight: 600 }}>{conn.name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{conn.status} • {conn.category}</div>
                    </div>
                    <div style={{ 
                      width: '8px', height: '8px', borderRadius: '50%', 
                      background: conn.status === 'Active' ? 'var(--secondary)' : (conn.status === 'Error' ? 'var(--danger)' : 'var(--accent)')
                    }}></div>
                  </div>
                ))
              )}
            </div>
            <button 
              className="btn" 
              style={{ marginTop: '2rem', width: '100%', background: 'rgba(255,255,255,0.05)', justifyContent: 'center' }}
              onClick={() => window.location.href = '/connections'}
            >
              System Configuration
            </button>
          </div>

          <div className="card" style={{ background: 'rgba(255,255,255,0.02)' }}>
            <h3 style={{ marginBottom: '1rem', fontSize: '1.1rem' }}>System Health</h3>
            <p style={{ fontSize: '0.875rem', lineHeight: '1.6', color: 'var(--text-muted)' }}>
              {connections.length > 0 
                ? `Monitoring ${connections.length} active integrations. All systems currently reporting within normal latency parameters.`
                : 'No active integrations monitored. Connect your Replit systems to begin real-time analysis.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
