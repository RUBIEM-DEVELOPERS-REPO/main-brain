# Database Schema

The system uses a relational schema stored in SQLite.

## Core Tables

### connections
Stores external system configurations.
- `id` (TEXT, PK): Unique identifier.
- `name` (TEXT): Display name.
- `type` (TEXT): api, database, file.
- `category` (TEXT): finance, marketing, admin, social, custom.
- `config_json` (TEXT): JSON string of connection parameters.
- `status` (TEXT): active, inactive, error.
- `last_sync_at` (DATETIME): Last successful sync.

### sync_jobs
Tracks data collection tasks.
- `id` (TEXT, PK)
- `connection_id` (TEXT, FK): Reference to `connections`.
- `status` (TEXT): pending, running, success, failed.
- `records_processed` (INTEGER)
- `error_message` (TEXT)

### financial_metrics
- `metric_date` (DATE)
- `revenue` (REAL)
- `expenses` (REAL)
- `profit` (REAL)
- `cash_balance` (REAL)

### marketing_metrics
- `metric_date` (DATE)
- `channel` (TEXT)
- `campaign_name` (TEXT)
- `spend` (REAL)
- `leads` (INTEGER)
- `conversions` (INTEGER)

### social_metrics
- `metric_date` (DATE)
- `platform` (TEXT)
- `followers` (INTEGER)
- `engagement` (INTEGER)

### admin_metrics
- `metric_date` (DATE)
- `open_tasks` (INTEGER)
- `completed_tasks` (INTEGER)
- `pending_approvals` (INTEGER)

### agent_insights
- `insight_type` (TEXT)
- `category` (TEXT)
- `title` (TEXT)
- `summary` (TEXT)
- `severity` (TEXT): info, warning, critical.
