# Technical Architecture

## Overview

The system follows a modern web architecture with a focus on modularity and agent-driven insights. It consists of a Next.js frontend, an API layer, a central database, and an agent skill layer.

## Components

### 1. Frontend (Next.js)
The user interface is built with Next.js 14 using the App Router. It uses a premium dark theme implemented with Vanilla CSS to ensure high performance and a custom look and feel. Data visualization is handled by Recharts.

### 2. API Layer (Next.js API Routes)
The backend logic is handled via Next.js API routes (to be implemented in the next phase). This layer manages authentication, system connections, and data retrieval for the dashboard.

### 3. Database Layer (SQLite)
A local SQLite database (`dashboard.db`) is used to store:
- Normalized metrics (finance, marketing, social, admin)
- Connection configurations
- Sync job logs
- Agent-generated insights

### 4. Agent Layer (Skills)
Repeatable workflows are defined as "Skills" in the `skills/` directory. These markdown files provide the logic for data ingestion, analysis, and alerting, allowing agents to process data consistently.

## Data Flow

1. **Ingestion**: Agents use the `finance-data-ingestion` or `marketing-data-ingestion` skills to pull data from connected systems via APIs or database queries.
2. **Normalization**: Collected data is cleaned and stored in the central `dashboard.db`.
3. **Analysis**: Analysis skills are triggered to process the normalized data and generate insights.
4. **Presentation**: The dashboard frontend fetches the normalized metrics and insights to display to the user.
5. **Alerting**: The `anomaly-alerting` skill monitors for spikes or drops and creates dashboard alerts.
