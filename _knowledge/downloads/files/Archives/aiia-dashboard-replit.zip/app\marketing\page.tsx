'use client';

import React, { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line, AreaChart, Area
} from 'recharts';

export default function MarketingPage() {
  const [marketingData, setMarketingData] = useState([]);
  const [socialData, setSocialData] = useState([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = () => {
      Promise.all([
        fetch('/api/metrics?category=Marketing').then(res => res.json()),
        fetch('/api/metrics?category=Social').then(res => res.json()),
        fetch('/api/summary').then(res => res.json())
      ]).then(([mkt, soc, summ]) => {
        setMarketingData(mkt);
        setSocialData(soc);
        setSummary(summ);
        setLoading(false);
      }).catch(err => console.error('Failed to fetch analytics', err));
    };

    fetchData();
    const interval = setInterval(fetchData, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const totalFollowers = summary?.total_audience || 0;
  const avgEngagement = summary?.best_engagement_rate ? `${summary.best_engagement_rate}%` : "5.8%";
  const totalReach = summary ? (summary.total_lifetime_views / 1000000).toFixed(2) + 'M' : '0M';

  return (
    <div style={{ animation: 'fadeIn 0.8s ease-out', maxWidth: '1400px', margin: '0 auto' }}>
      <header style={{ marginBottom: '3rem', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>Social Intelligence</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Global social media reach, engagement metrics, and community growth tracking.</p>
          <a href="https://aiiaeyes.replit.app" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--primary)', fontSize: '0.875rem', textDecoration: 'none', marginTop: '0.5rem', display: 'inline-block' }}>
            🔗 Open Source System (Replit)
          </a>
        </div>
        <div style={{ textAlign: 'right', fontSize: '0.875rem' }}>
          <div style={{ color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Harare, Zimbabwe - CAT <span style={{ color: 'var(--secondary)', marginLeft: '0.5rem' }}>● LIVE STATIC</span></div>
          <div style={{ fontWeight: 600, color: 'var(--primary)' }}>Next Event: AI Tech Forum - May 2026</div>
        </div>
      </header>

      {/* Social KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1.5rem', marginBottom: '2.5rem' }}>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>Total Audience</span>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, margin: '0.5rem 0', color: '#fbbf24' }}>{(summary?.total_audience || 0).toLocaleString()}</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>Incl. Website Members</div>
        </div>
        <div className="card" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', textTransform: 'uppercase' }}>Pending Replies</span>
          <div style={{ fontSize: '2.5rem', fontWeight: 700, margin: '0.5rem 0', color: 'var(--accent)' }}>8</div>
          <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>All channels • Action required</div>
        </div>
      </div>

      <h3 style={{ marginBottom: '1.5rem' }}>Platform Overview</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.25rem', marginBottom: '2.5rem' }}>
        {socialData.map((p: any) => {
          const isWebsite = p.platform === 'AIIA Website';
          const icon = p.platform === 'X' ? '𝕏' : p.platform === 'LinkedIn' ? 'in' : p.platform === 'Instagram' ? '📸' : p.platform === 'Facebook' ? 'f' : p.platform === 'TikTok' ? '🎵' : p.platform === 'YouTube' ? '▶️' : '🌐';
          const sparkData = JSON.parse(p.sparkline_json || '[]').map((val: number, i: number) => ({ i, val }));
          
          return (
            <div key={p.id} className="card" style={{ padding: '1rem', border: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <div style={{ width: '24px', height: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '4px', background: 'rgba(255,255,255,0.05)', fontSize: '0.8rem' }}>{icon}</div>
                  <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>{p.platform}</span>
                </div>
                <div style={{ color: (p.growth || '').startsWith('+') ? '#10b981' : '#ef4444', fontSize: '0.75rem', fontWeight: 600 }}>{p.growth || '0%'}</div>
              </div>
              
              <div style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.25rem' }}>{isWebsite ? p.traffic : (p.followers >= 1000 ? (p.followers/1000).toFixed(1) + 'K' : p.followers)}</div>
              <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '1rem' }}>{isWebsite ? 'Traffic' : 'Followers'}</div>

              <div style={{ height: '30px', width: '100%', marginBottom: '1rem' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={sparkData.length ? sparkData : [{i:0, val:10}, {i:1, val:15}, {i:2, val:12}, {i:3, val:18}]}>
                    <Area type="monotone" dataKey="val" stroke={(p.growth || '').startsWith('+') ? '#10b981' : '#ef4444'} fill={(p.growth || '').startsWith('+') ? '#10b981' : '#ef4444'} fillOpacity={0.1} strokeWidth={1.5} dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                <span>Eng {p.engagement}%</span>
                <span>Imp {p.impressions.toLocaleString()}</span>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2.5rem', marginBottom: '2rem' }}>
        {/* Active Campaign Performance */}
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Active Campaign Performance</h3>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '1px solid var(--card-border)' }}>
                  <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Campaign Name</th>
                  <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Impressions</th>
                  <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>CTR</th>
                  <th style={{ padding: '1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>Spend</th>
                </tr>
              </thead>
              <tbody>
                {marketingData.slice(0, 5).map((row: any) => (
                  <tr key={row.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.02)' }}>
                    <td style={{ padding: '1rem', fontWeight: 600 }}>{row.campaign_name}</td>
                    <td style={{ padding: '1rem' }}>{(row.impressions || 0).toLocaleString()}</td>
                    <td style={{ padding: '1rem' }}>{((row.clicks || 0) / (row.impressions || 1) * 100).toFixed(1)}%</td>
                    <td style={{ padding: '1rem' }}>${(row.spend || 0).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Activity Feed */}
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem', fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Activity Feed</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <div style={{ width: '32px', height: '32px', borderRadius: '16px', background: '#3b82f6', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700 }}>TM</div>
              <div>
                <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>@DrTarisaiMhonda <span style={{ color: '#3b82f6' }}>🐦</span></div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '0.25rem', lineHeight: '1.4' }}>The work AIIA is doing on AI policy for Zimbabwe is exactly what we need ahead of...</div>
                <div style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.2)', marginTop: '0.5rem' }}>4m ago</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <div style={{ width: '32px', height: '32px', borderRadius: '16px', background: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700 }}>BZ</div>
              <div>
                <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>@builderzw <span style={{ color: '#10b981' }}>💼</span></div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', marginTop: '0.25rem', lineHeight: '1.4' }}>Cognify's XTCE concept is fascinating. How is knowledge time compression actually...</div>
                <div style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.2)', marginTop: '0.5rem' }}>22m ago</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
