---
name: anomaly-alerting
description: detect unusual changes, risks, errors, or anomalies across finance, marketing, social media, admin, connection, and sync data in the consolidated company dashboard. Use when identifying spikes, drops, missing data, failed syncs, unusual spending, revenue changes, or overdue operational issues.
---

# Anomaly Alerting

## Goal
Detect unusual activity and create useful alerts.

## Workflow
1. Review current metrics against historical baselines.
2. Detect anomalies such as:
   - Revenue drops
   - Expense spikes
   - Campaign overspend
   - Lead drops
   - Social media engagement drops
   - Failed syncs
   - Overdue admin tasks
3. Classify severity:
   - Info
   - Warning
   - Critical
4. Explain the likely reason if available.
5. Recommend follow-up action.

## Output Format
Return:
- Alert title
- Category
- Severity
- What changed
- Why it matters
- Recommended action
