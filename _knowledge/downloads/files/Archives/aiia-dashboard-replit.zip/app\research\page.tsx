'use client';

import React, { useState, useEffect } from 'react';

const PublicationItem = ({ pub }: { pub: any }) => {
  const keyPoints = JSON.parse(pub.key_points_json || '[]');
  const tags = JSON.parse(pub.tags_json || '[]');

  return (
    <div style={{ padding: '2rem', borderBottom: '1px solid var(--card-border)', display: 'grid', gridTemplateColumns: '1fr 3fr', gap: '2rem' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div style={{ 
          width: '100%', aspectRatio: '3/4', background: 'rgba(255,255,255,0.02)', 
          borderRadius: '8px', border: '1px solid var(--card-border)',
          display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '3rem', opacity: 0.3
        }}>
          {pub.journal?.includes('Report') ? '📊' : '📄'}
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Relevance</div>
          <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--secondary)' }}>{Math.round(pub.relevance_score * 100)}%</div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>via {pub.search_provider}</div>
        </div>
      </div>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: 600, lineHeight: 1.2 }}>{pub.title}</h3>
            {pub.is_new === 1 && <span style={{ padding: '0.1rem 0.4rem', background: 'var(--secondary)', color: 'white', borderRadius: '4px', fontSize: '0.65rem', fontWeight: 800 }}>NEW</span>}
          </div>
          <span style={{ 
            fontSize: '0.75rem', padding: '0.25rem 0.75rem', borderRadius: '20px', 
            background: 'rgba(59, 130, 246, 0.1)', color: 'var(--primary)', fontWeight: 600
          }}>
            {pub.status}
          </span>
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '1.25rem' }}>
          <strong>Source:</strong> {pub.journal} • {new Date(pub.publication_date).toLocaleDateString()}
        </p>

        {keyPoints.length > 0 && (
          <div style={{ background: 'rgba(255,255,255,0.02)', padding: '1rem', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)', marginBottom: '1.25rem' }}>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.5rem', fontWeight: 700 }}>EXECUTIVE SUMMARY</div>
            <ul style={{ margin: 0, paddingLeft: '1.25rem', fontSize: '0.875rem', color: 'rgba(255,255,255,0.8)', lineHeight: '1.6' }}>
              {keyPoints.map((point: string, i: number) => <li key={i}>{point}</li>)}
            </ul>
          </div>
        )}

        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          {tags.map((tag: string) => (
            <span key={tag} style={{ fontSize: '0.7rem', padding: '0.2rem 0.6rem', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', color: 'var(--text-muted)' }}>#{tag}</span>
          ))}
        </div>

        <div style={{ display: 'flex', gap: '1rem' }}>
          <a href={pub.url} target="_blank" className="btn btn-primary" style={{ padding: '0.6rem 1.25rem', textDecoration: 'none' }}>Access Full Text</a>
          <button className="btn" style={{ padding: '0.6rem 1.25rem', background: 'rgba(255,255,255,0.05)' }}>Save to Library</button>
        </div>
      </div>
    </div>
  );
};

export default function ResearchPage() {
  const [publications, setPublications] = useState([]);
  const [products, setProducts] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/metrics?category=Research').then(res => res.json()),
      fetch('/api/products').then(res => res.json()),
      fetch('/api/events').then(res => res.json())
    ]).then(([pubs, prods, evts]) => {
      setPublications(pubs);
      setProducts(prods);
      setEvents(evts);
      setLoading(false);
    }).catch(err => console.error('Failed to fetch research repository', err));
  }, []);

  return (
    <div style={{ animation: 'fadeIn 0.8s ease-out', maxWidth: '1400px', margin: '0 auto' }}>
      <header style={{ marginBottom: '3rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '3rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>Research & IP</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Comprehensive tracking of intellectual property, product ecosystems, and academic events.</p>
        </div>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '3rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* Products Row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem' }}>
            {products.map((prod: any) => (
              <div key={prod.id} className="card" style={{ background: 'rgba(255,255,255,0.02)' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--primary)', fontWeight: 700, marginBottom: '0.5rem' }}>PRODUCT NODE</div>
                <h4 style={{ fontSize: '1.25rem', marginBottom: '0.25rem' }}>{prod.name}</h4>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{prod.tagline}</p>
              </div>
            ))}
          </div>

          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '1.5rem 2rem', borderBottom: '1px solid var(--card-border)', background: 'rgba(255,255,255,0.02)', display: 'flex', justifyContent: 'space-between' }}>
              <h3 style={{ fontSize: '1.1rem' }}>Academic Publication Archive</h3>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{publications.length} Documents</span>
            </div>
            {loading ? (
              <div style={{ padding: '4rem', textAlign: 'center' }}>Loading repository...</div>
            ) : (
              publications.map((pub: any) => (
                <PublicationItem key={pub.id} pub={pub} />
              ))
            )}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          {/* Events Sidebar */}
          <div className="card">
            <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>Upcoming Events</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {events.map((evt: any) => (
                <div key={evt.id} style={{ padding: '1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', borderLeft: '3px solid var(--secondary)' }}>
                  <div style={{ fontWeight: 700, marginBottom: '0.25rem' }}>{evt.title}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.5rem' }}>{new Date(evt.event_date).toLocaleDateString()} • {evt.location}</div>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    {evt.tags.map((tag: string) => (
                      <span key={tag} style={{ fontSize: '0.65rem', padding: '0.2rem 0.4rem', background: 'rgba(255,255,255,0.05)', borderRadius: '4px' }}>{tag}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Submission Form */}
          <div className="card" style={{ borderStyle: 'dashed' }}>
            <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>New Submission</h3>
            <form style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <input placeholder="Manuscript Title" style={{ background: 'rgba(0,0,0,0.2)', border: '1px solid var(--card-border)', padding: '0.75rem', borderRadius: '8px', color: 'white' }} />
              <textarea placeholder="Abstract Summary" rows={4} style={{ background: 'rgba(0,0,0,0.2)', border: '1px solid var(--card-border)', padding: '0.75rem', borderRadius: '8px', color: 'white', resize: 'none' }} />
              <button className="btn btn-primary" style={{ justifyContent: 'center' }}>Broadcast Work</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
