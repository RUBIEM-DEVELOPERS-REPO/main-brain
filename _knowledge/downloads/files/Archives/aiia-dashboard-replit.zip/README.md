# Integrated Company Dashboard System

This system consolidates company data from financial, marketing, social media, and administrative systems into one central dashboard.

## Main Features

- **API and database connection management**: Add and test connections to external systems.
- **Financial highlights**: Track revenue, expenses, and profit trends.
- **Marketing and social media reporting**: Monitor campaign performance and audience growth.
- **Admin operations monitoring**: Track pending approvals and internal tasks.
- **Agent-generated insights**: Automated analysis and recommendations.
- **Alerts and anomaly detection**: Identify unusual activity and sync failures.

## Main Modules

- **Dashboard Home**: Executive overview of all company KPIs.
- **Connections Page**: Manage system integrations.
- **Finance Module**: Deep dive into financial metrics.
- **Marketing Module**: Campaign and lead analytics.
- **Social Media Module**: Platform-specific engagement tracking.
- **Admin Module**: Operational task management.

## Tech Stack

- **Frontend**: Next.js 14 (App Router)
- **Styling**: Vanilla CSS (Premium Dark Theme)
- **Database**: SQLite with `better-sqlite3`
- **Charts**: Recharts
- **Agent Layer**: Skill-based markdown definitions

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the development server:
   ```bash
   npm run dev
   ```

3. Access the dashboard at `http://localhost:3000`.
