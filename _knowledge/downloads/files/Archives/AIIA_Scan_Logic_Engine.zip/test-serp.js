
const SERP_API_KEY = "faca327db19420f4cb7aec4e3f2802e4a34e774202da2f2d3d46d37bfaf630d5";

async function testSerp(platform, username) {
    console.log(`[Test] Searching for ${platform} profile: ${username}`);
    const query = `site:${platform}.com ${username} followers`;
    const searchUrl = `https://serpapi.com/search.json?engine=google&q=${encodeURIComponent(query)}&api_key=${SERP_API_KEY}`;
    
    try {
        const response = await fetch(searchUrl);
        console.log(`[Test] Status: ${response.status}`);
        const data = await response.json();
        
        if (data.error) {
            console.error(`[Test Error] ${data.error}`);
            return;
        }

        console.log(`[Test Success] Found ${data.organic_results?.length || 0} results.`);
        if (data.organic_results?.[0]) {
            console.log(`[Test Title] ${data.organic_results[0].title}`);
            console.log(`[Test Snippet] ${data.organic_results[0].snippet}`);
        } else {
            console.log("[Test] No organic results found.");
        }
    } catch (err) {
        console.error(`[Test Fetch Error] ${err.message}`);
    }
}

testSerp('twitter', 'AIInstituteAfr');
