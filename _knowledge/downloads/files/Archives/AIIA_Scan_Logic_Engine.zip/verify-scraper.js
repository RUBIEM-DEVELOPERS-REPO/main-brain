
const PLATFORMS = [
    { name: 'x', url: 'https://x.com/AIInstituteAfr' },
    { name: 'instagram', url: 'https://www.instagram.com/aiinstituteafrica' },
    { name: 'youtube', url: 'https://www.youtube.com/@AIInstituteAfrica' },
    { name: 'tiktok', url: 'https://www.tiktok.com/@ai.institute.afri' },
    { name: 'linkedin', url: 'https://www.linkedin.com/company/aiinstituteafrica' },
    { name: 'facebook', url: 'https://www.facebook.com/aiinstituteafrica' }
];

async function testScraper() {
    for (const p of PLATFORMS) {
        console.log(`[Test] Scraping ${p.name}...`);
        try {
            const res = await fetch(`http://localhost:3001/scrape?platform=${p.name}&url=${encodeURIComponent(p.url)}`);
            const data = await res.json();
            console.log(`[Test Success] ${p.name} source: ${data.source}`);
            // console.log(JSON.stringify(data, null, 2).substring(0, 500));
        } catch (err) {
            console.error(`[Test Error] ${p.name}: ${err.message}`);
        }
    }
}

testScraper();
