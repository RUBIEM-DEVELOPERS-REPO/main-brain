# AIIA Scan Logic Engine - Documentation

This package contains the core intelligence of the AIIA Scraper Bridge, which handles all data extraction for the Command Center.

## 🧠 Core Architecture
The system uses a **Waterfall Priority** system to ensure high-accuracy data:

1.  **Level 1: Official/Direct APIs**: 
    -   **Facebook**: Uses the Graph API (Page Insights).
    -   **LinkedIn/Instagram**: Uses Zernio API for reliable auth-less metrics.
    -   **Website**: Uses the custom `aiinstituteafrica.com/api/analytics` endpoint.
2.  **Level 2: SerpAPI Intelligence**: 
    -   Used as a fallback to search Google for public profile metrics (followers, recent post snippets) without needing credentials.
3.  **Level 3: n8n Cloud Agent**: 
    -   For complex or long-running scans, the logic delegates to n8n workflows and awaits a callback.

## 📂 File Summary
- **scraper-server.js**: The main Express server that handles the `/scrape` endpoint and n8n callbacks.
- **research-scraper.js**: Helper logic for analyzing search results.
- **test-direct-apis.js**: A utility script to verify your API keys (Facebook, Website, etc.) are working.
- **test-serp.js**: A test script for the search-based fallback logic.
- **verify-scraper.js**: A tool to check the end-to-end data integrity of a scan response.

## 🛠️ Usage
To run the engine independently:
1. Ensure `.env` contains your API keys.
2. Run `node scraper-server.js`.
3. The bridge will listen on port 3001.
