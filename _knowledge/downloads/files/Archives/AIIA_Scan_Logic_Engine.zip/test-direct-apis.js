
import dotenv from 'dotenv';
dotenv.config();

const FACEBOOK_PAGE_ID = process.env.FACEBOOK_PAGE_ID;
const FACEBOOK_ACCESS_TOKEN = process.env.FACEBOOK_ACCESS_TOKEN;
const ZERNIO_API_KEY = process.env.ZERNIO_API_KEY;

async function testFacebook() {
    console.log("\n--- Testing Facebook Graph API ---");
    const url = `https://graph.facebook.com/v20.0/${FACEBOOK_PAGE_ID}?fields=fan_count,followers_count,engagement,about&access_token=${FACEBOOK_ACCESS_TOKEN}`;
    try {
        const res = await fetch(url);
        const data = await res.json();
        if (data.error) throw new Error(data.error.message);
        console.log("[Success] Facebook Data:", JSON.stringify(data, null, 2));
    } catch (err) {
        console.error("[Error] Facebook API:", err.message);
    }
}

async function testZernio() {
    console.log("\n--- Testing Zernio API (LinkedIn) ---");
    try {
        const res = await fetch('https://zernio.com/api/analytics/linkedin', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${ZERNIO_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        console.log("[Success] Zernio Data (Partial):", JSON.stringify(data, null, 2).substring(0, 500));
    } catch (err) {
        console.error("[Error] Zernio API:", err.message);
    }
}

async function runTests() {
    if (FACEBOOK_PAGE_ID && FACEBOOK_ACCESS_TOKEN) await testFacebook();
    if (ZERNIO_API_KEY) await testZernio();
}

runTests();
