
import dotenv from 'dotenv';
dotenv.config();

const SERP_API_KEY = process.env.SERP_API_KEY;
const OPENAI_KEY = process.env.VITE_OPENAI_KEY;

async function research(platform, username, url) {
    console.log(`\n--- RESEARCHING: ${platform} (${username}) ---`);
    
    // 1. Get RAW SerpAPI results
    let query = `site:${platform}.com ${username} followers`;
    if (platform === 'youtube') query = `site:youtube.com ${username} "subscribers" "views"`;
    if (platform === 'tiktok') query = `site:tiktok.com "@${username}" followers`;
    if (platform === 'linkedin') query = `site:linkedin.com/company "${username}" followers`;

    const searchUrl = `https://serpapi.com/search.json?engine=google&q=${encodeURIComponent(query)}&api_key=${SERP_API_KEY}`;
    
    try {
        const serpRes = await fetch(searchUrl);
        const serpData = await serpRes.json();
        
        const rawText = JSON.stringify({
            organic_results: (serpData.organic_results || []).slice(0, 5).map(r => ({ title: r.title, snippet: r.snippet })),
            knowledge_graph: serpData.knowledge_graph || null
        });

        console.log("RAW SERP SNAPSHOT (First 2):", JSON.stringify(serpData.organic_results?.slice(0, 2), null, 2));

        // 2. Run current AI extraction logic
        const sysPrompt = `You are a data extractor for the AIIA Command Center. Extract social media stats for AI Institute Africa on ${platform} from the provided raw text.
Expect JSON input. You must respond ONLY with a raw JSON object (no markdown).
Required JSON schema:
{
  "followers": "...",
  "lifetime_views": "...",
  "lifetime_likes": "...",
  "daily_views": "...",
  "daily_likes": "...",
  "engagement_rate": "...",
  "recent_post_summary": "1 sentence short summary"
}`;

        const aiRes = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${OPENAI_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-4o",
                messages: [
                    { role: "system", content: sysPrompt },
                    { role: "user", content: rawText }
                ]
            })
        });

        const aiData = await aiRes.json();
        console.log("AI EXTRACTED DATA:", aiData.choices?.[0]?.message?.content);

    } catch (err) {
        console.error("Research Error:", err.message);
    }
}

// Research X and YouTube (common issues)
async function run() {
    await research('twitter', 'AIInstituteAfr', 'https://x.com/AIInstituteAfr');
    await research('youtube', 'AIInstituteAfrica', 'https://www.youtube.com/@AIInstituteAfrica');
}

run();
