# AIIA Command Center - n8n Automation & Tunnels

This folder contains the webhook definitions (n8n Workflows) and instructions for setting up the communication tunnel between your Command Center and n8n.

## 📥 Included Workflows
- **tick tok scraper.json**: The primary n8n workflow for scanning social platforms.
    - **Step 1**: Open n8n.
    - **Step 2**: Click "Workflows" -> "Import from File".
    - **Step 3**: Select `tick tok scraper.json`.

## 🌐 The Tunnel (Webhook Callback)
For n8n to send data back to your Command Center, it needs a public URL.

### If running locally:
Use `localtunnel` to expose port 3001:
```bash
npx localtunnel --port 3001 --subdomain aiia-scrapper-bridge
```
Your callback URL will be: `https://aiia-scrapper-bridge.loca.lt/webhook/n8n-callback`

### If running on Replit:
Your Repl will have a public URL (e.g., `https://aiia-command-center.youruser.repl.co`). 
Your callback URL will be: `https://your-repl-url.repl.co/webhook/n8n-callback`

## ⚙️ Workflow Configuration
Inside the n8n workflow, locate the **HTTP Request** node (titled "Callback to Command Center"). Update the **URL** in that node to match your callback URL from above.
