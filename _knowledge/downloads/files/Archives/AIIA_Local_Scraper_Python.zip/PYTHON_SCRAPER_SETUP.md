# AIIA Command Center - Local Python Scraper (snscrape)

This folder contains the localized Python core used for "Deep Fallback" scans. It is used as a last resort when Official APIs and SerpAPI fail to return data.

## 🛠️ Prerequisites
- **Python 3.8+** must be installed on the system.
- The `python` command must be available in your system's PATH.

## ⚙️ Installation
To make the scraper functional, you need to install it in editable mode within its directory:
```bash
# Navigate to the snscrape-master folder
cd snscrape-master

# Install dependencies
pip install -e .
```

## 🔄 Integration
The `scraper-server.js` (Bridge Server) expects this folder to be located at `../snscrape/snscrape-master` relative to the server file. It executes commands like:
`python -m snscrape --jsonl twitter-user <username>`

## 🖋️ Notes
- This is a localized version of the open-source `snscrape` library.
- It is highly efficient for extracting public profile data without needing API credentials.
- On **Replit**, this requires a `replit.nix` configuration to include the Python environment.
