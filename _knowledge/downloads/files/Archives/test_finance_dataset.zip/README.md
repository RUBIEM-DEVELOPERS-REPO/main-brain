Test Finance Dataset (Synthetic)

Files:
- customers.csv (35 rows)
- products.csv (12 rows)
- invoices.csv (220 rows)
- invoice_lines.csv (810 rows)
- payments.csv (233 rows)
- payment_allocations.csv (224 rows)

Import order:
1) customers 2) products 3) invoices 4) invoice_lines 5) payments 6) payment_allocations

Notes:
- totals are in invoice currency.
- invoice.status is derived from balance and due_date (as of 2026-02-25) except 'void'.
- payments with status='reversed' are excluded from amount_paid/balance calculations.
- some payments are unapplied (no allocation rows).

Primary keys:
- customers.customer_id
- products.product_id
- invoices.invoice_id
- invoice_lines.invoice_line_id
- payments.payment_id
- payment_allocations.allocation_id

Relationships:
- invoices.customer_id -> customers.customer_id
- invoice_lines.invoice_id -> invoices.invoice_id
- invoice_lines.product_id -> products.product_id
- payments.customer_id -> customers.customer_id
- payment_allocations.payment_id -> payments.payment_id
- payment_allocations.invoice_id -> invoices.invoice_id
