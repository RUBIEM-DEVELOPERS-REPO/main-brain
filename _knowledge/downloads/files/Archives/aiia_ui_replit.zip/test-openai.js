
import dotenv from 'dotenv';
dotenv.config();

const OPENAI_KEY = process.env.VITE_OPENAI_KEY;

async function testOpenAI() {
    console.log("\n--- Testing OpenAI Key ---");
    try {
        const res = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${OPENAI_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [{ role: "user", content: "Hello" }]
            })
        });
        const data = await res.json();
        if (data.error) throw new Error(`${data.error.code}: ${data.error.message}`);
        console.log("[Success] OpenAI Response:", data.choices[0].message.content);
    } catch (err) {
        console.error("[Error] OpenAI API:", err.message);
    }
}

testOpenAI();
