# Deployment Instructions - AIIA Signal Command Center

This setup contains a React frontend (Vite) and an Express backend (Scraper Bridge). Both need to run for the dashboard to be fully functional.

## 1. Environment Variables (Replit Secrets)
Add the following keys to your **Replit Secrets** tab. Do NOT share these publicly.

Required for full functionality:
- `VITE_OPENAI_API_KEY`: For AI Report Generation and Inbox Drafts.
- `VITE_AIIA_WEBSITE_API_KEY`: To fetch live website analytics.
- `FACEBOOK_ACCESS_TOKEN`: For direct Facebook scan.
- `FACEBOOK_PAGE_ID`: Your Facebook Page ID.
- `ZERNIO_API_KEY`: Optional - for LinkedIn/Instagram automated scans.
- `SERP_API_KEY`: Optional - fallback search for public profiles.

Note: In Replit, use the key names exactly as above. The Vite app will pick up keys prefixed with `VITE_`.

## 2. Dependencies
Run `npm install` in the Shell. The system uses:
- `concurrently`: To run Vite and Express together.
- `express`, `cors`, `dotenv`: For the bridge server.

## 3. How to Run
Click the **Run** button at the top. The `.replit` file is configured to execute:
`npm run replit`

This command starts:
- **Port 5173**: The Frontend Dashboard.
- **Port 3001**: The Scraper Bridge (used for all live scans).

## 4. Deployment Check
- If the "Social Monitor" scans fail with "Connection Refused," ensure `scraper-server.js` is running on port 3001.
- By default, the frontend is configured to call `/local-scraper/` which the Vite proxy routes to port 3001.
