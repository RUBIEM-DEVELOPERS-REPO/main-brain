# AIIA Command Center - API Connectivity & Tunneling Map

This package explains and provides the configuration for all "Tunnels" and "Proxies" that allow the AIIA Command Center to communicate across different environments.

## 1. Frontend Proxies (Vite Tunneling)
The dashboard uses an internal proxy to avoid CORS issues and simplify requests.
- **Config File**: `vite.config.js`
- **Tunnels**:
    - `/api-proxy` → `https://api.openai.com` (AI Reports & Replies)
    - `/n8n-proxy` → `https://arthurmagaya.app.n8n.cloud` (Cloud Agent Workflows)
    - `/local-scraper` → `http://localhost:3001` (Direct connection to Bridge Engine)

## 2. Backend Bridge (Scraper Connectivity)
The bridge server acts as a centralized request handler for external data sources.
- **File**: `scraper-server.js`
- **Outbound Connections**:
    - **Facebook**: `graph.facebook.com`
    - **AIIA Website**: `aiinstituteafrica.com/api/analytics`
    - **LinkedIn/Instagram**: `zernio.com/api/v1`
    - **SerpAPI**: `serpapi.com`

## 3. Reverse Tunnels (Inbound Webhooks)
For n8n to send data back to the system, you must expose port 3001.

### Local (Dev) Mode:
```bash
npx localtunnel --port 3001 --subdomain aiia-scrapper-bridge
```
- **Callback**: `https://aiia-scrapper-bridge.loca.lt/webhook/n8n-callback`

### Cloud (Production) Mode:
On Replit or a VPS, use your public URL:
- **Callback**: `https://your-public-url.com/webhook/n8n-callback`

## 4. Required Secrets
Ensure the following are set in your `.env` or Replit Secrets for the tunnels to function:
- `VITE_OPENAI_API_KEY`
- `VITE_AIIA_WEBSITE_API_KEY`
- `SERP_API_KEY`
- `FACEBOOK_ACCESS_TOKEN`
- `ZERNIO_API_KEY`
