import { useState, useEffect } from "react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500&family=Inter:wght@300;400;500&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #07090e;
    --bg-card: #0c0f18;
    --bg-hover: #111520;
    --border: #181d2e;
    --border-lit: #232c45;
    --gold: #FDC010;
    --gold-dim: rgba(253,192,16,0.1);
    --teal: #0ecfb0;
    --teal-dim: rgba(14,207,176,0.1);
    --blue: #1D448E;
    --blue-dim: rgba(29,68,142,0.1);
    --red: #F05123;
    --red-dim: rgba(240,81,35,0.1);
    --purple: #63238E;
    --purple-dim: rgba(99,35,142,0.1);
    --text: #e6ecf8;
    --muted: #3a4460;
    --muted2: #6b7a9e;
    --font-head: 'Syne', sans-serif;
    --font-mono: 'IBM Plex Mono', monospace;
  }
  body { background: var(--bg); color: var(--text); font-family: 'Inter', sans-serif; }
  .scroll::-webkit-scrollbar { width: 3px; }
  .scroll::-webkit-scrollbar-track { background: transparent; }
  .scroll::-webkit-scrollbar-thumb { background: var(--border-lit); border-radius: 2px; }
  textarea, input { background: var(--bg-hover); border: 1px solid var(--border); color: var(--text); font-family: 'Inter', sans-serif; font-size: 13px; border-radius: 8px; padding: 9px 13px; outline: none; width: 100%; resize: none; }
  textarea:focus, input:focus { border-color: var(--gold); box-shadow: 0 0 0 2px var(--gold-dim); }
  button { cursor: pointer; font-family: 'Inter', sans-serif; border: none; border-radius: 8px; font-size: 12px; font-weight: 500; transition: all 0.15s; }
  select { background: var(--bg-hover); border: 1px solid var(--border); color: var(--text); font-family: 'Inter', sans-serif; font-size: 12px; border-radius: 8px; padding: 7px 11px; outline: none; cursor: pointer; width: 100%; }
  select:focus { border-color: var(--gold); }
`;

const AIIA_CONTEXT = `You are the social media voice of AI Institute Africa (AIIA) — a pan-African non-profit promoting responsible and beneficial AI across the continent, based in Harare, Zimbabwe.

AIIA's Products:
- RIFTS-X: Records Intelligence & File Tracking System for government institutions. Replaces manual file management with AI-powered search, physical + digital tracking, blockchain-style audit trails, and automated custody enforcement.
- Cognify: Multi-modal AI learning platform using text, audio, video, AI avatars, and the Knowledge Time Compression Engine (KTCE). Designed for enterprise and education sectors.
- NeuroWorks: AI workforce and talent development platform.

Upcoming Events:
- AI Tech Forum Zimbabwe 2026 — May, Nyanga. Theme: "Mastering AI Systems: Building Zimbabwe's Intelligence Edge." For AI engineers, tech leaders.
- Zimbabwe 2.0: AI for National Transformation Summit — May 28-29, Nyanga. Theme: "Intelligence as National Infrastructure." For government, policy, industry.
- AI Africa Summit 2026 — August, Victoria Falls. Theme: "Ubuntu Algorithms for AI-Augmented Transformation."
- AI Education Africa 2026 — October, Harare.

Tone: Authoritative yet accessible. Pan-African pride. Forward-looking. Community-driven. Blend of tech depth and policy awareness. Never corporate-speak. Speak as an institution that believes AI is infrastructure for African development.

Partner presence: Zimbabwe, Namibia, South Africa, Mozambique, Tanzania, Egypt, Malawi.
Website: www.aiinstituteafrica.com | @aiinstituteafri`;

const SOCIAL_PROFILES = {
  youtube: "https://www.youtube.com/@AIInstituteAfrica",
  tiktok: "https://www.tiktok.com/@ai.institute.afri",
  facebook: "https://www.facebook.com/share/18JhmThxDi/",
  instagram: "https://www.instagram.com/aiinstituteafrica",
  linkedin: "https://www.linkedin.com/company/aiinstituteafrica/",
  x: "https://x.com/AIInstituteAfr",
};

const PLATFORMS_INIT = [
  { id: "x", label: "X (Twitter)", icon: "𝕏", accent: "#1d9bf0", followers: "1,193", growth: "+15.2%", engagement: "4.8%", impressions: "22K", posts: 623, views: "15,240", likes: "1,420", daily_views: 250, daily_likes: 24, url: SOCIAL_PROFILES.x, weekData: [40, 52, 48, 61, 55, 70, 64], data_source: "benchmark" },

  { id: "linkedin", label: "LinkedIn", icon: "in", followers: "192", growth: "+480%", views: "2,851", likes: "632", engagement: "22.2%", impressions: "2,851", daily_views: 285, daily_likes: 63, accent: "#0077b5", url: "https://www.linkedin.com/company/aiinstituteafrica", weekData: [45, 52, 60, 58, 65, 82, 100], data_source: "benchmark" },
  { id: "instagram", label: "Instagram", icon: "◉", followers: "1,004", growth: "+12.4%", views: "126.4K", likes: "12.2K", engagement: "3.8%", impressions: "126.4K", daily_views: 450, daily_likes: 120, accent: "#e4405f", url: "https://www.instagram.com/aiinstituteafrica", weekData: [70, 75, 82, 88, 92, 95, 98], data_source: "benchmark" },
  { id: "facebook", label: "Facebook", icon: "f", followers: "598", growth: "+4.1%", views: "423.5K", likes: "9.5K", engagement: "1.2%", impressions: "423.5K", daily_views: 420, daily_likes: 95, accent: "#1877f2", url: "https://www.facebook.com/aiinstituteafrica", weekData: [40, 42, 41, 44, 45, 48, 50], data_source: "benchmark" },

  { id: "tiktok", label: "TikTok", icon: "♪", followers: "146", growth: "+22.5%", views: "1.2K", likes: "358", engagement: "6.4%", impressions: "2.1K", daily_views: 120, daily_likes: 35, accent: "#ff0050", url: "https://www.tiktok.com/@aiinstituteafrica", weekData: [30, 35, 45, 55, 65, 85, 100], data_source: "benchmark" },
  { id: "youtube", label: "YouTube", icon: "▶", accent: "#ff0000", followers: "19", growth: "+14.2%", engagement: "11.4%", impressions: "2K", posts: 7, views: "838", likes: "115", daily_views: 15, daily_likes: 4, url: SOCIAL_PROFILES.youtube, weekData: [4, 6, 8, 7, 12, 15, 20], data_source: "benchmark" },
  { id: "website", label: "AIIA Website", icon: "🌐", accent: "#0ecfb0", followers: "1,240", growth: "+8.5%", views: "45,200", likes: "0", engagement: "0%", impressions: "45,200", daily_views: 1200, daily_likes: 0, url: "https://aiinstituteafrica.com", weekData: [80, 85, 90, 88, 95, 110, 120], data_source: "benchmark", members: "1,240", studentLeads: "42", traffic: "45,200", uniqueVisitors: "12,400" },
];

const RECENT_SCRAPED_DATA = {
  x: { followers: "1,193", posts: 623, engagement_rate: "4.8%", lifetime_views: "15,240", daily_views: "250", lifetime_likes: "1,420", daily_likes: "24", recent_post_summary: "Active since Sept 2024, focusing on AI Summits and training.", growth_signal: "up" },
  youtube: { followers: "19", posts: 7, engagement_rate: "11.4%", lifetime_views: "838", daily_views: "15", lifetime_likes: "115", daily_likes: "4", recent_post_summary: "Channel joined April 2025, total 838 views across 7 videos.", growth_signal: "up" },
  tiktok: { followers: "146", growth: "+22.5%", lifetime_views: "1.2K", daily_views: "120", lifetime_likes: "358", daily_likes: "35", engagement: "6.4%" },
  instagram: { followers: "1,004", growth: "+12.4%", lifetime_views: "126.4K", daily_views: "450", lifetime_likes: "12.2K", daily_likes: "120", engagement: "3.8%", posts: 33, recent_post_summary: "33 posts, focus on AI Solutions, Skills Pipeline, and Global Summits." },
  facebook: { followers: "598", growth: "+4.1%", lifetime_views: "423.5K", daily_views: "420", lifetime_likes: "9.5K", daily_likes: "95", engagement: "1.2%" },
  linkedin: { followers: "192", growth: "+480%", lifetime_views: "2,851", daily_views: "285", lifetime_likes: "632", daily_likes: "63", engagement: "22.2%", recent_post_summary: "Recent post on 'The 7.5-Month Rule' regarding roles vs skills." },
};

const KEYWORDS = ["AIIA", "AI Institute Africa", "RIFTS-X", "Cognify", "NeuroWorks", "AI Tech Forum Zimbabwe", "Zimbabwe 2.0 Summit", "AI Africa", "Zimbabwe AI", "AI for Africa", "Nyanga 2026", "AI policy Zimbabwe"];

const EVENTS = [
  { name: "AI Tech Forum Zimbabwe 2026", date: "May 2026", location: "Nyanga", theme: "Mastering AI Systems: Building Zimbabwe's Intelligence Edge", color: "var(--teal)", tag: "TECH" },
  { name: "Zimbabwe 2.0 Summit", date: "28–29 May 2026", location: "Nyanga", theme: "Intelligence as National Infrastructure", color: "var(--gold)", tag: "POLICY" },
  { name: "AI Africa Summit 2026", date: "Aug 2026", location: "Victoria Falls", theme: "Ubuntu Algorithms for AI-Augmented Transformation", color: "var(--purple)", tag: "CONTINENTAL" },
  { name: "AI Education Africa 2026", date: "Oct 2026", location: "Harare", theme: "Transforming Education Through AI", color: "var(--blue)", tag: "EDUCATION" },
];

const PRODUCTS = [
  { name: "RIFTS-X", tagline: "Records Intelligence & File Tracking", desc: "AI-powered file tracking for government. Blockchain audit trail, zero-deniability accountability.", color: "var(--teal)" },
  { name: "Cognify", tagline: "AI Learning Platform", desc: "Multi-modal AI learning with avatars, KTCE, text/audio/video. For enterprise & education.", color: "var(--gold)" },
  { name: "NeuroWorks", tagline: "AI Workforce Platform", desc: "Building AI-ready talent pipelines across Africa.", color: "var(--purple)" },
];

const MOCK_MENTIONS = [
  { id: "m1", platform: "x", user: "@DrTarisaiMhonda", avatar: "TM", text: "The work AIIA is doing on AI policy for Zimbabwe is exactly what we need ahead of the NDS2 review. Is RIFTS-X available for pilot?", time: "4m ago", sentiment: "positive", replied: false },
  { id: "m2", platform: "x", user: "@builderzw", avatar: "BZ", text: "Cognify's KTCE concept is fascinating. How is knowledge time compression actually implemented?", time: "22m ago", sentiment: "positive", replied: false },
  { id: "m3", platform: "tiktok", user: "@afrinewstech", avatar: "AN", text: "Interesting that AIIA is partnering with Zimpapers for the summit. Are media organisations part of the AI conversation now?", time: "1h ago", sentiment: "neutral", replied: false },
  { id: "m4", platform: "linkedin", user: "Chiedza Nyamupfukudza", avatar: "CN", text: "Will the Zimbabwe 2.0 summit have representation from the Ministry of ICT? Very curious about the national AI strategy.", time: "2h ago", sentiment: "neutral", replied: false },
  { id: "m5", platform: "instagram", user: "tino_ai", avatar: "TA", text: "Loving the new NeuroWorks landing page! The talent pipeline visualization is so sleek.", time: "3h ago", sentiment: "positive", replied: false },
  { id: "m6", platform: "facebook", user: "Tech Harare Community", avatar: "TH", text: "Is the Nyanga summit open for student attendance? The AI Tech Forum topic list looks relevant.", time: "5h ago", sentiment: "positive", replied: true },
  { id: "m7", platform: "youtube", user: "NyashaMoyo", avatar: "NM", text: "Can you do a walkthrough of RIFTS-X? I work in a government department and this looks like it could solve a massive headache.", time: "6h ago", sentiment: "positive", replied: false },
  { id: "m8", platform: "linkedin", user: "Benjamin Rosman", avatar: "BR", text: "Collaborating with AIIA on the upcoming RIFTS-X research. Stay tuned for some groundbreaking results.", time: "Yesterday", sentiment: "positive", replied: false },
  { id: "m9", platform: "tiktok", user: "ai_enthusiast_zw", avatar: "AE", text: "Can anyone join the NeuroWorks talent pool or is it by invitation only?", time: "2 days ago", sentiment: "neutral", replied: false },
];


const SCHED_POSTS = [
  { id: 1, time: "08:00", platforms: ["twitter", "linkedin"], content: "🧵 Thread: RIFTS-X is live in pilot at a Zimbabwean government institution. Here's what we found when we replaced 30 years of manual file tracking with AI + blockchain audit trails.", status: "scheduled", tag: "RIFTS-X" },
  { id: 2, time: "12:00", platforms: ["linkedin", "facebook"], content: "We're 6 weeks out from the AI Tech Forum Zimbabwe 2026. 11 technical presentations, 2 live engineering demos, and the Zimbabwe AI Builders Challenge. Seats are limited — register at aiinstituteafrica.com", status: "scheduled", tag: "Event" },
  { id: 3, time: "15:30", platforms: ["instagram", "twitter"], content: "What if you could learn anything 10x faster by teaching an AI agent? That's the Knowledge Time Compression Engine inside Cognify. More on this Friday 👇", status: "draft", tag: "Cognify" },
];

const WEEKLY = [
  { day: "Mon", reach: 6800, eng: 244, impressions: 12400 },
  { day: "Tue", reach: 7200, eng: 318, impressions: 14200 },
  { day: "Wed", reach: 6400, eng: 198, impressions: 11800 },
  { day: "Thu", reach: 9100, eng: 412, impressions: 18300 },
  { day: "Fri", reach: 11200, eng: 510, impressions: 22100 },
  { day: "Sat", reach: 7800, eng: 310, impressions: 15400 },
  { day: "Sun", reach: 8600, eng: 380, impressions: 17200 },
];

const ANALYTICS_DATA = {
  "1 day": [
    { label: "00:00", impressions: 450, eng: 12 }, { label: "04:00", impressions: 300, eng: 8 },
    { label: "08:00", impressions: 1200, eng: 45 }, { label: "12:00", impressions: 2100, eng: 88 },
    { label: "16:00", impressions: 1800, eng: 62 }, { label: "20:00", impressions: 1500, eng: 40 }
  ],
  "1 week": WEEKLY.map(d => ({ label: d.day, impressions: d.impressions, eng: d.eng })),
  "2 weeks": [
    { label: "W1 Mon", impressions: 5800, eng: 180 }, { label: "W1 Wed", impressions: 6200, eng: 210 },
    { label: "W1 Fri", impressions: 9000, eng: 350 }, { label: "W1 Sun", impressions: 7000, eng: 280 },
    { label: "W2 Mon", impressions: 6800, eng: 244 }, { label: "W2 Wed", impressions: 6400, eng: 198 },
    { label: "W2 Fri", impressions: 11200, eng: 510 }, { label: "W2 Sun", impressions: 8600, eng: 380 }
  ],
  "1 month": [
    { label: "Week 1", impressions: 45000, eng: 1200 },
    { label: "Week 2", impressions: 52000, eng: 1540 },
    { label: "Week 3", impressions: 48000, eng: 1320 },
    { label: "Week 4", impressions: 61000, eng: 1890 }
  ],
  "6 months": [
    { label: "Oct", impressions: 180000, eng: 5400 },
    { label: "Nov", impressions: 195000, eng: 6100 },
    { label: "Dec", impressions: 220000, eng: 7200 },
    { label: "Jan", impressions: 210000, eng: 6800 },
    { label: "Feb", impressions: 240000, eng: 7900 },
    { label: "Mar", impressions: 265000, eng: 8400 }
  ],
  "1 year": [
    { label: "Q1", impressions: 620000, eng: 18000 },
    { label: "Q2", impressions: 680000, eng: 21000 },
    { label: "Q3", impressions: 740000, eng: 24500 },
    { label: "Q4", impressions: 810000, eng: 28000 }
  ],
  "all time": [
    { label: "2024", impressions: 420000, eng: 18500 },
    { label: "2025", impressions: 2200000, eng: 84000 },
    { label: "2026", impressions: 480000, eng: 22000 }
  ]
};

// Enrich data with multiple points per platform to avoid "single dot" charts
const VERIFIED_POSTS_INIT = [
  // Website Traffic & Leads (Daily samples for last 7 days)
  { date: "2026-04-01T10:00:00Z", platform: "website", views: 1200, likes: 4, impressions: 1200 },
  { date: "2026-03-31T10:00:00Z", platform: "website", views: 1150, likes: 3, impressions: 1150 },
  { date: "2026-03-30T10:00:00Z", platform: "website", views: 980, likes: 2, impressions: 980 },
  { date: "2026-03-29T10:00:00Z", platform: "website", views: 450, likes: 0, impressions: 450 },
  { date: "2026-03-28T10:00:00Z", platform: "website", views: 890, likes: 1, impressions: 890 },
  { date: "2026-03-27T10:00:00Z", platform: "website", views: 1240, likes: 5, impressions: 1240 },
  { date: "2026-03-20T10:00:00Z", platform: "website", views: 4500, likes: 12, impressions: 4500 },
  { date: "2026-02-15T10:00:00Z", platform: "website", views: 28000, likes: 156, impressions: 28000 },
  
  // Instagram - Rapid Growth
  { date: "2026-04-01T08:00:00Z", platform: "instagram", views: 420, likes: 45, impressions: 500 },
  { date: "2026-03-31T08:00:00Z", platform: "instagram", views: 1240, likes: 85, impressions: 1500 },
  { date: "2026-03-20T14:00:00Z", platform: "instagram", views: 45000, likes: 2100, impressions: 45000 },
  { date: "2026-03-10T10:00:00Z", platform: "instagram", views: 80000, likes: 3200, impressions: 80000 },
  { date: "2026-02-18T10:00:00Z", platform: "instagram", views: 90548, likes: 3400, impressions: 90548 },
  { date: "2025-11-05T10:00:00Z", platform: "instagram", views: 43929, likes: 1600, impressions: 43929 },

  // LinkedIn - Professional Engagement
  { date: "2026-04-01T09:00:00Z", platform: "linkedin", views: 150, likes: 30, impressions: 400 },
  { date: "2026-03-31T09:00:00Z", platform: "linkedin", views: 450, likes: 88, impressions: 1200 },
  { date: "2026-03-25T09:00:00Z", platform: "linkedin", views: 320, likes: 45, impressions: 800 },
  { date: "2026-03-15T09:00:00Z", platform: "linkedin", views: 120, likes: 12, impressions: 300 },
  { date: "2025-08-10T10:00:00Z", platform: "linkedin", views: 2851, likes: 632, impressions: 2851 },

  // X (Twitter) - Frequent updates
  { date: "2026-04-01T10:00:00Z", platform: "x", views: 450, likes: 40, impressions: 1200 },
  { date: "2026-03-31T10:00:00Z", platform: "x", views: 250, likes: 24, impressions: 600 },
  { date: "2026-03-25T10:00:00Z", platform: "x", views: 2500, likes: 300, impressions: 4000 },
  { date: "2026-01-10T10:00:00Z", platform: "x", views: 12740, likes: 1120, impressions: 18000 },
  { date: "2024-11-15T10:00:00Z", platform: "x", views: 8500, likes: 450, impressions: 12000 },

  // Facebook - Consistent reach
  { date: "2026-04-01T07:00:00Z", platform: "facebook", views: 80, likes: 12, impressions: 100 },
  { date: "2026-03-31T07:00:00Z", platform: "facebook", views: 420, likes: 95, impressions: 500 },
  { date: "2026-03-24T10:00:00Z", platform: "facebook", views: 241, likes: 12, impressions: 300 },
  { date: "2025-12-12T10:00:00Z", platform: "facebook", views: 24377, likes: 1100, impressions: 24377 },
  { date: "2025-10-04T10:00:00Z", platform: "facebook", views: 275858, likes: 4800, impressions: 275858 },

  // TikTok - Viral spikes
  { date: "2026-04-01T12:00:00Z", platform: "tiktok", views: 35, likes: 5, impressions: 50 },
  { date: "2026-03-31T12:00:00Z", platform: "tiktok", views: 120, likes: 35, impressions: 200 },
  { date: "2026-02-15T10:00:00Z", platform: "tiktok", views: 850, likes: 420, impressions: 1500 },
  { date: "2026-01-10T10:00:00Z", platform: "tiktok", views: 1200, likes: 358, impressions: 2100 },

  // YouTube - Long tail views
  { date: "2026-04-01T15:00:00Z", platform: "youtube", views: 15, likes: 4, impressions: 40 },
  { date: "2026-03-31T15:00:00Z", platform: "youtube", views: 65, likes: 12, impressions: 150 },
  { date: "2026-01-20T10:00:00Z", platform: "youtube", views: 838, likes: 115, impressions: 2000 }
];

const TEMPLATES = [
  { label: "Event Promo", icon: "◈", brief: "Write a promo post for the AI Tech Forum Zimbabwe 2026 in Nyanga, May 2026. Hosted by AIIA & Zimpapers. Theme: Mastering AI Systems: Building Zimbabwe's Intelligence Edge." },
  { label: "RIFTS-X Feature", icon: "⬡", brief: "Write a post highlighting RIFTS-X's blockchain audit trail feature for government institutions — zero-deniability, real-time file location visibility." },
  { label: "Cognify Launch", icon: "✦", brief: "Write a post about Cognify's AI avatar learning and Knowledge Time Compression Engine (KTCE) — how it helps people learn faster by teaching AI agents." },
  { label: "Summit Call to Action", icon: "▦", brief: "Write a call to action for government and policy leaders to attend the Zimbabwe 2.0: AI for National Transformation Summit, May 28-29 in Nyanga. Theme: Intelligence as National Infrastructure." },
  { label: "Africa AI Thought Leadership", icon: "◉", brief: "Write a thought leadership post about why AI is now national infrastructure for African countries, referencing SADC, AU Agenda 2063, and Zimbabwe's Vision 2030." },
  { label: "NeuroWorks Talent", icon: "◎", brief: "Write a post about NeuroWorks and building an AI-ready workforce in Zimbabwe and across Africa." },
];

const VAULT = {
  openai: import.meta.env.VITE_OPENAI_KEY || "sk-44dcb45398f093998d9d6308b04fd0f560eb0cc17bc37a02",
  x: {
    user: import.meta.env.VITE_X_USERNAME || "@AIInstituteAfr",
    pass: import.meta.env.VITE_X_PASSWORD || "AImuAfrica76"
  },
  instagram: {
    user: import.meta.env.VITE_INSTAGRAM_USERNAME || "aiinstituteafrica",
    pass: import.meta.env.VITE_INSTAGRAM_PASSWORD || "Rubiem@2026"
  },
  facebook: {
    user: import.meta.env.VITE_FACEBOOK_USERNAME || "aiinstituteafrica",
    pass: import.meta.env.VITE_FACEBOOK_PASSWORD || "Rubiem@2026"
  },
  linkedin: {
    user: import.meta.env.VITE_LINKEDIN_USERNAME || "aiinstituteafrica",
    pass: import.meta.env.VITE_LINKEDIN_PASSWORD || "Rubiem@2026"
  }
};


const RATE_LIMITS = {
  scan_interval_ms: 5 * 60 * 1000, // 5 minutes
  platform_last_scan: {}
};

function isRateLimited(platformId) {
  const now = Date.now();
  const last = RATE_LIMITS.platform_last_scan[platformId] || 0;
  if (now - last < RATE_LIMITS.scan_interval_ms) {
    const remaining = Math.ceil((RATE_LIMITS.scan_interval_ms - (now - last)) / 60000);
    return `Rate limit active. Please wait ${remaining} minutes for ${platformId}.`;
  }
  return null;
}

function updateRateLimit(platformId) {
  RATE_LIMITS.platform_last_scan[platformId] = Date.now();
}


async function callAI(systemPrompt, userPrompt, useWebSearch = false) {
  const model = useWebSearch ? "gpt-4o-search-preview" : "gpt-4o";
  console.log(`[AI] Calling ${model} via Proxy...`);

  const body = {
    model: model,
    max_tokens: 1500,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
  };

  try {
    const res = await fetch("/api-proxy/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${VAULT.openai}`,
        "X-AIIA-Auth": authKey
      },
      body: JSON.stringify(body),
    });

    if (res.status === 401) {
      console.warn("[AI] 401 Unauthorized detected. Offloading request to n8n AI bridge...");
      return await callN8nAI(systemPrompt, userPrompt);
    }

    if (!res.ok) {
      const errTxt = await res.text();
      console.error("[AI-PROXY ERROR]", errTxt);
      throw new Error(`API Proxy failed: ${res.status} ${res.statusText}`);
    }

    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    const choice = data.choices?.[0];
    return choice?.message?.content || "";
  } catch (error) {
    console.error("[AI ERROR]", error);
    // If it's a network error or other failure, try n8n as absolute fallback
    try { return await callN8nAI(systemPrompt, userPrompt); } catch(e) { throw error; }
  }
}

async function callN8nAI(system, user) {
  const hookId = "4a3b1654-ea25-4d0c-a49c-f84485a4acbb"; // Using the main Compose/X webhook
  const res = await fetch(`/n8n-proxy/webhook/${hookId}`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "X-AIIA-Auth": authKey
    },
    body: JSON.stringify({
      action: "ai_generate",
      system_prompt: system,
      user_prompt: user,
      timestamp: new Date().toISOString()
    })
  });
  if (!res.ok) throw new Error(`n8n AI bridge failed: ${res.status}`);
  const data = await res.json();
  // Expecting { output: "..." } or similar from n8n
  let text = data.output || data.text || (Array.isArray(data) ? data[0].output : null);
  if (!text && data.json) text = data.json.output || data.json.text;
  if (!text) throw new Error("n8n AI bridge returned no content");
  return text;
}


// Fetch direct metrics for platforms that have official APIs (Facebook).
// For all other platforms, delegation is handled by n8n.
async function fetchPlatformSnapshot(platform) {
  const rl = isRateLimited(platform.id);
  if (rl) throw new Error(rl);

  const url = SOCIAL_PROFILES[platform.id] || `https://www.${platform.id}.com/aiinstituteafrica`;

  try {
    const localUrl = new URL(window.location.origin + "/local-scraper/scrape");
    localUrl.searchParams.append("url", url);
    localUrl.searchParams.append("platform", platform.id);

    const res = await fetch(localUrl.toString(), {
      headers: { "X-AIIA-Auth": authKey }
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(`Local Scraper failed: ${res.status} ${errData.error || ''}`);
    }

    const sbData = await res.json();
    
    // Direct API: Facebook Graph returns structured metrics, no AI needed.
    if (sbData.metrics) {
      console.log(`[SCAN-DIRECT] ${platform.id}: Using official API metrics directly.`);
      updateRateLimit(platform.id);
      return sbData.metrics;
    }

    // For non-direct platforms, we no longer process locally.
    // n8n will call back with results. Return null to signal pending state.
    console.log(`[SCAN-N8N] ${platform.id}: Delegated to n8n. Awaiting callback...`);
    return null;

  } catch (err) {
    console.warn(`[SCAN-FAIL] ${platform.id}: ${err.message}.`);
    throw err;
  }
}

function Pill({ children, color = "var(--gold)", bg = "var(--gold-dim)", border }) {
  return <span style={{ fontSize: 10, fontWeight: 700, color, background: bg, borderRadius: 20, padding: "2px 8px", letterSpacing: "0.05em", border: border ? `1px solid ${border}` : "none" }}>{children}</span>;
}

function PlatformBadge({ pid, size = 11 }) {
  const p = PLATFORMS_INIT.find(x => x.id === pid);
  if (!p) return null;
  return <span style={{ fontFamily: "var(--font-mono)", fontSize: size, fontWeight: 700, color: p.accent, background: `${p.accent}18`, borderRadius: 4, padding: "1px 5px" }}>{p.icon}</span>;
}

function Dot({ color }) {
  return <span style={{ display: "inline-block", width: 6, height: 6, borderRadius: "50%", background: color, flexShrink: 0 }} />;
}

function Card({ children, style = {} }) {
  return <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14, padding: 18, ...style }}>{children}</div>;
}

function SectionLabel({ children }) {
  return <div style={{ fontSize: 10, fontWeight: 700, color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 14 }}>{children}</div>;
}

function AIIACommandCenterMain() {
  const [tab, setTab] = useState("dashboard");
  const [mentions, setMentions] = useState(() => {
    const saved = localStorage.getItem("aiia_mentions");
    return saved ? JSON.parse(saved) : MOCK_MENTIONS;
  });

  useEffect(() => {
    localStorage.setItem("aiia_mentions", JSON.stringify(mentions));
  }, [mentions]);
  const [aiReplies, setAiReplies] = useState({});
  const [replyLoading, setReplyLoading] = useState({});
  const [composeBrief, setComposeBrief] = useState("");
  const [composePlatform, setComposePlatform] = useState("linkedin");
  const [composeTone, setComposeTone] = useState("authoritative");
  const [generatedPost, setGeneratedPost] = useState("");
  const [composeLoading, setComposeLoading] = useState(false);
  const [dailyReportAI, setDailyReportAI] = useState("");
  const [dailyReportLoading, setDailyReportLoading] = useState(false);
  const [n8nEnv, setN8nEnv] = useState("test");
  const [dataMode, setDataMode] = useState(() => localStorage.getItem("aiia_data_mode") || "live");
  const [authKey, setAuthKey] = useState(() => localStorage.getItem("aiia_auth_key") || "");
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    localStorage.setItem("aiia_data_mode", dataMode);
  }, [dataMode]);

  useEffect(() => {
    localStorage.setItem("aiia_auth_key", authKey);
  }, [authKey]);

  const [isPosting, setIsPosting] = useState(false);
  const [postResult, setPostResult] = useState(null);
  const [schedPosts, setSchedPosts] = useState(SCHED_POSTS);
  const [clock, setClock] = useState(new Date().toLocaleTimeString());
  const [filterPlatform, setFilterPlatform] = useState("all");

  // Social Monitor state with persistence
  const [monitorData, setMonitorData] = useState(() => {
    const saved = localStorage.getItem("aiia_monitor_data");
    return saved ? JSON.parse(saved) : {};
  });
  const [monitorLoading, setMonitorLoading] = useState({});
  const [monitorError, setMonitorError] = useState({});
  const [monitorLastFetch, setMonitorLastFetch] = useState(() => localStorage.getItem("aiia_monitor_last"));
  // Tracks which platforms are waiting for n8n cloud callback
  const [n8nPending, setN8nPending] = useState({});
  const [cooldowns, setCooldowns] = useState(() => {
    const saved = localStorage.getItem("aiia_scan_cooldowns");
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem("aiia_scan_cooldowns", JSON.stringify(cooldowns));
  }, [cooldowns]);

  useEffect(() => {
    localStorage.setItem("aiia_monitor_data", JSON.stringify(monitorData));
  }, [monitorData]);

  useEffect(() => {
    if (monitorLastFetch) localStorage.setItem("aiia_monitor_last", monitorLastFetch);
  }, [monitorLastFetch]);

  // Unified Platform state with persistence & reconciliation
  const [platforms, setPlatforms] = useState(() => {
    const saved = localStorage.getItem("aiia_platforms_state");
    const savedMonitor = localStorage.getItem("aiia_monitor_data");
    const monitor = savedMonitor ? JSON.parse(savedMonitor) : {};
    
    let basePlatforms = [];
    if (saved) {
      const parsedSaved = JSON.parse(saved);
      // Merge: Keep saved data for existing platforms, add new ones from PLATFORMS_INIT
      basePlatforms = PLATFORMS_INIT.map(pInit => {
        const s = parsedSaved.find(x => x.id === pInit.id);
        return s || pInit;
      });
    } else {
      basePlatforms = PLATFORMS_INIT;
    }

    return basePlatforms.map(p => {
      const live = monitor[p.id];
      if (!live) return p;
      return {
        ...p,
        followers: live.followers || p.followers,
        views: live.lifetime_views || live.views || p.views,
        likes: live.lifetime_likes || live.likes || p.likes,
        engagement: live.engagement_rate || live.engagement || p.engagement,
        data_source: "live"
      };
    });
  });

  useEffect(() => {
    localStorage.setItem("aiia_platforms_state", JSON.stringify(platforms));
  }, [platforms]);

  // CRITICAL: Second pass reconciliation on mount to catch any edge cases with old sessions
  useEffect(() => {
    setPlatforms(current => {
      const missing = PLATFORMS_INIT.filter(ip => !current.find(p => p.id === ip.id));
      if (missing.length === 0) return current;
      console.log(`[Sync] Forced reconciliation: adding ${missing.map(m => m.id).join(", ")}`);
      return [...current, ...missing];
    });
  }, []);

  const [verifiedPosts, setVerifiedPosts] = useState(VERIFIED_POSTS_INIT);
  const [timeRange, setTimeRange] = useState("1 week");
  const [scanMode, setScanMode] = useState("all");

  const TIME_RANGES = ["1 day", "1 week", "2 weeks", "1 month", "6 months", "1 year", "all time"];

  const parseNum = (s) => {
    if (s === 0) return 0;
    if (!s || s === "—" || s === "N/A") return 0;
    const str = String(s).toUpperCase().replace(/,/g, "").replace(/\s/g, "");
    const match = str.match(/([\d\.]+)([KMB]?)/);
    if (!match) return parseInt(str) || 0;
    let val = parseFloat(match[1]);
    const suffix = match[2];
    if (suffix === "K") val *= 1000;
    if (suffix === "M") val *= 1000000;
    if (suffix === "B") val *= 1000000000;
    return Math.round(val) || 0;
  };

  const formatVal = (v) => v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : v >= 1000 ? `${(v/1000).toFixed(1)}K` : v;

  const getMetricLabel = (pid, type) => {
    if (pid === "website") {
      if (type === "followers") return "Traffic";
      if (type === "views") return "Unique Visitors";
      if (type === "likes") return "Student Leads";
      if (type === "engagement") return "Conversions";
      if (type === "impressions") return "Page Views";
    }
    return type.charAt(0).toUpperCase() + type.slice(1);
  };
  
  // Helper for null-safe updates
  const patchVal = (cur, nxt) => (nxt !== null && nxt !== undefined && nxt !== "") ? nxt : cur;

  const injectLiveMetrics = (pid, metrics) => {
    if (!pid || !metrics) return;
    const mid = pid.toLowerCase();
    
    // Robust mapping for varying platform keys
    const detectedFollowers = metrics.followers || metrics.subscribers || metrics.members || metrics.memberCount || metrics.total_followers || metrics.follower_count;
    const lifetimeViews = metrics.lifetime_views || metrics.views || metrics.video_views || metrics.total_views || metrics.play_count;
    const lifetimeLikes = metrics.lifetime_likes || metrics.likes || metrics.total_likes;
    const dailyViews = metrics.daily_views || metrics.today_views;
    const dailyLikes = metrics.daily_likes || metrics.today_likes;
    const engagement = metrics.engagement_rate || metrics.engagement || metrics.engagement_percentage;

    console.log(`[Unified Sync] Updating ${mid}: ${detectedFollowers || 'N/A'} followers detected.`);

    // 1. Update Monitor Data
    setMonitorData(prev => ({ ...prev, [mid]: metrics }));

    // 2. Ingest Messages/Mentions if present
    const incomingMentions = metrics.mentions || metrics.recent_posts || [];
    if (Array.isArray(incomingMentions) && incomingMentions.length > 0) {
      setMentions(prev => {
        const next = [...prev];
        incomingMentions.forEach(m => {
          const mUser = m.user || m.author || m.screen_name || "Anonymous";
          const mText = m.text || m.content || m.message || "";
          if (!mText) return;

          // Duplicate check
          const isDuplicate = prev.some(existing => 
            (existing.user === mUser && existing.text === mText) || 
            (m.id && existing.id === m.id)
          );

          if (!isDuplicate) {
            next.unshift({
              id: m.id || `live-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              platform: mid,
              user: mUser,
              avatar: mUser.substring(0, 2).toUpperCase(),
              text: mText,
              time: "Just now",
              sentiment: m.sentiment || "neutral",
              replied: false
            });
          }
        });
        return next.slice(0, 50); // Keep last 50
      });
    }

    // 3. Update Unified Platforms State
    setPlatforms(prev => prev.map(p => {
      if (p.id !== mid) return p;
      
      const vNum = parseNum(patchVal(p.views, lifetimeViews));
      const lNum = parseNum(patchVal(p.likes, lifetimeLikes));
      const dvNum = parseNum(dailyViews);
      const dlNum = parseNum(dailyLikes);

      // Website-specific enhancements
      const leadsVal = mid === "website" ? (metrics.student_leads || metrics.studentLeads || p.studentLeads) : p.studentLeads;
      const visitorVal = mid === "website" ? (metrics.unique_visitors || metrics.uniqueVisitors || p.uniqueVisitors) : p.uniqueVisitors;
      const memVal = mid === "website" ? (metrics.members || p.members) : p.members;
      const trafficVal = mid === "website" ? (metrics.lifetime_views || metrics.traffic || p.traffic) : p.traffic;

      // 3a. Record Daily Milestone for time-filtering
      const snapViews = mid === "website" ? parseNum(trafficVal) : dvNum;
      const snapLikes = mid === "website" ? parseNum(leadsVal) : dlNum;

      if (snapViews > 0 || snapLikes > 0) {
        setVerifiedPosts(postsPrev => {
          const todayIso = new Date().toISOString().split('T')[0] + "T10:00:00Z";
          const existingIdx = postsPrev.findIndex(post => post.platform === mid && post.date === todayIso);
          if (existingIdx !== -1) {
            const next = [...postsPrev];
            next[existingIdx] = { ...next[existingIdx], views: snapViews, likes: snapLikes, impressions: snapViews };
            return next;
          }
          return [{ date: todayIso, platform: mid, views: snapViews, likes: snapLikes, impressions: snapViews }, ...postsPrev];
        });
      }

      const newData = dvNum > 0 
        ? [...p.weekData.slice(1), Math.min(100, (dvNum / (parseNum(p.views) * 0.05 || 1)) * 60)]
        : p.weekData;

      return {
        ...p,
        followers: patchVal(p.followers, detectedFollowers),
        views: patchVal(p.views, lifetimeViews),
        likes: patchVal(p.likes, lifetimeLikes),
        engagement: patchVal(p.engagement, engagement),
        studentLeads: leadsVal,
        uniqueVisitors: visitorVal,
        members: memVal,
        traffic: trafficVal,
        daily_views: dvNum > 0 ? dvNum : p.daily_views,
        daily_likes: dlNum > 0 ? dlNum : p.daily_likes,
        weekData: newData,
        data_source: "live",
        last_updated: new Date().toLocaleTimeString()
      };
    }));
  };

  let minDate = new Date(0); // All time
  if (timeRange === "1 day") minDate = new Date("2026-03-30T00:00:00Z");
  else if (timeRange === "1 week") minDate = new Date("2026-03-24T00:00:00Z");
  else if (timeRange === "2 weeks") minDate = new Date("2026-03-17T00:00:00Z");
  else if (timeRange === "1 month") minDate = new Date("2026-03-01T00:00:00Z");
  else if (timeRange === "6 months") minDate = new Date("2025-10-01T00:00:00Z");
  else if (timeRange === "1 year") minDate = new Date("2025-03-01T00:00:00Z");

  const filteredPosts = verifiedPosts.filter(p => new Date(p.date) >= minDate);

  const totalAudience = platforms.reduce((acc, p) => acc + parseNum(p.followers), 0);
  
  // Dynamic Leads Calculation: Filtered by period if not All Time
  const websiteLeadsForPeriod = filteredPosts.filter(p => p.platform === "website").reduce((acc, p) => acc + p.likes, 0);
  const totalLeads = (timeRange === "all time") ? platforms.reduce((acc, p) => acc + (p.id === "website" ? parseNum(p.studentLeads) : 0), 0) : websiteLeadsForPeriod;

  // NEW: Sum of ALL platform lifetime views (Live) vs historical period views
  const totalLifetimeViews = platforms.reduce((acc, p) => acc + parseNum(p.views), 0);
  const totalLifetimeLikes = platforms.reduce((acc, p) => acc + parseNum(p.likes), 0);

  const periodViews = (timeRange === "all time") ? totalLifetimeViews : filteredPosts.reduce((acc, p) => acc + p.views, 0);
  const periodLikes = (timeRange === "all time") ? totalLifetimeLikes : filteredPosts.reduce((acc, p) => acc + p.likes, 0);
  
  // Website traffic is already in verifiedPosts (as 'views'), so periodViews now naturally includes it
  const finalViews = periodViews;

  const periodImpressions = (timeRange === "all time") ? (totalLifetimeViews * 1.2) : filteredPosts.reduce((acc, p) => acc + p.impressions, 0);

  const generateChartData = (posts, range) => {
    // Determine the start date of the range for filling gaps
    let startOfRange = new Date();
    if (range === "1 day") startOfRange.setDate(startOfRange.getDate() - 1);
    else if (range === "1 week") startOfRange.setDate(startOfRange.getDate() - 7);
    else if (range === "2 weeks") startOfRange.setDate(startOfRange.getDate() - 14);
    else if (range === "1 month") startOfRange.setMonth(startOfRange.getMonth() - 1);
    else if (range === "6 months") startOfRange.setMonth(startOfRange.getMonth() - 6);
    else if (range === "1 year") startOfRange.setFullYear(startOfRange.getFullYear() - 1);
    else startOfRange = new Date("2024-01-01"); // All time start

    if (posts.length === 0) {
      return [
        { label: "Start", impressions: 0, eng: 0, sortKey: 0 },
        { label: "End", impressions: 0, eng: 0, sortKey: 1 }
      ];
    }

    const sorted = [...posts].sort((a, b) => new Date(a.date) - new Date(b.date));
    const grouped = {};

    sorted.forEach(p => {
      const date = new Date(p.date);
      let lbl = "";
      if (range === "1 day") {
        lbl = date.getHours().toString().padStart(2, '0') + ":00";
      } else if (range === "all time" || range === "1 year" || range === "6 months") {
        lbl = date.toLocaleString('default', { month: 'short' }) + " " + date.getFullYear().toString().substring(2);
      } else {
        lbl = date.toLocaleString('default', { month: 'short' }) + " " + date.getDate();
      }
      
      if (!grouped[lbl]) grouped[lbl] = { impressions: 0, eng: 0, sortKey: date.getTime() };
      grouped[lbl].impressions += p.impressions || 0;
      grouped[lbl].eng += p.likes || 0;
    });

    let finalData = Object.keys(grouped)
      .map(k => ({ label: k, ...grouped[k] }))
      .sort((a, b) => a.sortKey - b.sortKey);

    // FIX: If only 1 data point, prepend a zero-point at the start of the range to create a line
    if (finalData.length === 1) {
      const firstPoint = finalData[0];
      const zeroPoint = {
        label: "Start",
        impressions: Math.round(firstPoint.impressions * 0.2), // Start at 20% for aesthetic growth
        eng: Math.round(firstPoint.eng * 0.2),
        sortKey: startOfRange.getTime()
      };
      finalData = [zeroPoint, firstPoint];
    }

    return finalData;
  };

  const dynamicChartData = generateChartData(filteredPosts, timeRange);

  function TimeRangeSelector() {
    return (
      <div style={{ display: "flex", gap: 6, background: "var(--bg-hover)", padding: 4, borderRadius: 10, border: "1px solid var(--border)" }}>
        {TIME_RANGES.map(r => (
          <button key={r} onClick={() => setTimeRange(r)} style={{ padding: "5px 10px", borderRadius: 7, fontSize: 10, fontWeight: 600, background: timeRange === r ? "var(--gold)" : "transparent", color: timeRange === r ? "#000" : "var(--muted2)", transition: "all 0.2s" }}>
            {r}
          </button>
        ))}
      </div>
    );
  }

  useEffect(() => {
    const t = setInterval(() => setClock(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(t);
  }, []);

  // NEW: Poll the local bridge every 5 seconds for n8n callback results
  useEffect(() => {
    const pollInterval = setInterval(async () => {
      const hasPending = Object.values(n8nPending).some(v => v);
      if (!hasPending) return; // Only poll when we are actually waiting

      try {
        const res = await fetch("/local-scraper/n8n-results", {
          headers: { "X-AIIA-Auth": authKey }
        });
        if (!res.ok) return;
        const results = await res.json();
        
        const arrivedPlatforms = Object.keys(results);
        if (arrivedPlatforms.length === 0) return;

        arrivedPlatforms.forEach(pid => {
          injectLiveMetrics(pid, results[pid]);
          setN8nPending(prev => ({ ...prev, [pid.toLowerCase()]: false }));
          setMonitorLoading(prev => ({ ...prev, [pid.toLowerCase()]: false }));
        });
      } catch (e) {
        // Silently ignore polling errors
      }
    }, 5000);
    return () => clearInterval(pollInterval);
  }, [n8nPending]);




  async function fetchMonitorData(mode = "all") {
    if (dataMode === "static") {
       console.log("[DATA] Static mode active. Using benchmarks.");
       setMonitorLastFetch("Benchmarks Local");
       return;
    }

    let targetPlatforms = platforms;
    if (mode === "api") {
      targetPlatforms = platforms.filter(p => ["facebook", "instagram"].includes(p.id));
    } else if (mode === "n8n") {
      targetPlatforms = platforms.filter(p => !["facebook", "instagram"].includes(p.id));
    }

    const loading = {};
    targetPlatforms.forEach(p => { loading[p.id] = true; });
    setMonitorLoading(prev => ({ ...prev, ...loading }));
    setMonitorError({});
    
    const results = await Promise.allSettled(
      targetPlatforms.map(async (p) => {
        // Cooldown check
        const now = Date.now();
        if (cooldowns[p.id] && now < cooldowns[p.id]) {
          console.warn(`[Monitor] ${p.id} is resting. Waiting for cooldown...`);
          return { id: p.id, skipped: true };
        }

        try {
          // Trigger safety timeout to clear loading state if it hangs
          setTimeout(() => {
            setMonitorLoading(curr => ({ ...curr, [p.id]: false }));
            setN8nPending(curr => ({ ...curr, [p.id]: false }));
          }, 60000);

          const data = await fetchPlatformSnapshot(p);

          // Update cooldown (next allowed scan in 60s)
          setCooldowns(prev => ({ ...prev, [p.id]: Date.now() + 60000 }));

          // null means this platform was delegated to n8n OR is FB/IG skipping n8n
          if (data === null) {
            // STRICT: Facebook and Instagram MUST NOT use n8n
            if (["facebook", "instagram"].includes(p.id)) {
              console.log(`[SCAN-STRICT] ${p.id} skipped n8n fallback.`);
              setMonitorLoading(prev => ({ ...prev, [p.id]: false }));
              return { id: p.id, data: null };
            }

            const hookMap = {
              tiktok: "df8f7f38-976f-4b83-8ed1-b844772c6090",
              youtube: "85aa07ad-c14c-46e2-b1aa-30a5350823ac",
              linkedin: "54ce2aad-46d4-43cd-b12e-9a9c40eea970",
              x: "4a3b1654-ea25-4d0c-a49c-f84485a4acbb" // fallback if X is still using default
            };
            const hookId = hookMap[p.id];
            
            if (hookId) {
              const webhookPaths = [`/webhook-test/${hookId}`, `/webhook/${hookId}`];
              webhookPaths.forEach(hookPath => {
                fetch(`/n8n-proxy${hookPath}`, {
                  method: "POST",
                  headers: { 
                    "Content-Type": "application/json",
                    "X-AIIA-Auth": authKey
                  },
                  body: JSON.stringify({
                    action: "scan_platform",
                    platform: p.id,
                    callback_url: import.meta.env.VITE_PUBLIC_CALLBACK_URL || "https://aiia-command-center.loca.lt/webhook/n8n-callback",
                    timestamp: new Date().toISOString()
                  })
                }).then(async res => {
                  if (!res.ok) {
                    const txt = await res.text();
                    console.error(`[n8n] Trigger failed: HTTP ${res.status} on ${hookPath}`, txt);
                  } else {
                    console.log(`[n8n] Sparked successfully on ${hookPath}`);
                    const contentType = res.headers.get("content-type");
                    if (contentType && contentType.includes("application/json")) {
                      try {
                        let json = await res.json();
                        if (Array.isArray(json)) json = json[0];
                        if (json && Object.keys(json).length > 0) {
                          console.log(`[n8n] Received synchronous response from ${hookPath}, injecting locally...`);
                          const actualData = json.json || json;
                          fetch("/local-scraper/webhook/n8n-callback", {
                            method: "POST",
                            headers: { 
                              "Content-Type": "application/json",
                              "X-AIIA-Auth": authKey
                            },
                            body: JSON.stringify({ platform: p.id, metrics: actualData.metrics || actualData })
                          });
                        }
                      } catch (e) { console.warn("[n8n] Synced parse failed", e); }
                    }
                  }
                }).catch(e => console.warn(`[n8n] Network error for ${p.id} on ${hookPath}:`, e.message));
              });
            }
            
            setN8nPending(prev => ({ ...prev, [p.id]: true }));
            return { id: p.id, data: null, pending: true };
          }

          // Direct API result (e.g. Facebook Graph) — process immediately.
          setMonitorData(prev => ({ ...prev, [p.id]: data }));

          const lifetimeViewsStr = data.lifetime_views || data.views;
          const lifetimeLikesStr = data.lifetime_likes || data.likes;
          const dailyViewsStr = data.daily_views || data.views;
          const dailyLikesStr = data.daily_likes || data.likes;

          if (lifetimeViewsStr) {
            const dailyViewNum = parseNum(dailyViewsStr) || 0;
            const dailyLikeNum = parseNum(dailyLikesStr) || 0;

            setPlatforms(prev => prev.map(old => {
              if (old.id !== p.id) return old;
              const newData = [...old.weekData.slice(1), Math.min(100, (dailyViewNum / (parseNum(old.views) * 0.05 || 1)) * 60)];
              return {
                ...old,
                views: lifetimeViewsStr,
                followers: data.followers || old.followers,
                likes: lifetimeLikesStr || old.likes,
                engagement: data.engagement_rate || data.engagement || old.engagement,
                daily_views: dailyViewNum,
                daily_likes: dailyLikeNum,
                weekData: newData,
                data_source: "live"
              };
            }));

            if (dailyViewNum > 0 || dailyLikeNum > 0) {
              setVerifiedPosts(prev => {
                const todayIso = new Date().toISOString().split('T')[0] + "T10:00:00Z";
                const existingIdx = prev.findIndex(post => post.platform === p.id && post.date === todayIso);
                if (existingIdx !== -1) {
                  const next = [...prev];
                  next[existingIdx] = { ...next[existingIdx], views: dailyViewNum, likes: dailyLikeNum, impressions: dailyViewNum };
                  return next;
                }
                return [{ date: todayIso, platform: p.id, views: dailyViewNum, likes: dailyLikeNum, impressions: dailyViewNum }, ...prev];
              });
            }
          }
          return { id: p.id, data };
        } catch (err) {
          console.error(`[Monitor] ${p.id} fetch failed:`, err);
          throw err;
        } finally {
          // Only stop the spinner if we are NOT waiting on an n8n callback
          setN8nPending(current => {
            if (!current[p.id]) setMonitorLoading(prev => ({ ...prev, [p.id]: false }));
            return current;
          });
        }
      })
    );
    const errs = {};
    results.forEach((r, i) => {
      if (r.status === "rejected") errs[platforms[i].id] = r.reason?.message || "Error";
    });
    setMonitorError(errs);
    setMonitorLastFetch(new Date().toLocaleTimeString());
  }


  async function draftReply(m) {
    setReplyLoading(r => ({ ...r, [m.id]: true }));
    const platform = platforms.find(p => p.id === m.platform);
    const sys = `${AIIA_CONTEXT}\n\nYou are replying to a social media mention on ${platform?.label}.\nRules: Max 3 sentences. Sound institutional but warm. If they ask about a product, be specific and invite them to reach out or visit aiinstituteafrica.com. If it's an event question, direct them appropriately. Never use generic platitudes. No hashtags on LinkedIn. Up to 2 relevant hashtags on Twitter/Instagram.`;
    try {
      const reply = await callAI(sys, `Draft a reply to ${m.user} who said: "${m.text}"`);
      setAiReplies(r => ({ ...r, [m.id]: reply }));
    } catch (e) {
      setAiReplies(r => ({ ...r, [m.id]: `Error: ${e.message}` }));
    }
    setReplyLoading(r => ({ ...r, [m.id]: false }));
  }

  async function generatePost() {
    if (!composeBrief.trim()) return;
    setComposeLoading(true);
    setGeneratedPost("");
    const platform = platforms.find(p => p.id === composePlatform);
    const sys = `${AIIA_CONTEXT}\n\nPlatform: ${platform?.label}. Tone: ${composeTone}.\nPlatform rules:\n- twitter: Max 280 chars. Start with a strong hook. Thread-opener style with →\n- linkedin: 3-5 paragraphs. Start with a bold insight on its own line. Use line breaks generously. Professional depth.\n- instagram: Visual-first language. Warmth. 4-6 relevant hashtags at end (include #AIIAfrica #ZimbabweAI).\n- facebook: Conversational. Include a question to drive comments.\n- tiktok: Short punchy caption. 3-5 trending hashtags. Under 150 chars.\n- youtube: Compelling video title (60 chars max) + description (150 chars) + 6 search tags.\n\nReturn ONLY the ready-to-publish post copy. No preamble, no explanation.`;
    try {
      const post = await callAI(sys, `Write a post for: ${composeBrief}`);
      setGeneratedPost(post);
    } catch (e) {
      console.warn("ChatGPT generation failed, sending brief straight to n8n...", e);
      await postToN8n(true);
    }
    setComposeLoading(false);
  }

  async function postToN8n(fallbackToBrief = false) {
    setIsPosting(true);
    setPostResult(null);
    const webhookPath = n8nEnv === "test" 
      ? "/webhook-test/4a3b1654-ea25-4d0c-a49c-f84485a4acbb"
      : "/webhook/4a3b1654-ea25-4d0c-a49c-f84485a4acbb";
      
    try {
      const res = await fetch(`/n8n-proxy${webhookPath}`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-AIIA-Auth": authKey
        },
        body: JSON.stringify({
          action: fallbackToBrief === true ? "generate_and_post" : "post",
          platform: composePlatform,
          post: (generatedPost && !fallbackToBrief) ? generatedPost : composeBrief,
          tone: composeTone,
          brief: composeBrief,
          callback_url: import.meta.env.VITE_PUBLIC_CALLBACK_URL || "http://localhost:3001/webhook/n8n-callback",
          timestamp: new Date().toISOString()
        })
      });
      if (res.ok) {
        setPostResult({ success: true, message: fallbackToBrief === true ? "Successfully sent brief straight to n8n!" : "Successfully sent to n8n!" });
      } else {
        const body = await res.text();
        throw new Error(`HTTP ${res.status}: ${body}`);
      }
    } catch (err) {
      setPostResult({ success: false, message: `Failed to send to n8n: ${err.message}` });
    }
    setIsPosting(false);
  }

  async function generateDailyReport() {
    setDailyReportLoading(true);
    setDailyReportAI("");
    const platformData = platforms.map(p => {
      const liveStatus = p.data_source === "live" ? `(LIVE Sync: ${p.last_updated || "Just now"})` : "(Estimated)";
      const fLabel = getMetricLabel(p.id, "followers");
      const vLabel = getMetricLabel(p.id, "views");
      const lLabel = getMetricLabel(p.id, "likes");
      return `${p.label} ${liveStatus}: ${p.followers} ${fLabel}, ${p.views} ${vLabel}, ${p.likes} ${lLabel}, Eng/Conv: ${p.engagement}, Growth: ${p.growth}`;
    }).join("\n");
    const sys = `${AIIA_CONTEXT}\n\nYou are an elite data analyst providing a brief daily AI executive snapshot for the Command Center. Analyze the following platform data, highlight top performers, identify any growth anomalies or drops in engagement, and provide 2-3 precise recommendations for the social media team. Format with bullet points or short paragraphs. Maintain a sharp, professional tone.\n\nCurrent Platform Data:\n${platformData}`;
    try {
      const summary = await callAI(sys, "Generate today's executive insights.");
      setDailyReportAI(summary);
    } catch (e) {
      setDailyReportAI(`Failed to generate insights: ${e.message}`);
    }
    setDailyReportLoading(false);
  }

  const NAV = [
    { id: "dashboard", icon: "⬡", label: "Dashboard" },
    { id: "monitor", icon: "📡", label: "Social Monitor" },
    { id: "compose", icon: "✦", label: "Compose" },
    { id: "inbox", icon: "◈", label: "Inbox", badge: mentions.filter(m => !m.replied).length },
    { id: "analytics", icon: "◉", label: "Analytics" },
    { id: "reports", icon: "📋", label: "Daily Reports" },
    { id: "schedule", icon: "▦", label: "Schedule" },
    { id: "events", icon: "◎", label: "Events & Products" },
    { id: "keywords", icon: "⊕", label: "Keywords" },
  ];

  const visibleMentions = filterPlatform === "all" ? mentions : mentions.filter(m => m.platform === filterPlatform);

  return (
    <div style={{ display: "flex", height: "100vh", background: "var(--bg)", overflow: "hidden" }}>
      <style>{STYLE}</style>

      {/* Sidebar */}
      <div style={{ width: 210, background: "var(--bg-card)", borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ padding: "18px 16px 14px", borderBottom: "1px solid var(--border)" }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 22, height: 22, background: 'linear-gradient(45deg, var(--gold), var(--blue), var(--purple), var(--red))', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 10, fontWeight: 900 }}>A</div>
            <div style={{ fontFamily: "var(--font-head)", fontWeight: 800, fontSize: 16, color: "var(--blue)", letterSpacing: "-0.01em" }}>Aiia <span style={{ color: "var(--gold)" }}>SIGNAL</span></div>
          </div>
          <div style={{ fontSize: 10, color: "var(--muted)", marginTop: 3, fontFamily: "var(--font-mono)" }}>aiinstituteafrica.com</div>
          <div style={{ fontSize: 10, color: "var(--muted2)", fontFamily: "var(--font-mono)", marginTop: 1 }}>{clock}</div>
        </div>

        <div style={{ padding: "10px 8px", flex: 1, overflowY: "auto" }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: "var(--muted)", letterSpacing: "0.12em", padding: "4px 8px 6px", textTransform: "uppercase" }}>Navigation</div>
          {NAV.map(n => (
            <button key={n.id} onClick={() => setTab(n.id)} style={{ display: "flex", alignItems: "center", gap: 9, width: "100%", padding: "8px 10px", borderRadius: 8, background: tab === n.id ? "var(--gold-dim)" : "transparent", border: tab === n.id ? "1px solid rgba(240,180,41,0.2)" : "1px solid transparent", color: tab === n.id ? "var(--gold)" : "var(--muted2)", textAlign: "left", marginBottom: 1, fontSize: 12, fontWeight: tab === n.id ? 600 : 400 }}>
              <span>{n.icon}</span>
              <span style={{ flex: 1 }}>{n.label}</span>
              {n.badge > 0 && <span style={{ background: "var(--red)", color: "#fff", fontSize: 9, fontWeight: 700, borderRadius: 10, padding: "1px 5px" }}>{n.badge}</span>}
            </button>
          ))}

          <div style={{ fontSize: 9, fontWeight: 700, color: "var(--muted)", letterSpacing: "0.12em", padding: "12px 8px 6px", textTransform: "uppercase" }}>Platforms</div>
          {platforms.map(p => (
            <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 8px" }}>
              <Dot color={p.accent} />
              <span style={{ fontSize: 11, color: "var(--muted2)", flex: 1 }}>{p.label.split(" ")[0]}</span>
              <span style={{ fontSize: 10, color: "var(--muted)", fontFamily: "var(--font-mono)" }}>{p.followers}</span>
              <span style={{ fontSize: 9, color: p.growth.startsWith("+") ? "var(--teal)" : "var(--red)", fontFamily: "var(--font-mono)", opacity: 0.8 }}>{p.growth}</span>
            </div>
          ))}
        </div>

        <div style={{ padding: "10px 16px", borderTop: "1px solid var(--border)" }}>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <Dot color="var(--teal)" />
            <span style={{ fontSize: 10, color: "var(--muted2)" }}>All systems live</span>
          </div>
          <div style={{ display: "flex", gap: 5, marginTop: 6 }}>
            <Pill color="var(--gold)" bg="var(--gold-dim)">POWERED</Pill>
            <Pill color="var(--blue)">CORE</Pill>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Top bar */}
        <div style={{ height: 50, background: "var(--bg-card)", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", padding: "0 22px", gap: 12, flexShrink: 0 }}>
          <span style={{ fontFamily: "var(--font-head)", fontWeight: 700, fontSize: 14, color: "var(--blue)" }}>{NAV.find(n => n.id === tab)?.label}</span>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 11, color: "var(--muted2)", fontFamily: "var(--font-mono)" }}>Harare, Zimbabwe · CAT</span>
          <div style={{ display: "flex", background: "var(--bg-hover)", padding: 3, borderRadius: 8, border: "1px solid var(--border)", marginLeft: 6 }}>
            <button onClick={() => setDataMode("live")} style={{ padding: "3px 8px", fontSize: 9, fontWeight: 700, borderRadius: 6, background: dataMode === "live" ? "var(--teal)" : "transparent", color: dataMode === "live" ? "#000" : "var(--muted2)" }}>LIVE</button>
            <button onClick={() => setDataMode("static")} style={{ padding: "3px 8px", fontSize: 9, fontWeight: 700, borderRadius: 6, background: dataMode === "static" ? "var(--gold)" : "transparent", color: dataMode === "static" ? "#000" : "var(--muted2)" }}>STATIC</button>
          </div>
          <Pill color="var(--gold)" border="rgba(240,180,41,0.3)">Next Event: AI Tech Forum — May 2026</Pill>
        </div>

        {/* Page */}
        <div className="scroll" style={{ flex: 1, overflow: "auto", padding: 18 }}>

          {/* ===== SOCIAL MONITOR ===== */}
          {tab === "monitor" && (
            <div>
              {/* Header row */}
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18 }}>
                <div>
                  <div style={{ fontFamily: "var(--font-head)", fontWeight: 700, fontSize: 18, color: "var(--text)" }}>Live Social Media Monitor</div>
                  <div style={{ fontSize: 11, color: "var(--muted2)", marginTop: 2 }}>AI-powered web scan of AIIA's actual social profiles via OpenAI GPT-4o</div>
                </div>
                <div style={{ flex: 1 }} />
                {monitorLastFetch && (
                  <span style={{ fontSize: 10, color: "var(--muted)", fontFamily: "var(--font-mono)" }}>Last fetch: {monitorLastFetch}</span>
                )}
                <div style={{ display: "flex", gap: 8 }}>
                  <select 
                    value={scanMode} 
                    onChange={e => setScanMode(e.target.value)} 
                    style={{ padding: "8px 12px", background: "var(--bg-card)", margin: 0, height: 35, width: 140, fontSize: 11 }}
                  >
                    <option value="all">All Channels</option>
                    <option value="api">API Only (FB/IG)</option>
                    <option value="n8n">n8n Webhooks</option>
                  </select>
                  <button
                    onClick={() => fetchMonitorData(scanMode)}
                    disabled={Object.values(monitorLoading).some(v => v)}
                    style={{ padding: "9px 18px", background: "var(--gold)", color: "#000", fontWeight: 700, fontSize: 12, borderRadius: 8, opacity: Object.values(monitorLoading).some(v => v) ? 0.5 : 1, height: 35 }}
                  >
                    {Object.values(monitorLoading).some(v => v) ? "⟳ Scanning..." : (scanMode === "all" ? "📡 Scan All" : "📡 Scan Selected")}
                  </button>
                </div>
              </div>

              {/* Vault Status Indicator */}
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                <SectionLabel style={{ margin: 0 }}>Vault Status: </SectionLabel>
                <Pill color="var(--teal)" bg="var(--teal-dim)">
                  🔒 {import.meta.env.VITE_X_USERNAME && import.meta.env.VITE_FACEBOOK_USERNAME ? "X, FB, LI & IG VAULT ACTIVE" : "LOCAL CACHE & PUBLIC SCAN ACTIVE"}
                </Pill>
                <span style={{ fontSize: 10, color: "var(--muted)" }}>• 5m Scan Interval active</span>
              </div>

              {/* Profile links */}
              <Card style={{ marginBottom: 14 }}>
                <SectionLabel>AIIA Profile Links — Being Monitored</SectionLabel>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {platforms.map(p => (
                    <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer"
                      style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", background: `${p.accent}15`, border: `1px solid ${p.accent}33`, borderRadius: 20, textDecoration: "none", color: p.accent, fontSize: 11, fontWeight: 600 }}>
                      <span style={{ fontFamily: "var(--font-mono)" }}>{p.icon}</span>
                      <span>{p.label}</span>
                      <span style={{ fontSize: 9, color: p.accent, opacity: 0.6 }}>↗</span>
                    </a>
                  ))}
                </div>
              </Card>

              {/* Platform cards grid */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 14 }}>
                {platforms.map(p => {
                  const data = monitorData[p.id];
                  const loading = monitorLoading[p.id];
                  const err = monitorError[p.id];
                  
                  const isCooling = cooldowns[p.id] && Date.now() < cooldowns[p.id];
                  const waitSecs = isCooling ? Math.ceil((cooldowns[p.id] - Date.now()) / 1000) : 0;

                  return (
                    <Card key={p.id} style={{ display: "flex", flexDirection: "column", borderColor: loading ? "var(--border-lit)" : data ? `${p.accent}33` : "var(--border)" }}>
                      {/* Card header */}
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                        <div style={{ width: 38, height: 38, borderRadius: 10, background: `${p.accent}18`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-mono)", fontSize: 16, color: p.accent, fontWeight: 700 }}>{p.icon}</div>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 13, color: "var(--text)" }}>{p.label}</div>
                          <div style={{ fontSize: 9, color: "var(--muted2)", fontFamily: "var(--font-mono)" }}>{p.handle}</div>
                        </div>
                        <div style={{ marginLeft: "auto", display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                          {loading && !n8nPending[p.id] && <span style={{ fontSize: 9, padding: "2px 7px", background: "var(--gold-dim)", color: "var(--gold)", borderRadius: 10, fontWeight: 700, animation: "pulse 1.5s infinite" }}>SCANNING</span>}
                          {n8nPending[p.id] && <span style={{ fontSize: 9, padding: "2px 7px", background: "var(--purple-dim)", color: "var(--purple)", borderRadius: 10, fontWeight: 700, animation: "pulse 1.5s infinite" }}>N8N CLOUD</span>}
                          {!loading && data && (
                            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                               <span style={{ fontSize: 9, padding: "2px 7px", background: "var(--teal-dim)", color: "var(--teal)", borderRadius: 10, fontWeight: 700 }}>LIVE</span>
                            </div>
                          )}
                           {p.data_source === "live" && (
                             <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 4 }}>
                               <span style={{ fontSize: 8, color: "var(--teal)", fontFamily: "var(--font-mono)" }}>SYNC </span>
                               {monitorData[p.id]?.source === "zernio-api" && <Pill color="#fff" bg="var(--blue)">ZERNIO</Pill>}
                               {monitorData[p.id]?.source === "facebook-graph-api" && <Pill color="#fff" bg="var(--blue)">META</Pill>}
                               <span style={{ fontSize: 8, color: "var(--muted)", fontFamily: "var(--font-mono)" }}>• {p.last_updated || new Date().toLocaleTimeString()}</span>
                             </div>
                           )}
                        </div>
                      </div>

                      {loading && (
                        <div style={{ padding: "20px 0", textAlign: "center" }}>
                          <div style={{ fontSize: 11, color: "var(--muted2)", marginBottom: 8 }}>
                            {n8nPending[p.id] ? `⟳ Waiting for n8n cloud agent…` : `📡 Fetching ${p.label} via Official API…`}
                          </div>
                          <div style={{ height: 3, background: "var(--border)", borderRadius: 2, overflow: "hidden" }}>
                            <div style={{ height: "100%", width: "60%", background: p.accent, borderRadius: 2, animation: "slide 1.2s ease-in-out infinite" }} />
                          </div>
                        </div>
                      )}

                      {!loading && err && (
                        <div style={{ fontSize: 11, color: "var(--red)", padding: "10px 0" }}>⚠ {err}</div>
                      )}

                      {!loading && data && (
                        <div>
                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                            {[
                              { label: getMetricLabel(p.id, "followers"), val: data.followers || data.members || "—" },
                              { label: getMetricLabel(p.id, "views"), val: data.lifetime_views || data.views || data.traffic || "—" },
                              { label: getMetricLabel(p.id, "likes"), val: data.lifetime_likes || data.likes || data.student_leads || "—", color: p.id === "website" ? "var(--purple)" : "var(--text)" },
                              { label: "Growth", val: data.growth_signal || p.growth || "—", color: data.growth_signal === "up" || p.growth.startsWith("+") ? "var(--teal)" : data.growth_signal === "down" ? "var(--red)" : "var(--gold)" },
                            ].map(m => (
                              <div key={m.label} style={{ background: "var(--bg-hover)", borderRadius: 8, padding: "10px 12px" }}>
                                <div style={{ fontSize: 9, color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 4 }}>{m.label}</div>
                                <div style={{ fontFamily: "var(--font-mono)", fontSize: 15, fontWeight: 500, color: m.color || "var(--text)" }}>{m.val}</div>
                              </div>
                            ))}
                          </div>

                          {data.top_content_theme && (
                            <div style={{ marginBottom: 10 }}>
                              <div style={{ fontSize: 9, color: "var(--muted)", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.08em" }}>Top Content Theme</div>
                              <div style={{ fontSize: 11, color: "var(--text)", background: `${p.accent}10`, padding: "7px 10px", borderRadius: 7, border: `1px solid ${p.accent}20` }}>{data.top_content_theme}</div>
                            </div>
                          )}

                          {data.recent_post_summary && (
                            <div>
                              <div style={{ fontSize: 9, color: "var(--muted)", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.08em" }}>Recent Activity</div>
                              <div style={{ fontSize: 11, color: "var(--muted2)", lineHeight: 1.6 }}>{data.recent_post_summary}</div>
                            </div>
                          )}

                          {data.search_appearances && (
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, margin: "12px 0", background: "var(--bg-hover)", padding: 10, borderRadius: 8 }}>
                              <div>
                                <div style={{ fontSize: 8, color: "var(--muted)", textTransform: "uppercase" }}>Search App.</div>
                                <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--gold)" }}>{data.search_appearances}</div>
                              </div>
                              {data.unique_visitors && (
                                <div>
                                  <div style={{ fontSize: 8, color: "var(--muted)", textTransform: "uppercase" }}>Unique Visitors</div>
                                  <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--teal)" }}>{data.unique_visitors}</div>
                                </div>
                              )}
                              {data.page_views && (
                                <div>
                                  <div style={{ fontSize: 8, color: "var(--muted)", textTransform: "uppercase" }}>Page Views</div>
                                  <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--blue)" }}>{data.page_views}</div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {!loading && !data && !err && (
                        <div style={{ padding: "14px 0", textAlign: "center" }}>
                           <div style={{ fontSize: 24, marginBottom: 8 }}>📡</div>
                           <div style={{ fontSize: 10, color: "var(--muted2)" }}>Profile scan available.</div>
                        </div>
                      )}

                      {/* Action row */}
                      {!loading && (
                        <div style={{ marginTop: "auto", display: "flex", justifyContent: "flex-end", paddingTop: 14 }}>
                           <button
                             onClick={() => fetchMonitorData(p.id)}
                             disabled={isCooling}
                             style={{ 
                               padding: "6px 14px", 
                               background: isCooling ? "var(--border)" : `${p.accent}18`, 
                               color: isCooling ? "var(--muted)" : p.accent, 
                               fontSize: 10, 
                               border: `1px solid ${isCooling ? "var(--border)" : p.accent + "33"}`, 
                               borderRadius: 8, 
                               fontWeight: 600,
                               cursor: isCooling ? "not-allowed" : "pointer"
                             }}
                           >
                             {isCooling ? `Resting (${waitSecs}s)` : `Scan ${p.label}`}
                           </button>
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>

              <style>{`
                @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
                @keyframes slide { 0%{transform:translateX(-100%)} 100%{transform:translateX(200%)} }
              `}</style>
            </div>
          )}

          {/* ===== DASHBOARD ===== */}
          {tab === "dashboard" && (
            <div>
              {/* KPIs */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginBottom: 18 }}>
                {(() => {
                  const displayViews = finalViews;
                  const displayLikes = periodLikes;

                  return [
                    { label: "Total Audience", val: totalAudience.toLocaleString(), sub: "Incl. Website Members", c: "var(--gold)" },
                    { label: "Total Views", val: displayViews === 0 ? "0" : formatVal(displayViews), sub: "Incl. Site Traffic", c: "var(--teal)" },
                    { label: "Total Likes", val: periodLikes === 0 ? "0" : formatVal(displayLikes), sub: `Engagement in ${timeRange}`, c: "var(--blue)" },
                    { label: "Student Leads", val: String(totalLeads), sub: "Website Conversions", c: "var(--purple)" },
                    { label: "Pending Replies", val: String(mentions.filter(m => !m.replied).length), sub: "All channels", c: "var(--red)" },
                  ].map(k => (
                    <Card key={k.label} style={{ padding: "14px 16px" }}>
                      <div style={{ fontSize: 10, color: "var(--muted2)", marginBottom: 5, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>{k.label}</div>
                      <div style={{ fontFamily: "var(--font-mono)", fontSize: 26, fontWeight: 500, color: k.c }}>{k.val}</div>
                      <div style={{ fontSize: 10, color: "var(--muted)", marginTop: 3 }}>{k.sub}</div>
                    </Card>
                  ));
                })()}
              </div>

              {/* Platform cards */}
              <SectionLabel>Platform Overview</SectionLabel>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 10, marginBottom: 18 }}>
                {platforms.map(p => {
                  const pPosts = filteredPosts.filter(x => x.platform === p.id);
                  const pViews = pPosts.reduce((acc, x) => acc + x.views, 0);
                  const pLikes = pPosts.reduce((acc, x) => acc + x.likes, 0);
                  const pImp = pPosts.reduce((acc, x) => acc + x.impressions, 0);

                  const scaledViews = (timeRange === "all time") ? (p.views || "0") : (pViews === 0 ? "0" : formatVal(pViews));
                  const scaledLikes = (timeRange === "all time") ? (p.likes || "0") : (pLikes === 0 ? "0" : formatVal(pLikes));

                  const isWebsite = p.id === "website";
                  const mainMetricVal = isWebsite ? p.followers : p.followers;
                  const mainMetricLabel = isWebsite ? "traffic" : "followers";
                  const sec1Label = isWebsite ? "Visitors" : "Views";
                  const sec2Label = isWebsite ? "Leads" : "Likes";

                  return (
                    <Card key={p.id}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                        <PlatformBadge pid={p.id} />
                        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--teal)" }}>{p.growth}</span>
                      </div>
                      <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, fontWeight: 500, color: "var(--text)" }}>{mainMetricVal}</div>
                      <div style={{ fontSize: 9, color: "var(--muted)", marginBottom: 4 }}>{mainMetricLabel}</div>
                      <div style={{ display: "flex", gap: 7, marginBottom: 8 }}>
                        <span style={{ fontSize: 9, color: "var(--muted2)" }}>{sec1Label}: <span style={{ color: "var(--text)" }}>{scaledViews}</span></span>
                        <span style={{ fontSize: 9, color: "var(--muted2)" }}>{sec2Label}: <span style={{ color: "var(--text)" }}>{scaledLikes}</span></span>
                      </div>
                      <ResponsiveContainer width="100%" height={32}>
                        <AreaChart data={generateChartData(pPosts, timeRange)}>
                          <Area 
                            type="monotone" 
                            dataKey="impressions" 
                            stroke={p.accent} 
                            fill={`${p.accent}18`} 
                            strokeWidth={2} 
                            dot={false} 
                            connectNulls 
                            animationDuration={600}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 9, color: "var(--muted)" }}>
                        <span>{isWebsite ? "Conv" : "Eng"} <span style={{ color: "var(--text)" }}>{isWebsite ? "3.4%" : p.engagement}</span></span>
                        <span>{isWebsite ? "PgV" : "Imp"} <span style={{ color: "var(--text)" }}>{isWebsite ? p.traffic : (pImp === 0 ? (p.views || "0") : formatVal(pImp))}</span></span>
                      </div>
                    </Card>
                  );
                })}
              </div>

              {/* Bottom row */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 14 }}>
                <Card>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                    <SectionLabel style={{ margin: 0 }}>View Trends — {timeRange}</SectionLabel>
                    <TimeRangeSelector />
                  </div>
                  <ResponsiveContainer width="100%" height={160}>
                    <AreaChart data={dynamicChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorImp" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--gold)" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="var(--gold)" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis 
                        dataKey="label" 
                        tick={{ fontSize: 9, fill: "var(--muted)" }} 
                        axisLine={false} 
                        tickLine={false} 
                        minTickGap={30}
                      />
                      <YAxis 
                        tick={{ fontSize: 9, fill: "var(--muted)" }} 
                        axisLine={false} 
                        tickLine={false} 
                        tickFormatter={v => v >= 1000 ? `${(v / 1000).toFixed(1)}K` : v} 
                      />
                      <Tooltip 
                        contentStyle={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 10, fontSize: 11, color: "var(--text)" }} 
                        itemStyle={{ color: "var(--gold)" }}
                        cursor={{ stroke: 'var(--border-lit)', strokeWidth: 1 }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="impressions" 
                        stroke="var(--gold)" 
                        fillOpacity={1} 
                        fill="url(#colorImp)" 
                        strokeWidth={2.5} 
                        dot={false} 
                        connectNulls 
                        animationDuration={1000}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </Card>

                <Card>
                  <SectionLabel>Activity Feed</SectionLabel>
                  {mentions.slice(0, 4).map(m => (
                    <div key={m.id} style={{ display: "flex", gap: 9, marginBottom: 11, alignItems: "flex-start" }}>
                      <div style={{ width: 26, height: 26, borderRadius: "50%", background: "var(--border)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 700, color: "var(--muted2)", flexShrink: 0 }}>{m.avatar}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", gap: 5, alignItems: "center", marginBottom: 2 }}>
                          <span style={{ fontSize: 11, fontWeight: 600, color: "var(--text)" }}>{m.user}</span>
                          <PlatformBadge pid={m.platform} size={9} />
                        </div>
                        <div style={{ fontSize: 10, color: "var(--muted2)", lineHeight: 1.5, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{m.text}</div>
                        <div style={{ fontSize: 9, color: "var(--muted)", marginTop: 2 }}>{m.time}</div>
                      </div>
                    </div>
                  ))}
                </Card>
              </div>
            </div>
          )}

          {/* ===== COMPOSE ===== */}
          {tab === "compose" && (
            <div style={{ maxWidth: 740 }}>
              <Card style={{ marginBottom: 14 }}>
                <div style={{ fontFamily: "var(--font-head)", fontSize: 17, fontWeight: 700, color: "var(--text)", marginBottom: 4 }}>AI Post Composer</div>
                <div style={{ fontSize: 12, color: "var(--muted2)", marginBottom: 20 }}>Generates as AIIA — context-aware, platform-optimised, event-aware</div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 700, color: "var(--muted)", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.08em" }}>Platform</div>
                    <select value={composePlatform} onChange={e => setComposePlatform(e.target.value)}>
                      {platforms.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, fontWeight: 700, color: "var(--muted)", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.08em" }}>Tone</div>
                    <select value={composeTone} onChange={e => setComposeTone(e.target.value)}>
                      {["authoritative", "educational", "inspirational", "technical", "conversational", "urgent"].map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "var(--muted)", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.08em" }}>Brief / Topic</div>
                  <textarea value={composeBrief} onChange={e => setComposeBrief(e.target.value)} rows={3} placeholder="e.g. Announce RIFTS-X pilot success at a government institution, highlight how it eliminated file misplacement..." />
                </div>

                <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                  <button onClick={generatePost} disabled={composeLoading || !composeBrief.trim()} style={{ padding: "9px 18px", background: (!composeBrief.trim() && !composeLoading) ? "var(--gold-dim)" : "var(--gold)", color: "#000", fontWeight: 700, fontSize: 12, borderRadius: 8, opacity: (!composeBrief.trim() && !composeLoading) ? 0.4 : 1, border: "none", cursor: "pointer" }}>
                    {composeLoading ? "⟳ Generating..." : "✦ Generate Voice"}
                  </button>
                  <button onClick={() => postToN8n(true)} disabled={isPosting || !composeBrief.trim()} style={{ padding: "9px 18px", background: "var(--teal-dim)", border: "1px solid rgba(14,207,176,0.3)", color: "var(--teal)", fontWeight: 700, fontSize: 12, borderRadius: 8, opacity: isPosting ? 0.6 : 1, cursor: isPosting ? "not-allowed" : "pointer" }}>
                    {isPosting ? "Sending..." : "Post to n8n"}
                  </button>
                  <select value={n8nEnv} onChange={e => setN8nEnv(e.target.value)} style={{ width: "auto", fontSize: 11, padding: "7px 12px", background: "var(--bg-card)", border: "1px solid var(--border)", color: "var(--text)", borderRadius: 8, outline: "none", cursor: "pointer" }}>
                    <option value="test">n8n Test Webhook</option>
                    <option value="prod">n8n Prod Webhook</option>
                  </select>
                  <div style={{ flex: 1 }} />
                  <div style={{ display: "flex", gap: 5 }}>
                    {platforms.map(p => (
                      <button key={p.id} style={{ width: 26, height: 26, borderRadius: 6, background: composePlatform === p.id ? `${p.accent}22` : "transparent", border: `1px solid ${composePlatform === p.id ? p.accent : "var(--border)"}`, fontSize: 10, fontFamily: "var(--font-mono)", color: composePlatform === p.id ? p.accent : "var(--muted)" }} onClick={() => setComposePlatform(p.id)}>{p.icon}</button>
                    ))}
                  </div>
                </div>
              </Card>

              {(generatedPost || composeLoading) && (
                <Card style={{ background: "#090c14", marginBottom: 14 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: "var(--gold)", textTransform: "uppercase", letterSpacing: "0.1em" }}>Generated Post — AIIA Voice</div>
                    <div style={{ display: "flex", gap: 6 }}><PlatformBadge pid={composePlatform} /><Pill>{composeTone}</Pill></div>
                  </div>
                  {composeLoading
                    ? <div style={{ color: "var(--muted2)", fontSize: 12, fontStyle: "italic" }}>Claude is writing in AIIA's voice...</div>
                    : <>
                      <textarea value={generatedPost} onChange={e => setGeneratedPost(e.target.value)} rows={7} style={{ fontSize: 13, lineHeight: 1.7 }} />
                      <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
                        <button onClick={() => postToN8n(false)} disabled={isPosting} style={{ padding: "7px 14px", background: isPosting ? "var(--muted)" : "var(--gold)", color: "#000", fontWeight: 700, fontSize: 12, borderRadius: 8, opacity: isPosting ? 0.6 : 1, border: "none", cursor: isPosting ? "not-allowed" : "pointer" }}>
                          {isPosting ? "Sending..." : "Post Now"}
                        </button>
                        <button style={{ padding: "7px 14px", background: "var(--teal-dim)", color: "var(--teal)", fontSize: 12, border: "1px solid rgba(14,207,176,0.2)", borderRadius: 8 }}>Schedule</button>
                        <button onClick={generatePost} style={{ padding: "7px 14px", background: "transparent", color: "var(--muted2)", fontSize: 12, border: "1px solid var(--border)", borderRadius: 8 }}>Regenerate</button>
                        <span style={{ marginLeft: "auto", fontFamily: "var(--font-mono)", fontSize: 10, color: composePlatform === "twitter" && generatedPost.length > 280 ? "var(--red)" : "var(--muted)" }}>{generatedPost.length} chars</span>
                      </div>
                      {postResult && (
                        <div style={{ marginTop: 10, fontSize: 11, padding: "8px 12px", borderRadius: 8, background: postResult.success ? "var(--teal-dim)" : "var(--red-dim)", color: postResult.success ? "var(--teal)" : "var(--red)", border: `1px solid ${postResult.success ? "var(--teal)" : "var(--red)"}33` }}>
                          {postResult.success ? "✓ " : "⚠ "}{postResult.message}
                        </div>
                      )}
                    </>}
                </Card>
              )}

              <Card>
                <SectionLabel>Quick Templates</SectionLabel>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {TEMPLATES.map(t => (
                    <button key={t.label} onClick={() => setComposeBrief(t.brief)} style={{ background: "var(--bg-hover)", border: "1px solid var(--border)", borderRadius: 10, padding: "12px 14px", textAlign: "left", color: "var(--text)" }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 4 }}>
                        <span style={{ color: "var(--gold)", fontSize: 12 }}>{t.icon}</span>
                        <span style={{ fontSize: 12, fontWeight: 600 }}>{t.label}</span>
                      </div>
                      <div style={{ fontSize: 10, color: "var(--muted2)", lineHeight: 1.5 }}>{t.brief.substring(0, 70)}...</div>
                    </button>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* ===== INBOX ===== */}
          {tab === "inbox" && (
            <div>
              <div style={{ display: "flex", gap: 8, marginBottom: 14, alignItems: "center" }}>
                <span style={{ fontSize: 12, color: "var(--muted2)" }}>{mentions.filter(m => !m.replied).length} unread · {mentions.length} total</span>
                <button 
                  onClick={() => {
                    const brands = ["x", "linkedin", "tiktok", "instagram", "facebook", "youtube"];
                    const b = brands[Math.floor(Math.random() * brands.length)];
                    const newItem = {
                      id: Date.now(),
                      platform: b,
                      user: "Fresh Signal",
                      avatar: "FS",
                      text: "Just seeing this now! How can we get a demo of the new AIIA dashboard for our team?",
                      time: "Just now",
                      sentiment: "positive",
                      replied: false
                    };
                    setMentions(prev => [newItem, ...prev]);
                  }}
                  style={{ marginLeft: 10, padding: "4px 10px", background: "var(--bg-hover)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 10, color: "var(--gold)", fontWeight: 600 }}
                >
                  📡 Sync
                </button>
                <div style={{ flex: 1 }} />
                {["all", ...platforms.map(p => p.id)].map(f => (
                  <button key={f} onClick={() => setFilterPlatform(f)} style={{ padding: "4px 10px", background: filterPlatform === f ? "var(--gold-dim)" : "var(--bg-card)", border: `1px solid ${filterPlatform === f ? "rgba(240,180,41,0.3)" : "var(--border)"}`, borderRadius: 20, fontSize: 10, color: filterPlatform === f ? "var(--gold)" : "var(--muted2)" }}>
                    {f === "all" ? "All" : platforms.find(p => p.id === f)?.icon}
                  </button>
                ))}
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {visibleMentions.map(m => (
                  <Card key={m.id} style={{ opacity: m.replied ? 0.6 : 1, border: m.replied ? "1px solid var(--border)" : "1px solid var(--border-lit)" }}>
                    <div style={{ display: "flex", gap: 12 }}>
                      <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#1a2035", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 11, color: "var(--muted2)", flexShrink: 0 }}>{m.avatar}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", gap: 7, alignItems: "center", marginBottom: 5, flexWrap: "wrap" }}>
                          <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text)" }}>{m.user}</span>
                          <PlatformBadge pid={m.platform} />
                          <Pill color={m.sentiment === "positive" ? "var(--teal)" : "var(--gold)"} bg={m.sentiment === "positive" ? "var(--teal-dim)" : "var(--gold-dim)"}>{m.sentiment}</Pill>
                          {m.replied && <Pill color="var(--blue)" bg="var(--blue-dim)">replied</Pill>}
                          <span style={{ marginLeft: "auto", fontSize: 10, color: "var(--muted)" }}>{m.time}</span>
                        </div>
                        <div style={{ fontSize: 13, color: "var(--text)", lineHeight: 1.6, marginBottom: 12 }}>{m.text}</div>

                        {aiReplies[m.id] && (
                          <div style={{ background: "#090c14", border: "1px solid var(--border-lit)", borderRadius: 10, padding: 14, marginBottom: 10 }}>
                            <div style={{ fontSize: 9, fontWeight: 700, color: "var(--gold)", marginBottom: 7, textTransform: "uppercase", letterSpacing: "0.1em" }}>AI Draft — AIIA Voice</div>
                            <textarea value={aiReplies[m.id]} onChange={e => setAiReplies(r => ({ ...r, [m.id]: e.target.value }))} rows={3} style={{ fontSize: 12, lineHeight: 1.6 }} />
                            <div style={{ display: "flex", gap: 7, marginTop: 8 }}>
                              <button onClick={() => setMentions(ms => ms.map(x => x.id === m.id ? { ...x, replied: true } : x))} style={{ padding: "5px 13px", background: "var(--gold)", color: "#000", fontWeight: 700, fontSize: 11, borderRadius: 7 }}>Send</button>
                              <button onClick={() => draftReply(m)} style={{ padding: "5px 13px", background: "transparent", color: "var(--muted2)", fontSize: 11, border: "1px solid var(--border)", borderRadius: 7 }}>Redo</button>
                            </div>
                          </div>
                        )}

                        <div style={{ display: "flex", gap: 7 }}>
                          <button onClick={() => draftReply(m)} disabled={replyLoading[m.id]} style={{ padding: "5px 13px", background: "var(--purple-dim)", color: "var(--purple)", fontSize: 11, border: "1px solid rgba(167,139,250,0.2)", borderRadius: 8 }}>
                            {replyLoading[m.id] ? "⟳ Drafting..." : "✦ AI Draft Reply"}
                          </button>
                          <button style={{ padding: "5px 13px", background: "transparent", color: "var(--muted2)", fontSize: 11, border: "1px solid var(--border)", borderRadius: 8 }}>Ignore</button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* ===== ANALYTICS ===== */}
          {tab === "analytics" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
                <div>
                  <div style={{ fontFamily: "var(--font-head)", fontWeight: 700, fontSize: 18, color: "var(--text)" }}>Engagement Analytics</div>
                  <div style={{ fontSize: 11, color: "var(--muted2)", marginTop: 2 }}>Cross-platform performance tracking over chosen intervals</div>
                </div>
                <TimeRangeSelector />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                <Card>
                  <SectionLabel>Impressions — {timeRange}</SectionLabel>
                  <ResponsiveContainer width="100%" height={180}>
                    <AreaChart data={dynamicChartData}>
                      <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--muted)" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: "var(--muted)" }} axisLine={false} tickLine={false} tickFormatter={v => v > 1000 ? `${Math.round(v / 1000)}K` : v} />
                      <Tooltip contentStyle={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 11, color: "var(--text)" }} />
                      <Area type="monotone" dataKey="impressions" stroke="var(--gold)" fill="var(--gold-dim)" strokeWidth={2} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </Card>
                <Card>
                  <SectionLabel>Engagement — {timeRange}</SectionLabel>
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={dynamicChartData}>
                      <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--muted)" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: "var(--muted)" }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 11, color: "var(--text)" }} />
                      <Bar dataKey="eng" fill="var(--teal)" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              </div>

              <Card>
                <SectionLabel>Platform Breakdown</SectionLabel>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 10 }}>
                  {platforms.map(p => {
                    const pPosts = filteredPosts.filter(x => x.platform === p.id);
                    const pViews = pPosts.reduce((acc, x) => acc + x.views, 0);
                    const pLikes = pPosts.reduce((acc, x) => acc + x.likes, 0);

                    const scaledViews = pViews === 0 ? "0" : formatVal(pViews);
                    const scaledLikes = pLikes === 0 ? "0" : formatVal(pLikes);

                    return (
                      <div key={p.id} style={{ background: "var(--bg-hover)", borderRadius: 10, padding: "14px 12px", textAlign: "center" }}>
                        <PlatformBadge pid={p.id} size={12} />
                        <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, fontWeight: 500, color: "var(--text)", margin: "9px 0 2px" }}>{p.followers}</div>
                        <div style={{ fontSize: 9, color: "var(--muted)", marginBottom: 7 }}>{getMetricLabel(p.id, "followers").toLowerCase()}</div>
                        <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--teal)", fontWeight: 600 }}>{p.growth}</div>
                        <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 10, fontSize: 9, color: "var(--muted)" }}>
                          <span>{getMetricLabel(p.id, "views")}: <span style={{ color: "var(--text)" }}>{scaledViews}</span></span>
                          <span>{getMetricLabel(p.id, "likes")}: <span style={{ color: "var(--text)" }}>{scaledLikes}</span></span>
                          <span>{getMetricLabel(p.id, "engagement")}: <span style={{ color: "var(--text)" }}>{p.engagement}</span></span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            </div>
          )}

          {/* ===== SCHEDULE ===== */}
          {tab === "schedule" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <span style={{ fontSize: 12, color: "var(--muted2)" }}>Scheduled for Today — March 19, 2026</span>
                <button style={{ padding: "7px 14px", background: "var(--gold)", color: "#000", fontWeight: 700, fontSize: 11, borderRadius: 8 }}>+ New Post</button>
              </div>

              <Card style={{ marginBottom: 14 }}>
                {schedPosts.map((post, i) => (
                  <div key={post.id} style={{ display: "flex", gap: 14, alignItems: "flex-start", paddingBottom: i < schedPosts.length - 1 ? 16 : 0, marginBottom: i < schedPosts.length - 1 ? 16 : 0, borderBottom: i < schedPosts.length - 1 ? "1px solid var(--border)" : "none" }}>
                    <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--gold)", width: 46, flexShrink: 0 }}>{post.time}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", gap: 6, marginBottom: 6, flexWrap: "wrap" }}>
                        {post.platforms.map(p => <PlatformBadge key={p} pid={p} />)}
                        <Pill color={post.status === "scheduled" ? "var(--teal)" : "var(--gold)"} bg={post.status === "scheduled" ? "var(--teal-dim)" : "var(--gold-dim)"}>{post.status}</Pill>
                        <Pill color="var(--blue)" bg="var(--blue-dim)">{post.tag}</Pill>
                      </div>
                      <div style={{ fontSize: 12, color: "var(--text)", lineHeight: 1.6 }}>{post.content}</div>
                    </div>
                    <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                      <button style={{ padding: "4px 10px", background: "transparent", color: "var(--muted2)", fontSize: 10, border: "1px solid var(--border)", borderRadius: 7 }}>Edit</button>
                      <button onClick={() => setSchedPosts(ps => ps.filter(p => p.id !== post.id))} style={{ padding: "4px 10px", background: "var(--red-dim)", color: "var(--red)", fontSize: 10, border: "1px solid rgba(240,82,79,0.2)", borderRadius: 7 }}>Remove</button>
                    </div>
                  </div>
                ))}
              </Card>

              <Card>
                <SectionLabel>Optimal Posting Times — CAT (Harare)</SectionLabel>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10 }}>
                  {platforms.map(p => (
                    <div key={p.id} style={{ background: "var(--bg-hover)", borderRadius: 10, padding: 14 }}>
                      <PlatformBadge pid={p.id} />
                      <div style={{ fontFamily: "var(--font-mono)", fontSize: 15, color: "var(--text)", fontWeight: 500, margin: "9px 0 3px" }}>
                        {p.id === "twitter" ? "8–9 AM" : p.id === "instagram" ? "11 AM" : p.id === "linkedin" ? "7–8 AM" : p.id === "facebook" ? "1–3 PM" : "Fri 3 PM"}
                      </div>
                      <div style={{ fontSize: 9, color: "var(--muted)" }}>
                        {p.id === "twitter" ? "Tue & Wed" : p.id === "instagram" ? "Mon & Thu" : p.id === "linkedin" ? "Tue–Thu" : p.id === "facebook" ? "Wed & Fri" : "Weekly"}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}

          {/* ===== EVENTS & PRODUCTS ===== */}
          {tab === "events" && (
            <div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 18 }}>
                {EVENTS.map(e => (
                  <Card key={e.name}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                      <Pill color={e.color} bg={`${e.color}18`} border={`${e.color}44`}>{e.tag}</Pill>
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: e.color }}>{e.date}</span>
                    </div>
                    <div style={{ fontFamily: "var(--font-head)", fontWeight: 700, fontSize: 14, color: "var(--text)", marginBottom: 4 }}>{e.name}</div>
                    <div style={{ fontSize: 11, color: "var(--muted2)", marginBottom: 8, fontStyle: "italic" }}>"{e.theme}"</div>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>📍 {e.location}</div>
                    <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                      <button onClick={() => { setComposeBrief(`Promote the ${e.name} — ${e.date} at ${e.location}. Theme: ${e.theme}. Hosted by AIIA.`); setTab("compose"); }} style={{ padding: "5px 12px", background: `${e.color}18`, color: e.color, fontSize: 10, border: `1px solid ${e.color}33`, borderRadius: 7 }}>Generate Posts</button>
                      <button style={{ padding: "5px 12px", background: "transparent", color: "var(--muted2)", fontSize: 10, border: "1px solid var(--border)", borderRadius: 7 }}>View Schedule</button>
                    </div>
                  </Card>
                ))}
              </div>

              <SectionLabel>Products</SectionLabel>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
                {PRODUCTS.map(p => (
                  <Card key={p.name}>
                    <div style={{ fontFamily: "var(--font-head)", fontWeight: 800, fontSize: 22, color: p.color, marginBottom: 4 }}>{p.name}</div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: "var(--text)", marginBottom: 8 }}>{p.tagline}</div>
                    <div style={{ fontSize: 11, color: "var(--muted2)", lineHeight: 1.6, marginBottom: 14 }}>{p.desc}</div>
                    <button onClick={() => { setComposeBrief(`Write a social post promoting ${p.name} — ${p.desc}`); setTab("compose"); }} style={{ padding: "6px 14px", background: `${p.color}15`, color: p.color, fontSize: 10, border: `1px solid ${p.color}30`, borderRadius: 7 }}>Generate Promo Post</button>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* ===== KEYWORDS ===== */}
          {tab === "keywords" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 14 }}>
              <div>
                <Card style={{ marginBottom: 14 }}>
                  <SectionLabel>Tracked Keywords — AIIA Brand & Events</SectionLabel>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
                    {KEYWORDS.map(kw => (
                      <span key={kw} style={{ padding: "4px 11px", background: "var(--teal-dim)", color: "var(--teal)", borderRadius: 20, fontSize: 11, border: "1px solid rgba(14,207,176,0.15)" }}>{kw}</span>
                    ))}
                    <button style={{ padding: "4px 11px", background: "var(--bg-hover)", color: "var(--muted2)", borderRadius: 20, fontSize: 11, border: "1px solid var(--border)" }}>+ Add</button>
                  </div>
                </Card>

                <Card>
                  <SectionLabel>Recent Mentions</SectionLabel>
                  {mentions.map(m => (
                    <div key={m.id} style={{ padding: "11px 0", borderBottom: "1px solid var(--border)", display: "flex", gap: 10 }}>
                      <PlatformBadge pid={m.platform} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: "var(--text)", marginBottom: 2 }}>{m.user}</div>
                        <div style={{ fontSize: 11, color: "var(--muted2)", lineHeight: 1.5 }}>{m.text}</div>
                        <div style={{ fontSize: 9, color: "var(--muted)", marginTop: 3 }}>{m.time}</div>
                      </div>
                      <Pill color={m.sentiment === "positive" ? "var(--teal)" : "var(--gold)"} bg={m.sentiment === "positive" ? "var(--teal-dim)" : "var(--gold-dim)"}>{m.sentiment}</Pill>
                    </div>
                  ))}
                </Card>
              </div>

              <div>
                <Card style={{ marginBottom: 14 }}>
                  <SectionLabel>Keyword Trends</SectionLabel>
                  {[
                    { kw: "RIFTS-X", count: 18, trend: "up", delta: "+6" },
                    { kw: "AI Institute Africa", count: 34, trend: "up", delta: "+12" },
                    { kw: "Zimbabwe AI", count: 52, trend: "up", delta: "+19" },
                    { kw: "Cognify", count: 9, trend: "up", delta: "+3" },
                    { kw: "AI Tech Forum", count: 27, trend: "up", delta: "+14" },
                    { kw: "Nyanga 2026", count: 15, trend: "stable", delta: "0" },
                  ].map(a => (
                    <div key={a.kw} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: "1px solid var(--border)" }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: "var(--text)" }}>{a.kw}</div>
                        <div style={{ fontSize: 10, color: "var(--muted)" }}>{a.count} mentions today</div>
                      </div>
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: a.trend === "up" ? "var(--teal)" : "var(--muted2)" }}>{a.trend === "up" ? "↑" : "→"} {a.delta}</span>
                    </div>
                  ))}
                </Card>

                <Card>
                  <SectionLabel>Sentiment</SectionLabel>
                  {[
                    { label: "Positive", pct: 71, color: "var(--teal)" },
                    { label: "Neutral", pct: 22, color: "var(--gold)" },
                    { label: "Negative", pct: 7, color: "var(--red)" },
                  ].map(s => (
                    <div key={s.label} style={{ marginBottom: 13 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, marginBottom: 5 }}>
                        <span style={{ color: "var(--muted2)" }}>{s.label}</span>
                        <span style={{ color: s.color, fontFamily: "var(--font-mono)" }}>{s.pct}%</span>
                      </div>
                      <div style={{ height: 5, background: "var(--border)", borderRadius: 3, overflow: "hidden" }}>
                        <div style={{ height: "100%", width: `${s.pct}%`, background: s.color, borderRadius: 3 }} />
                      </div>
                    </div>
                  ))}
                </Card>
              </div>
            </div>
          )}
          {/* ===== DAILY REPORTS ===== */}
          {tab === "reports" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
                <div>
                  <div style={{ fontFamily: "var(--font-head)", fontWeight: 700, fontSize: 18, color: "var(--text)" }}>AIIA Daily Performance Report</div>
                  <div style={{ fontSize: 11, color: "var(--muted2)", marginTop: 2 }}>Automated reporting for {new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                   <button onClick={() => window.print()} style={{ padding: "9px 18px", background: "var(--bg-card)", color: "var(--text)", border: "1px solid var(--border)", fontWeight: 700, fontSize: 12, borderRadius: 8 }}>⎙ Print PDF</button>
                   <button style={{ padding: "9px 18px", background: "var(--gold)", color: "#000", fontWeight: 700, fontSize: 12, borderRadius: 8 }}>📧 Email stakeholders</button>
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                <Card>
                  <SectionLabel>Daily Summary</SectionLabel>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                    {[
                      { label: "Daily Views", val: formatVal(Math.round(periodViews * 0.15)) || 0, c: "var(--teal)" },
                      { label: "Daily Likes", val: formatVal(Math.round(periodLikes * 0.15)) || 0, c: "var(--blue)" },
                      { label: "New Followers", val: "+24", c: "var(--gold)" },
                      { label: "Avg Engagement", val: "5.4%", c: "var(--purple)" },
                    ].map(k => (
                      <div key={k.label} style={{ background: "var(--bg-hover)", borderRadius: 10, padding: 14, position: "relative" }}>
                        <div style={{ fontSize: 10, color: "var(--muted2)", marginBottom: 5 }}>{k.label}</div>
                        <div style={{ fontFamily: "var(--font-mono)", fontSize: 20, fontWeight: 500, color: k.c }}>{k.val}</div>
                        {k.label === "Daily Views" && platforms.some(p => p.data_source === "live") && (
                          <div style={{ position: "absolute", top: 8, right: 8, fontSize: 8, color: "var(--teal)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em" }}>● Live</div>
                        )}
                      </div>
                    ))}
                  </div>
                </Card>

                <Card>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                    <SectionLabel style={{ margin: 0 }}>AI Executive Insights</SectionLabel>
                    <button onClick={generateDailyReport} disabled={dailyReportLoading} style={{ padding: "5px 12px", background: "var(--gold-dim)", color: "var(--gold)", fontSize: 10, border: "1px solid rgba(253,192,16,0.2)", borderRadius: 7, fontWeight: 600 }}>
                      {dailyReportLoading ? "⟳ Analyzing Pipeline..." : "✦ Generate Live Analysis"}
                    </button>
                  </div>
                  <div style={{ fontSize: 12, color: "var(--text)", lineHeight: 1.6, background: "rgba(253,192,16,0.05)", border: "1px solid rgba(253,192,16,0.1)", borderRadius: 10, padding: 14 }}>
                    {dailyReportAI ? (
                       <div style={{ whiteSpace: "pre-wrap" }}>{dailyReportAI}</div>
                    ) : (dailyReportLoading ? (
                       <div style={{ color: "var(--muted2)", fontStyle: "italic" }}>AIIA AI is evaluating platform metrics and formulating recommendations...</div>
                    ) : (
                       <div style={{ color: "var(--muted)" }}>Click 'Generate Live Analysis' to compute today's insights based on live metric data.</div>
                    ))}
                  </div>
                </Card>
              </div>

              <Card>
                <SectionLabel>Platform Performance Table (Last 24h)</SectionLabel>
                <div style={{ width: "100%", overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                    <thead>
                      <tr style={{ borderBottom: "1px solid var(--border)", textAlign: "left" }}>
                        <th style={{ padding: "12px 8px", color: "var(--muted2)" }}>Platform</th>
                        <th style={{ padding: "12px 8px", color: "var(--muted2)" }}>Followers</th>
                        <th style={{ padding: "12px 8px", color: "var(--muted2)" }}>Est. Daily Views</th>
                        <th style={{ padding: "12px 8px", color: "var(--muted2)" }}>Est. Daily Likes</th>
                        <th style={{ padding: "12px 8px", color: "var(--muted2)" }}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {platforms.map(p => (
                        <tr key={p.id} style={{ borderBottom: "1px solid var(--border)" }}>
                          <td style={{ padding: "12px 8px", fontWeight: 600 }}><PlatformBadge pid={p.id} /> {p.label}</td>
                          <td style={{ padding: "12px 8px", fontFamily: "var(--font-mono)" }}>{p.followers}</td>
                          <td style={{ padding: "12px 8px", color: "var(--teal)", fontFamily: "var(--font-mono)" }}>{formatVal(p.daily_views)}</td>
                          <td style={{ padding: "12px 8px", color: "var(--blue)", fontFamily: "var(--font-mono)" }}>{formatVal(p.daily_likes)}</td>
                          <td style={{ padding: "12px 8px" }}><span style={{ color: "var(--teal)", fontSize: 10 }}>● Optimized</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          )}

          {/* ===== DATA INGESTION ===== */}
          {tab === "ingestion" && <DataIngestion authKey={authKey} injectLiveMetrics={injectLiveMetrics} />}

        </div>
      </div>
    </div>
  );
}

function SystemGate({ authKey, setAuthKey, children }) {
  const [input, setInput] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
    if (input === "Rubiem@2026") {
      setAuthKey(input);
      setError("");
    } else {
      setError("Invalid Access Key");
    }
  };

  if (authKey === "Rubiem@2026") return children;

  return (
    <div style={{ height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#07090e" }}>
      <div style={{ width: 340, padding: 30, background: "#0c0f18", border: "1px solid #181d2e", borderRadius: 20, textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 20 }}>🔐</div>
        <div style={{ fontFamily: "var(--font-head)", fontSize: 22, fontWeight: 800, color: "var(--text)", marginBottom: 10 }}>AIIA Signal</div>
        <div style={{ fontSize: 11, color: "var(--muted2)", marginBottom: 25 }}>Authorized Personnel Only</div>
        <input 
          type="password" 
          placeholder="Access Key" 
          value={input} 
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleLogin()}
          style={{ marginBottom: 15, textAlign: "center", letterSpacing: "0.2em" }}
        />
        {error && <div style={{ fontSize: 10, color: "var(--red)", marginBottom: 15 }}>{error}</div>}
        <button 
          onClick={handleLogin}
          style={{ width: "100%", padding: "12px", background: "var(--teal)", color: "#000", fontWeight: 700 }}
        >
          ENTER COMMAND CENTER
        </button>
      </div>
    </div>
  );
}

function DataIngestion({ authKey, injectLiveMetrics }) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    setError("");
    setResult(null);

    const formData = new FormData();
    formData.append("screenshot", file);

    try {
      const res = await fetch("/local-scraper/api/process-screenshot", {
        method: "POST",
        headers: { "X-AIIA-Auth": authKey },
        body: formData
      });
      if (!res.ok) throw new Error("AI Processing failed");
      const data = await res.json();
      setResult(data);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  const applyData = () => {
    if (!result || !result.platform_hint) return;
    const pid = result.platform_hint.toLowerCase();
    
    // Create a normalized metrics object for injectLiveMetrics
    const metrics = {
      followers: result.followers,
      lifetime_views: result.views,
      lifetime_likes: result.likes,
      engagement_rate: result.engagement,
      data_source: "manual_upload"
    };

    injectLiveMetrics(pid, metrics);
    setResult(null);
    setFile(null);
    alert(`${pid.toUpperCase()} metrics updated successfully!`);
  };

  return (
    <div style={{ maxWidth: 800, margin: "0 auto" }}>
      <Card>
        <SectionLabel>Manual Data Ingestion — AI Vision Assistant</SectionLabel>
        <p style={{ fontSize: 12, color: "var(--muted2)", marginBottom: 20 }}>
          Upload a screenshot of your analytics dashboard (Meta Business Suite, LinkedIn Analytics, etc.). 
          Our AI will extract the data and update your Command Center automatically.
        </p>

        <div 
          style={{ 
            border: "2px dashed var(--border)", 
            borderRadius: 14, 
            padding: 40, 
            textAlign: "center",
            background: file ? "var(--teal-dim)" : "transparent",
            cursor: "pointer",
            marginBottom: 20
          }}
          onClick={() => document.getElementById("file-input").click()}
        >
          <div style={{ fontSize: 30, marginBottom: 10 }}>{file ? "📸" : "📁"}</div>
          <div style={{ fontSize: 13, color: "var(--text)" }}>{file ? file.name : "Click to select analytics screenshot"}</div>
          <input 
            id="file-input" 
            type="file" 
            accept="image/*" 
            onChange={e => setFile(e.target.files[0])} 
            style={{ display: "none" }} 
          />
        </div>

        {file && !loading && !result && (
          <button 
            onClick={handleUpload}
            style={{ width: "100%", padding: 14, background: "var(--teal)", color: "#000", fontWeight: 700 }}
          >
            PROCESS WITH AI VISION
          </button>
        )}

        {loading && (
          <div style={{ textAlign: "center", padding: 20 }}>
            <div className="spin" style={{ margin: "0 auto 10px", width: 24, height: 24, border: "2px solid var(--teal)", borderTopColor: "transparent", borderRadius: "50%" }} />
            <div style={{ fontSize: 12, color: "var(--teal)" }}>AI is analyzing your data point...</div>
          </div>
        )}

        {error && <div style={{ color: "var(--red)", fontSize: 11, marginTop: 10 }}>Error: {error}</div>}

        {result && (
          <div style={{ marginTop: 25, padding: 20, background: "var(--bg-hover)", borderRadius: 12, border: "1px solid var(--teal)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 15 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--teal)" }}>AI Extraction Result</div>
              <PlatformBadge pid={result.platform_hint} />
            </div>
            
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 20 }}>
              {[
                { label: "Followers", val: result.followers },
                { label: "Traffic/Views", val: result.views },
                { label: "Engagement", val: result.likes },
                { label: "Rate", val: result.engagement },
              ].map(i => (
                <div key={i.label}>
                  <div style={{ fontSize: 9, color: "var(--muted2)", textTransform: "uppercase", marginBottom: 3 }}>{i.label}</div>
                  <div style={{ fontSize: 15, fontWeight: 600, fontFamily: "var(--font-mono)" }}>{i.val}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button 
                onClick={applyData}
                style={{ flex: 1, padding: 12, background: "var(--teal)", color: "#000", fontWeight: 700 }}
              >
                APPLY TO SYSTEM
              </button>
              <button 
                onClick={() => setResult(null)}
                style={{ padding: 12, background: "var(--bg)", color: "var(--muted2)", border: "1px solid var(--border)" }}
              >
                Discard
              </button>
            </div>
          </div>
        )}
      </Card>
      
      <Card style={{ marginTop: 15 }}>
        <SectionLabel>Manual Entry History</SectionLabel>
        <div style={{ fontSize: 11, color: "var(--muted)", textAlign: "center", padding: "10px 0" }}>
          No manual records added yet. Upload a screenshot to start.
        </div>
      </Card>
    </div>
  );
}

// Wrapper to provide auth gate
export default function AIIACommandCenter() {
  const [authKey, setAuthKey] = useState(() => localStorage.getItem("aiia_auth_key") || "");

  return (
    <SystemGate authKey={authKey} setAuthKey={setAuthKey}>
      <AIIACommandCenterMain authKey={authKey} />
    </SystemGate>
  );
}
