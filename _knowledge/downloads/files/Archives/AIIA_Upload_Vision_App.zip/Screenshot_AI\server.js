import express from 'express';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3005;

app.use(cors());
app.use(express.static('public'));

const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

app.post('/api/process', upload.single('screenshot'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No image uploaded." });

    const base64Image = req.file.buffer.toString('base64');
    let openAiKey = process.env.VITE_OPENAI_KEY || process.env.OPENAI_API_KEY;

    // Auto-fallback to the key used in the command center vault if missing 
    if (!openAiKey) openAiKey = "sk-44dcb45398f093998d9d6308b04fd0f560eb0cc17bc37a02";

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${openAiKey}`
            },
            body: JSON.stringify({
                model: "gpt-4o",
                messages: [
                    {
                        role: "user",
                        content: [
                            { type: "text", text: "Analyze this social media analytics screenshot. Extract exactly 4 numbers if present: Followers (or Subscribers/Total Audience), Lifetime Views (or Traffic), Lifetime Likes (or Total Engagement), and Engagement Rate (or Conversion Rate). Map them to this JSON structure: { \"followers\": \"...\", \"views\": \"...\", \"likes\": \"...\", \"engagement\": \"...\", \"platform_hint\": \"...\" }. If a value is missing, use '0'. Platform hint should be one of: x, linkedin, facebook, instagram, tiktok, youtube, website. Return ONLY the JSON." },
                            {
                                type: "image_url",
                                image_url: {
                                    url: `data:image/jpeg;base64,${base64Image}`
                                }
                            }
                        ]
                    }
                ],
                max_tokens: 300
            })
        });

        const data = await response.json();
        if (data.error) throw new Error(data.error.message);

        let content = data.choices[0].message.content;
        if (content.includes('```json')) {
            content = content.split('```json')[1].split('```')[0].trim();
        } else if (content.includes('```')) {
            content = content.split('```')[1].split('```')[0].trim();
        }

        const extracted = JSON.parse(content);
        res.json(extracted);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "AI processing failed: " + err.message });
    }
});

app.listen(port, () => {
    console.log(`Screenshot AI listening at http://localhost:${port}`);
});
