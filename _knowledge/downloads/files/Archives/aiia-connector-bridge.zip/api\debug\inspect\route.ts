import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
  try {
    const finance = db.prepare('SELECT * FROM financial_metrics').all();
    const marketing = db.prepare('SELECT * FROM marketing_metrics').all();
    const social = db.prepare('SELECT * FROM social_metrics').all();
    const admin = db.prepare('SELECT * FROM admin_metrics').all();
    const research = db.prepare('SELECT * FROM research_publications').all();
    const connections = db.prepare('SELECT id, name, category, status, last_sync_at FROM connections').all();
    const jobs = db.prepare('SELECT * FROM sync_jobs ORDER BY started_at DESC LIMIT 10').all();

    return NextResponse.json({
      counts: {
        finance: finance.length,
        marketing: marketing.length,
        social: social.length,
        admin: admin.length,
        research: research.length
      },
      data: {
        finance,
        marketing,
        social,
        admin,
        research,
        connections,
        jobs
      }
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
