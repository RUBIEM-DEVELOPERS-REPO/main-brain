import { NextResponse } from 'next/server';

export async function GET() {
  const endpoints = [
    { name: "Public Dashboard", endpoint: "/api/public/dashboard", methods: ["GET", "POST"] },
    { name: "Global Sync", endpoint: "/api/sync", methods: ["POST"] },
    { name: "Platform Summary", endpoint: "/api/summary", methods: ["GET"] },
    { name: "Events", endpoint: "/api/events", methods: ["GET"] },
    { name: "Products", endpoint: "/api/products", methods: ["GET"] },
    { name: "Weekly Analytics", endpoint: "/api/analytics/weekly", methods: ["GET"] },
    { name: "Social Platforms", endpoint: "/api/social/platforms", methods: ["GET"] }
  ];

  return NextResponse.json({
    system: "AIIA Command Center",
    version: "2.0.0",
    discovery_url: "/api/config",
    endpoints
  });
}
