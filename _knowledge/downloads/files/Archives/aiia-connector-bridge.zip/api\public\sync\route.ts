import { NextResponse } from 'next/server';
import db from '@/lib/db';

// POST /api/public/sync - Exact alias for force pull
export async function POST() {
  try {
    // In this context, 'sync' could mean triggering internal syncs for all Active connections
    const connections = db.prepare('SELECT id FROM connections WHERE status = "Active"').all() as any[];
    
    // We can't easily wait for all background fetches here without blocking, 
    // but we can log that a global sync was requested.
    console.log(`[GLOBAL SYNC] Requested at ${new Date().toISOString()}`);
    
    return NextResponse.json({ 
      success: true, 
      message: `Global sync triggered for ${connections.length} active systems.` 
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
