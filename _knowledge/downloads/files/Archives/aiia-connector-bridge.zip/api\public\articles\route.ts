import { NextResponse } from 'next/server';
import db from '@/lib/db';

// GET /api/public/articles - Returns articles
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const since = searchParams.get('since');
    const limit = parseInt(searchParams.get('limit') || '100');

    let query = 'SELECT * FROM research_publications';
    const params = [];

    if (since) {
      query += ' WHERE publication_date >= ?';
      params.push(since);
    }

    query += ' ORDER BY publication_date DESC LIMIT ?';
    params.push(limit);

    const articles = db.prepare(query).all(...params).map((a: any) => ({
      ...a,
      key_points: JSON.parse(a.key_points_json || '[]'),
      tags: JSON.parse(a.tags_json || '[]'),
      relevance_score: a.relevance_score || a.impact_factor
    }));
    return NextResponse.json(articles);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
