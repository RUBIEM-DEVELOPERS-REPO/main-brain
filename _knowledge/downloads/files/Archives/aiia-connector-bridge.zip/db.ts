import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.join(process.cwd(), 'dashboard.db');
const db = new Database(dbPath);

// Initialize schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS connections (
    id TEXT PRIMARY KEY,
    name TEXT,
    type TEXT, -- api, database, file
    category TEXT, -- finance, marketing, admin, social, custom
    config_json TEXT,
    secret_reference TEXT,
    status TEXT,
    last_sync_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS sync_jobs (
    id TEXT PRIMARY KEY,
    connection_id TEXT,
    status TEXT, -- pending, running, success, failed
    started_at DATETIME,
    completed_at DATETIME,
    records_processed INTEGER,
    error_message TEXT,
    FOREIGN KEY (connection_id) REFERENCES connections(id)
  );

  CREATE TABLE IF NOT EXISTS financial_metrics (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    metric_date DATE,
    revenue REAL,
    expenses REAL,
    profit REAL,
    cash_balance REAL,
    receivables REAL,
    payables REAL,
    projected_income REAL,
    projected_expenses REAL,
    profit_margin REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id),
    UNIQUE(metric_date, source_connection_id)
  );

  CREATE TABLE IF NOT EXISTS financial_requisitions (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    title TEXT,
    amount REAL,
    category TEXT,
    status TEXT,
    priority TEXT,
    external_created_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id)
  );

  CREATE TABLE IF NOT EXISTS financial_receipts (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    vendor TEXT,
    amount REAL,
    category TEXT,
    receipt_date DATE,
    status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id)
  );

  CREATE TABLE IF NOT EXISTS marketing_metrics (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    metric_date DATE,
    channel TEXT,
    campaign_name TEXT,
    spend REAL,
    impressions INTEGER,
    clicks INTEGER,
    leads INTEGER,
    conversions INTEGER,
    cost_per_lead REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id),
    UNIQUE(metric_date, channel, campaign_name, source_connection_id)
  );

  CREATE TABLE IF NOT EXISTS social_metrics (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    metric_date DATE,
    platform TEXT,
    followers INTEGER,
    growth TEXT, -- e.g. +15.2%
    lifetime_views INTEGER,
    lifetime_likes INTEGER,
    daily_views INTEGER,
    daily_likes INTEGER,
    sparkline_json TEXT, -- 7-point array
    members INTEGER,
    student_leads INTEGER,
    traffic INTEGER,
    unique_visitors INTEGER,
    posts INTEGER,
    impressions INTEGER,
    engagement REAL,
    clicks INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id),
    UNIQUE(metric_date, platform, source_connection_id)
  );

  CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    title TEXT,
    event_date DATETIME,
    location TEXT,
    theme TEXT,
    tags_json TEXT, -- JSON array
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    name TEXT,
    tagline TEXT,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS admin_metrics (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    metric_date DATE,
    open_tasks INTEGER,
    completed_tasks INTEGER,
    overdue_tasks INTEGER,
    pending_approvals INTEGER,
    internal_requests INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id),
    UNIQUE(metric_date, source_connection_id)
  );

  CREATE TABLE IF NOT EXISTS research_publications (
    id TEXT PRIMARY KEY,
    source_connection_id TEXT,
    external_id TEXT,
    title TEXT,
    authors TEXT,
    publication_date TEXT,
    summary TEXT,
    journal TEXT,
    status TEXT,
    impact_factor REAL,
    url TEXT,
    key_points_json TEXT,
    tags_json TEXT,
    relevance_score REAL,
    is_new INTEGER,
    fetched_at TEXT,
    search_provider TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_connection_id) REFERENCES connections(id),
    UNIQUE(external_id, source_connection_id)
  );

  CREATE TABLE IF NOT EXISTS agent_insights (
    id TEXT PRIMARY KEY,
    insight_type TEXT,
    category TEXT,
    title TEXT,
    summary TEXT,
    severity TEXT, -- info, warning, critical
    source_data_json TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

export default db;
