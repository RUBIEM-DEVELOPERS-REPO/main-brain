import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { action, data } = await request.json();
    
    // Find the financial connection
    const connection = db.prepare("SELECT * FROM connections WHERE category = 'Finance' LIMIT 1").get() as any;
    if (!connection) {
      return NextResponse.json({ error: 'Financial connection not found' }, { status: 404 });
    }

    const config = JSON.parse(connection.config_json);
    const baseUrl = config.url.replace('/api/public/dashboard', ''); // Get base URL
    
    let endpoint = '';
    if (action === 'receipt') endpoint = '/api/public/receipts';
    else if (action === 'inflow') endpoint = '/api/public/inflows';
    else return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

    const response = await fetch(`${baseUrl}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': connection.secret_reference || ''
      },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Financial system error: ${errText}`);
    }

    const result = await response.json();
    return NextResponse.json({ success: true, result });

  } catch (error: any) {
    console.error('Finance Action Error:', error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
