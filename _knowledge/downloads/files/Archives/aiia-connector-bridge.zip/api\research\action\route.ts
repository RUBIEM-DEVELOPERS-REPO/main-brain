import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { action, data } = await request.json();
    
    const connection = db.prepare("SELECT * FROM connections WHERE category = 'Research' LIMIT 1").get() as any;
    if (!connection) {
      return NextResponse.json({ error: 'Research connection not found' }, { status: 404 });
    }

    const config = JSON.parse(connection.config_json);
    const url = config.url; // Already points to /api/webhooks/send
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Research system error: ${errText}`);
    }

    const result = await response.json();
    return NextResponse.json({ success: true, result });

  } catch (error: any) {
    console.error('Research Action Error:', error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
