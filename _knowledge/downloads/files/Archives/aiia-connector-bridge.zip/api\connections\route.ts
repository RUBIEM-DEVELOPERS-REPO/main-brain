import { NextResponse } from 'next/server';
import db from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

export async function GET() {
  try {
    const connections = db.prepare('SELECT * FROM connections ORDER BY created_at DESC').all();
    return NextResponse.json(connections);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, type, category, config, secret_reference } = body;
    
    const id = uuidv4();
    const configJson = JSON.stringify(config);
    
    db.prepare(`
      INSERT INTO connections (id, name, type, category, config_json, secret_reference, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, type, category, configJson, secret_reference || null, 'Active');
    
    return NextResponse.json({ id, message: 'Connection created successfully' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) return NextResponse.json({ error: 'ID is required' }, { status: 400 });

    // Delete associated sync jobs first
    db.prepare('DELETE FROM sync_jobs WHERE connection_id = ?').run(id);
    // Delete the connection
    db.prepare('DELETE FROM connections WHERE id = ?').run(id);
    
    return NextResponse.json({ message: 'Connection deleted successfully' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
