import { NextResponse } from 'next/server';
import db from '@/lib/db';

// GET /api/public/reports - Returns reports
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const since = searchParams.get('since');
    
    // For now, we reuse research_publications or we could have a separate reports table
    // The user requested /api/public/reports as a specific endpoint
    const query = since 
      ? 'SELECT * FROM research_publications WHERE publication_date >= ? ORDER BY publication_date DESC' 
      : 'SELECT * FROM research_publications ORDER BY publication_date DESC';
    
    const reports = db.prepare(query).all(since ? [since] : []);
    
    return NextResponse.json(reports);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
