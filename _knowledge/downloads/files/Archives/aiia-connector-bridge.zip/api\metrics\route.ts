import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    
    if (!category) {
      return NextResponse.json({ error: 'Category is required' }, { status: 400 });
    }

    let data;
    if (category === 'Social') {
      data = db.prepare(`
        SELECT * FROM (
          SELECT * FROM social_metrics 
          WHERE platform != 'Global' 
          ORDER BY rowid DESC
        )
        GROUP BY platform
        ORDER BY platform ASC
      `).all();
    } else if (category === 'Finance') {
      const metrics = db.prepare(`
        SELECT * FROM financial_metrics 
        ORDER BY metric_date DESC
      `).all();
      
      const receipts = db.prepare('SELECT * FROM financial_receipts ORDER BY receipt_date DESC LIMIT 10').all();
      const requisitions = db.prepare('SELECT * FROM financial_requisitions ORDER BY external_created_at DESC LIMIT 10').all();
      
      data = {
        metrics,
        receipts,
        requisitions,
        latest: metrics[0] || { revenue: 0, expenses: 0, profit: 0, cash_balance: 0 }
      };
    } else if (category === 'Marketing') {
      data = db.prepare(`
        SELECT * FROM marketing_metrics 
        ORDER BY metric_date DESC
      `).all();
    } else if (category === 'Admin') {
      data = db.prepare(`
        SELECT * FROM admin_metrics 
        ORDER BY metric_date DESC
      `).all();
    } else if (category === 'Research') {
      data = db.prepare(`
        SELECT * FROM research_publications 
        ORDER BY publication_date DESC 
        LIMIT 50
      `).all();
    } else if (category === 'Trends') {
      data = db.prepare(`
        SELECT metric_date as name, revenue, expenses 
        FROM financial_metrics 
        ORDER BY metric_date ASC 
        LIMIT 30
      `).all();
    } else if (category === 'Summary') {
      // Aggregate summary for all time
      const finance = db.prepare(`
        SELECT revenue as totalIncome, expenses as totalSpent 
        FROM financial_metrics
        ORDER BY metric_date DESC LIMIT 1
      `).get() as any;
      
      const totalRevenue = (finance?.totalIncome || 0) - (finance?.totalSpent || 0);
      
      const marketing = db.prepare(`
        SELECT SUM(leads) as totalLeads 
        FROM marketing_metrics
      `).get() as any;

      const socialGlobal = db.prepare(`
        SELECT lifetime_views as reach 
        FROM social_metrics
        WHERE platform = 'Global'
        ORDER BY rowid DESC LIMIT 1
      `).get() as any;
      
      const totalFollowers = socialGlobal?.reach || 0;
      
      const admin = db.prepare(`
        SELECT pending_approvals as totalApprovals 
        FROM admin_metrics 
        ORDER BY metric_date DESC LIMIT 1
      `).get() as any;

      const socialSummary = db.prepare(`
        SELECT student_leads as totalLeads
        FROM social_metrics
        WHERE platform = 'Global'
        ORDER BY metric_date DESC LIMIT 1
      `).get() as any;
      
      data = {
        totalRevenue: totalRevenue,
        totalProfit: totalRevenue,
        totalLeads: socialSummary?.totalLeads || marketing?.totalLeads || 0,
        totalFollowers: totalFollowers,
        totalApprovals: admin?.totalApprovals || 0
      };
    }

    return NextResponse.json(data);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
