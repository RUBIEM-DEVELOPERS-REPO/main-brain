import { NextResponse } from 'next/server';
import db from '@/lib/db';

// GET /api/public - Discovery
export async function GET() {
  try {
    const counts = {
      finance: (db.prepare('SELECT count(*) as c FROM financial_metrics').get() as { c: number }).c,
      marketing: (db.prepare('SELECT count(*) as c FROM marketing_metrics').get() as { c: number }).c,
      social: (db.prepare('SELECT count(*) as c FROM social_metrics').get() as { c: number }).c,
      research: (db.prepare('SELECT count(*) as c FROM research_publications').get() as { c: number }).c,
      connections: (db.prepare('SELECT count(*) as c FROM connections').get() as { c: number }).c
    };

    return NextResponse.json({
      name: "Integrated Company Dashboard API",
      version: "1.0.0",
      collections: [
        { name: "finance", count: counts.finance, endpoint: "/api/public/dashboard" },
        { name: "marketing", count: counts.marketing, endpoint: "/api/marketing/campaigns" },
        { name: "social", count: counts.social, endpoint: "/api/social/platforms" },
        { name: "research", count: counts.research, endpoint: "/api/public/articles" }
      ],
      health: "/api/public/health"
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
