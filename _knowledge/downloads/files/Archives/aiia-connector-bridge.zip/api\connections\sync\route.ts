import { NextResponse } from 'next/server';
import db from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';
import { Client } from 'pg';

async function syncSocialExport(connection: any, connectionId: string) {
  const config = JSON.parse(connection.config_json);
  const base = config.url.replace(/\/$/, '');
  let recordsProcessed = 0;

  const safeFetch = async (path: string) => {
    try {
      const res = await fetch(`${base}${path}`, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) return null;
      const json = await res.json();
      return json.data || json;
    } catch (e: any) {
      console.warn(`[SOCIAL-EXPORT] Failed ${path}:`, e.message);
      return null;
    }
  };

  // Normalize platform name
  const normPlatform = (name: string) => {
    if (!name) return 'Unknown';
    if (name.toLowerCase() === 'x') return 'X';
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  };

  const today = new Date().toISOString().split('T')[0];

  // 1. Platforms
  const platforms = await safeFetch('/api/export/platforms');
  if (platforms?.length) {
    const sstmt = db.prepare(`
      INSERT OR REPLACE INTO social_metrics (
        id, source_connection_id, metric_date, platform, followers, growth,
        lifetime_views, lifetime_likes, daily_views, daily_likes, sparkline_json,
        members, student_leads, traffic, unique_visitors, posts, impressions, engagement, clicks
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const p of platforms) {
      sstmt.run(
        uuidv4(), connectionId, today, normPlatform(p.platform),
        parseInt(p.followers) || 0, p.growth || '0%',
        parseInt(p.lifetime_views) || 0, parseInt(p.lifetime_likes) || 0,
        parseInt(p.daily_views) || 0, parseInt(p.daily_likes) || 0,
        JSON.stringify(p.week_data || []),
        parseInt(p.members) || 0, parseInt(p.student_leads) || 0,
        parseInt(p.traffic) || 0, parseInt(p.unique_visitors) || 0,
        parseInt(p.posts) || 0, parseInt(p.impressions) || 0,
        parseFloat(p.engagement) || 0, parseInt(p.clicks) || 0
      );
      recordsProcessed++;
    }
  }

  // 1.5 Global Summary
  const summaryRes = await safeFetch('/api/export/summary');
  if (summaryRes?.length) {
    const sumData = summaryRes[0];
    const sstmt = db.prepare(`
      INSERT OR REPLACE INTO social_metrics (
        id, source_connection_id, metric_date, platform, followers, growth,
        lifetime_views, lifetime_likes, daily_views, daily_likes, sparkline_json,
        members, student_leads, traffic, unique_visitors, posts, impressions, engagement, clicks
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    sstmt.run(
      uuidv4(), connectionId, today, 'Global',
      sumData.total_audience || 0, '0%',
      sumData.total_lifetime_views || 0, sumData.total_lifetime_likes || 0,
      0, 0,
      JSON.stringify([]),
      0, sumData.total_student_leads || 0,
      0, 0,
      sumData.total_posts || 0, sumData.total_impressions || 0,
      sumData.best_engagement_rate || 0, 0
    );
    recordsProcessed++;
  }

  // 2. Campaigns
  const campaigns = await safeFetch('/api/export/campaigns');
  if (campaigns?.length) {
    const mstmt = db.prepare(`
      INSERT OR REPLACE INTO marketing_metrics (id, source_connection_id, metric_date, channel, campaign_name, spend, impressions, clicks, leads, conversions)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const c of campaigns) {
      mstmt.run(uuidv4(), connectionId, today, normPlatform(c.channel), c.campaign_name || c.name || 'Campaign', parseFloat(c.spend) || 0, parseInt(c.impressions) || 0, parseInt(c.clicks) || 0, parseInt(c.leads) || 0, parseInt(c.conversions) || 0);
      recordsProcessed++;
    }
  }

  return recordsProcessed;
}

async function syncPostgres(connection: any, connectionId: string, jobId: string) {
  const config = JSON.parse(connection.config_json);
  const client = new Client(config.url);
  await client.connect();
  
  let recordsProcessed = 0;
  
  try {
    if (connection.category === 'Finance') {
      // Pull actual figures from Neon DB tables
      const budgetRes = await client.query('SELECT SUM(amount::numeric) as total FROM budgets');
      const inflowRes = await client.query("SELECT SUM(amount::numeric) as total FROM inflows WHERE status = 'confirmed'");
      const spentRes  = await client.query('SELECT SUM(amount::numeric) as total FROM receipts');
      
      const budget = parseFloat(budgetRes.rows[0]?.total) || 0;
      const income = parseFloat(inflowRes.rows[0]?.total) || 0;
      const spent  = parseFloat(spentRes.rows[0]?.total)  || 0;
      
      const profit = income - spent;
      const profitMargin = income > 0 ? (profit / income) * 100 : 0;

      const date = new Date().toISOString().split('T')[0];
      db.prepare(`
        INSERT OR REPLACE INTO financial_metrics 
        (id, source_connection_id, metric_date, revenue, expenses, profit, cash_balance, receivables, payables, projected_income, projected_expenses, profit_margin)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(uuidv4(), connectionId, date, income, spent, profit, budget, 0, 0, 0, 0, profitMargin);
      recordsProcessed++;

      // Sync Requisitions with correct column names
      const reqRes = await client.query('SELECT id, title, requested_amount, category, status, priority, created_at FROM requisitions ORDER BY created_at DESC LIMIT 50');
      const reqStmt = db.prepare(`
        INSERT OR REPLACE INTO financial_requisitions (id, source_connection_id, title, amount, category, status, priority, external_created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const req of reqRes.rows) {
        reqStmt.run(
          req.id, connectionId,
          req.title || '',
          parseFloat(req.requested_amount) || 0,
          req.category || '',
          req.status || '',
          req.priority || '',
          req.created_at ? req.created_at.toISOString() : null
        );
        recordsProcessed++;
      }

      // Sync Receipts
      const recRes = await client.query('SELECT id, vendor, amount, category, date, status FROM receipts ORDER BY date DESC LIMIT 50');
      const recStmt = db.prepare(`
        INSERT OR REPLACE INTO financial_receipts (id, source_connection_id, vendor, amount, category, receipt_date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      for (const r of recRes.rows) {
        recStmt.run(
          r.id, connectionId,
          r.vendor || '',
          parseFloat(r.amount) || 0,
          r.category || '',
          r.date ? new Date(r.date).toISOString().split('T')[0] : date,
          r.status || ''
        );
        recordsProcessed++;
      }
    }
    
    return recordsProcessed;
  } finally {
    await client.end();
  }
}

export async function POST(request: Request) {
  try {
    const { connectionId } = await request.json();
    
    const connection = db.prepare('SELECT * FROM connections WHERE id = ?').get(connectionId) as any;
    if (!connection) {
      return NextResponse.json({ error: 'Connection not found' }, { status: 404 });
    }

    if (!connection.config_json) {
      return NextResponse.json({ error: 'Connection configuration is missing' }, { status: 400 });
    }

    // Log start of sync
    const jobId = uuidv4();
    db.prepare(`
      INSERT INTO sync_jobs (id, connection_id, status, started_at)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    `).run(jobId, connectionId, 'running');

    if (connection.type === 'Postgres') {
      const count = await syncPostgres(connection, connectionId, jobId);
      db.prepare('UPDATE sync_jobs SET status = ?, completed_at = CURRENT_TIMESTAMP, records_processed = ? WHERE id = ?')
        .run('completed', count, jobId);
      return NextResponse.json({ success: true, recordsProcessed: count });
    }

    if (connection.category === 'Social' || connection.category === 'Marketing') {
      const count = await syncSocialExport(connection, connectionId);
      db.prepare('UPDATE sync_jobs SET status = ?, completed_at = CURRENT_TIMESTAMP, records_processed = ? WHERE id = ?')
        .run('completed', count, jobId);
      db.prepare("UPDATE connections SET status = 'Active', last_sync_at = CURRENT_TIMESTAMP WHERE id = ?")
        .run(connectionId);
      return NextResponse.json({ success: true, recordsProcessed: count });
    }

    let url;
    try {
      const config = JSON.parse(connection.config_json);
      url = config.url;
    } catch (e) {
      return NextResponse.json({ error: 'Invalid connection configuration format' }, { status: 400 });
    }

    if (!url) {
      return NextResponse.json({ error: 'Connection URL is missing from configuration' }, { status: 400 });
    }

    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (connection.secret_reference) headers['x-api-key'] = connection.secret_reference;

    try {
      const baseUrl = url.replace(/\/$/, '').replace(/\/api$/, '');

      let data: any = {};
      let targetUrl = baseUrl;
      if (connection.category === 'Research') targetUrl = `${baseUrl}/api/public/articles`;
      else if (connection.category === 'Finance') targetUrl = `${baseUrl}/api/public/dashboard`;

      const response = await fetch(targetUrl, { headers, signal: AbortSignal.timeout(30000) });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`System at ${targetUrl} responded with ${response.status}: ${errorText.substring(0, 100)}`);
      }
      data = await response.json();

      let recordsProcessed = 0;

      // Normalization helper
      const normalizeDate = (dateStr: string) => {
        try {
          const d = new Date(dateStr);
          return isNaN(d.getTime()) ? new Date().toISOString().split('T')[0] : d.toISOString().split('T')[0];
        } catch {
          return new Date().toISOString().split('T')[0];
        }
      };

      // Use a transaction for atomic updates
      const transaction = db.transaction((data) => {
        if (connection.category === 'Finance') {
          const stmt = db.prepare(`
            INSERT OR REPLACE INTO financial_metrics (id, source_connection_id, metric_date, revenue, expenses, profit, cash_balance, receivables, payables, projected_income, projected_expenses, profit_margin)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          
          const receiptStmt = db.prepare(`
            INSERT OR REPLACE INTO financial_receipts (id, source_connection_id, vendor, amount, category, receipt_date, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `);

          const reqStmt = db.prepare(`
            INSERT OR REPLACE INTO financial_requisitions (id, source_connection_id, title, amount, category, status, priority, external_created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `);

          // Handle Snapshot format with forecasts
          let items = [];
          if (Array.isArray(data)) items = data;
          else if (data.finance) items = [data.finance]; 
          else if (data.revenue !== undefined) items = [data]; 
          else items = data.metrics || data.data || [];

          for (const item of items) {
            const date = normalizeDate(item.date || item.metric_date);
            const summary = data.summary || {};
            const revenue = parseFloat(item.revenue || summary.totalInflows) || 0;
            const expenses = parseFloat(item.expenses || summary.totalSpent) || 0;
            const profit = revenue - expenses; 
            const balance = parseFloat(item.cash_balance || summary.totalBudget) || 0;
            
            // Forecasts
            const forecast = data.annualProfitForecast || item.annualProfitForecast || {};
            const pIncome = parseFloat(forecast.projectedIncome) || 0;
            const pExpenses = parseFloat(forecast.projectedExpenses) || 0;
            const pMargin = parseFloat(forecast.profitMargin) || 0;

            stmt.run(uuidv4(), connectionId, date, revenue, expenses, profit, balance, item.receivables || 0, item.payables || 0, pIncome, pExpenses, pMargin);
            recordsProcessed++;
          }

          // Ingest Receipts
          const receipts = data.recentReceipts || data.receipts || [];
          for (const r of receipts) {
            receiptStmt.run(uuidv4(), connectionId, r.vendor, r.amount, r.category, normalizeDate(r.date || r.receipt_date), r.status);
            recordsProcessed++;
          }

          // Ingest Requisitions
          const requisitions = data.recentRequisitions || data.requisitions || [];
          for (const req of requisitions) {
            reqStmt.run(uuidv4(), connectionId, req.title, req.requestedAmount || req.amount, req.category, req.status, req.priority, req.createdAt || req.external_created_at);
            recordsProcessed++;
          }

        } else if (connection.category === 'Marketing' || connection.category === 'Social') {
          // Social export handled separately — skip inline ingestion
          recordsProcessed += 0;
        } else if (connection.category === 'Research') {
          const stmt = db.prepare(`
            INSERT OR REPLACE INTO research_publications (
              id, source_connection_id, external_id, title, authors, 
              publication_date, summary, journal, status, impact_factor, 
              url, key_points_json, tags_json, relevance_score, is_new, 
              fetched_at, search_provider
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          const items = Array.isArray(data) ? data : (data.articles || data.publications || data.data || []);
          for (const item of items) {
            const date = normalizeDate(item.published_at || item.publication_date || item.date);
            stmt.run(
              uuidv4(), 
              connectionId, 
              item.external_id || uuidv4(),
              item.title || 'Untitled', 
              item.authors || item.source || 'Unknown', 
              date, 
              item.summary || '', 
              item.journal || item.source || 'Research Portal', 
              item.status || item.raw_status || 'Published', 
              parseFloat(item.impact_factor || item.relevance_score) || 0,
              item.url || '',
              JSON.stringify(item.key_points || []),
              JSON.stringify(item.tags || []),
              parseFloat(item.relevance_score) || 0,
              item.is_new ? 1 : 0,
              item.fetched_at || new Date().toISOString(),
              item.search_provider || 'Direct'
            );
            recordsProcessed++;
          }
        } else if (connection.category === 'Admin') {
          const stmt = db.prepare(`
            INSERT OR REPLACE INTO admin_metrics (id, source_connection_id, metric_date, open_tasks, completed_tasks, overdue_tasks, pending_approvals, internal_requests)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `);
          const items = Array.isArray(data) ? data : [data];
          for (const item of items) {
            const date = normalizeDate(item.date || item.metric_date);
            stmt.run(uuidv4(), connectionId, date, parseInt(item.open_tasks) || 0, parseInt(item.completed_tasks) || 0, parseInt(item.overdue_tasks) || 0, parseInt(item.pending_approvals) || 0, parseInt(item.internal_requests) || 0);
            recordsProcessed++;
          }
        } else if (connection.category === 'Social' || connection.category === 'Marketing') {
          // Additional Social endpoints like Products and Events
          if (data.products) {
            const pstmt = db.prepare(`
              INSERT OR REPLACE INTO products (id, name, tagline, description)
              VALUES (?, ?, ?, ?)
            `);
            for (const p of data.products) {
              pstmt.run(uuidv4(), p.name, p.tagline || '', p.description || '');
              recordsProcessed++;
            }
          }
          if (data.events) {
            const epstmt = db.prepare(`
              INSERT OR REPLACE INTO events (id, title, event_date, location, theme, tags_json)
              VALUES (?, ?, ?, ?, ?, ?)
            `);
            for (const e of data.events) {
              epstmt.run(uuidv4(), e.name, e.date, e.location, e.theme, JSON.stringify([e.tag]));
              recordsProcessed++;
            }
          }
        }
        return recordsProcessed;
      });

      const count = transaction(data);

      db.prepare(`
        UPDATE sync_jobs 
        SET status = 'success', completed_at = CURRENT_TIMESTAMP, records_processed = ?
        WHERE id = ?
      `).run(count, jobId);

      db.prepare("UPDATE connections SET last_sync_at = CURRENT_TIMESTAMP, status = 'Active' WHERE id = ?")
        .run(connectionId);

      return NextResponse.json({ success: true, recordsProcessed: count });

    } catch (syncError: any) {
      console.error(`Sync failed for ${connection.name}:`, syncError.message);
      db.prepare(`
        UPDATE sync_jobs 
        SET status = 'failed', completed_at = CURRENT_TIMESTAMP, error_message = ?
        WHERE id = ?
      `).run(syncError.message, jobId);
      
      db.prepare("UPDATE connections SET status = 'Error' WHERE id = ?").run(connectionId);
      return NextResponse.json({ success: false, error: syncError.message }, { status: 200 }); // Return 200 so the UI can show the error
    }

  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
