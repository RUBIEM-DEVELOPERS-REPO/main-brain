import { NextResponse } from 'next/server';
import db from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

// GET /api/public/dashboard - Returns live snapshot
export async function GET() {
  try {
    const finance = db.prepare('SELECT * FROM financial_metrics ORDER BY metric_date DESC LIMIT 1').get() as any;
    const receipts = db.prepare('SELECT * FROM financial_receipts ORDER BY receipt_date DESC LIMIT 5').all();
    const requisitions = db.prepare('SELECT * FROM financial_requisitions ORDER BY external_created_at DESC LIMIT 5').all();
    
    // Category Totals
    const financeCategories = db.prepare('SELECT category, SUM(amount) as total FROM financial_receipts GROUP BY category').all();
    const categoryTotals: any = {};
    financeCategories.forEach((c: any) => categoryTotals[c.category] = c.total);

    const marketing = db.prepare('SELECT SUM(leads) as totalLeads FROM marketing_metrics').get() as any;
    const social = db.prepare('SELECT SUM(followers) as totalFollowers FROM social_metrics').get() as any;

    return NextResponse.json({
      timestamp: new Date().toISOString(),
      annualProfitForecast: {
        projectedIncome: finance?.projected_income || 0,
        projectedExpenses: finance?.projected_expenses || 0,
        projectedProfit: (finance?.projected_income || 0) - (finance?.projected_expenses || 0),
        profitMargin: finance?.profit_margin || 0
      },
      finance: finance || { 
        revenue: 0, 
        expenses: 0, 
        profit: 0, 
        cash_balance: 0,
        receivables: 0,
        payables: 0
      },
      recentReceipts: receipts,
      recentRequisitions: requisitions,
      categoryTotals,
      marketing: { totalLeads: marketing?.totalLeads || 0 },
      social: { totalFollowers: social?.totalFollowers || 0 }
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST /api/public/dashboard - Accepts Finance System data, stores it
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const { date, revenue, expenses, cash_balance, receivables, payables } = data;
    
    if (revenue === undefined || expenses === undefined) {
      return NextResponse.json({ error: 'Missing revenue or expenses' }, { status: 400 });
    }

    const id = uuidv4();
    db.prepare(`
      INSERT OR REPLACE INTO financial_metrics (id, metric_date, revenue, expenses, profit, cash_balance, receivables, payables)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, 
      date || new Date().toISOString().split('T')[0], 
      revenue, 
      expenses, 
      revenue - expenses, 
      cash_balance || 0,
      receivables || 0,
      payables || 0
    );

    return NextResponse.json({ success: true, message: 'Finance data ingested' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
