import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
  try {
    const globalRow = db.prepare(`
      SELECT * FROM social_metrics 
      WHERE platform = 'Global' 
      ORDER BY rowid DESC LIMIT 1
    `).get() as any;

    return NextResponse.json({
      total_audience: globalRow?.followers || 0, // followers mapped to total_audience in sync
      total_lifetime_views: globalRow?.lifetime_views || 0,
      total_lifetime_likes: globalRow?.lifetime_likes || 0,
      total_posts: globalRow?.posts || 0,
      total_student_leads: globalRow?.student_leads || 0,
      best_engagement_rate: globalRow?.engagement || 0
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
