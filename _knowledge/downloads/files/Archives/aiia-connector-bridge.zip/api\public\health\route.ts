import { NextResponse } from 'next/server';
import db from '@/lib/db';

// GET /api/public/health - Health Check
export async function GET() {
  try {
    const lastSync = db.prepare('SELECT MAX(completed_at) as last FROM sync_jobs WHERE status = "success"').get() as any;
    
    return NextResponse.json({
      status: "UP",
      timestamp: new Date().toISOString(),
      last_sync_event: lastSync?.last || null,
      database: "connected",
      environment: process.env.NODE_ENV
    });
  } catch (error: any) {
    return NextResponse.json({ 
      status: "DOWN", 
      error: error.message 
    }, { status: 500 });
  }
}
