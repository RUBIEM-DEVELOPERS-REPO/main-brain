import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
  try {
    const total = db.prepare('SELECT COUNT(*) as count FROM research_publications').get() as any;
    const isNew = db.prepare('SELECT COUNT(*) as count FROM research_publications WHERE is_new = 1').get() as any;
    const reports = db.prepare('SELECT COUNT(*) as count FROM research_publications WHERE journal LIKE "%Report%"').get() as any;
    const saved = db.prepare('SELECT COUNT(*) as count FROM research_publications WHERE status = "Saved"').get() as any;

    return NextResponse.json({
      total: total.count,
      new: isNew.count,
      saved: saved.count,
      reports: reports.count,
      version: "1.1"
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
