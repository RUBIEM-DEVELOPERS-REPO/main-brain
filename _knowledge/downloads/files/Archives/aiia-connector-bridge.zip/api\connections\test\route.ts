import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { url, authType, token } = body;
    
    if (!url) {
      return NextResponse.json({ error: 'URL is required' }, { status: 400 });
    }

    const headers: Record<string, string> = {};
    if (authType === 'Bearer' && token) {
      headers['Authorization'] = `Bearer ${token}`;
    } else if (authType === 'API Key' && token) {
      headers['x-api-key'] = token;
    }

    const response = await fetch(url, { 
      method: 'GET',
      headers,
      signal: AbortSignal.timeout(5000) // 5 second timeout
    });

    if (response.ok) {
      return NextResponse.json({ success: true, message: 'Connection successful' });
    } else {
      return NextResponse.json({ 
        success: false, 
        message: `Connection failed with status: ${response.status} ${response.statusText}` 
      });
    }
  } catch (error: any) {
    return NextResponse.json({ 
      success: false, 
      message: `Connection failed: ${error.message}` 
    });
  }
}
