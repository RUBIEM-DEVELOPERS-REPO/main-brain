import { NextResponse } from 'next/server';
import db from '@/lib/db';

// POST /api/sync - force a fresh pull before reading data
export async function POST() {
  try {
    // This is essentially the same as /api/public/sync
    console.log(`[FORCE SYNC] Initiated at ${new Date().toISOString()}`);
    
    // We could trigger a fetch from internal/external connections here
    return NextResponse.json({ 
      success: true, 
      message: 'Global fresh pull initiated.' 
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
