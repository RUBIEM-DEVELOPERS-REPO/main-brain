import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
  try {
    const events = db.prepare('SELECT * FROM events ORDER BY event_date ASC').all();
    return NextResponse.json(events.map((e: any) => ({
      ...e,
      tags: JSON.parse(e.tags_json || '[]')
    })));
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
