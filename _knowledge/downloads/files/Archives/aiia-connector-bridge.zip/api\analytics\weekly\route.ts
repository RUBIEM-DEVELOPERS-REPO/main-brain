import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
  try {
    const weekly = db.prepare(`
      SELECT 
        metric_date as date, 
        SUM(impressions) as impressions, 
        SUM(engagement) as engagement,
        SUM(clicks) as reach
      FROM social_metrics 
      GROUP BY metric_date 
      ORDER BY metric_date DESC 
      LIMIT 7
    `).all();
    
    return NextResponse.json(weekly.reverse());
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
